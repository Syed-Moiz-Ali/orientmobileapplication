import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:staff_app/core/router/app_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_core/shared_core.dart';
import 'package:staff_app/features/technician/domain/entities/technician_entities.dart';
import 'package:staff_app/features/technician/presentation/providers/technician_providers.dart';
import 'package:staff_app/features/technician/presentation/widgets/section_card.dart';
import 'package:staff_app/features/technician/presentation/widgets/job_search_bar.dart';
import 'package:staff_app/features/technician/presentation/widgets/job_card_tile.dart';

class AssignedJobsList extends ConsumerWidget {
  const AssignedJobsList({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(technicianDashboardProvider);
    final notifier = ref.read(technicianDashboardProvider.notifier);

    return SectionCard(
      title: 'Assigned Jobs',
      icon: Icons.work_outline_rounded,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          JobSearchBar(onJobFound: () => _openDetail(context, ref, state.selectedJob!)),
          SizedBox(height: AppDimensions.s14),
          ...state.assignedJobs.map((job) {
            return Padding(
              padding: EdgeInsets.only(bottom: AppDimensions.s10),
              child: JobCardTile(job: job, onStatusChanged: (s) => notifier.updateAssignedJobStatus(job.id, s)),
            );
          }),
        ],
      ),
    );
  }

  void _openDetail(BuildContext context, WidgetRef ref, TechnicianJobEntity job) {
    context
        .push(AppRoutes.technicianJobDetail, extra: job)
        .whenComplete(() => ref.read(technicianDashboardProvider.notifier).closeJob());
  }
}
