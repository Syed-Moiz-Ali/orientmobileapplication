import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_auth/shared_auth.dart';
import 'package:crm_app/features/crm_dashboard/presentation/crm_dashboard_view.dart';

class AppRoutes {
  AppRoutes._();

  static const String startup = '/';
  static const String login = '/login';
  static const String crmDashboard = '/crm_dashboard_view';
  static const String forgotPassword = '/forgot-password';
}

final _routerRefreshNotifier = ValueNotifier<int>(0);

final appRouterProvider = Provider<GoRouter>((ref) {
  ref.listen<AuthState>(authNotifierProvider, (_, __) {
    _routerRefreshNotifier.value++;
  });

  return GoRouter(
    refreshListenable: _routerRefreshNotifier,
    initialLocation: AppRoutes.startup,
    redirect: (context, state) {
      final authState = ref.read(authNotifierProvider);
      final matched = state.matchedLocation;

      final isAuthRoute =
          matched == AppRoutes.login || matched == AppRoutes.forgotPassword;

      return switch (authState) {
        AuthUnauthenticated() => isAuthRoute ? null : AppRoutes.login,
        AuthLoading() =>
          matched == AppRoutes.startup ? null : AppRoutes.startup,
        AuthError() => isAuthRoute ? null : AppRoutes.login,
        AuthAuthenticated(:final role) when !_isCrmRole(role) =>
          isAuthRoute ? null : AppRoutes.login,
        AuthAuthenticated() =>
          matched == AppRoutes.login || matched == AppRoutes.startup
              ? AppRoutes.crmDashboard
              : null,
      };
    },
    routes: [
      GoRoute(
        path: AppRoutes.startup,
        builder: (context, state) => const AuthLoadingView(),
      ),
      GoRoute(
        path: AppRoutes.login,
        name: AppRoutes.login,
        builder: (context, state) => LoginView(
          appName: 'Orient CRM App',
          intendedUsers: 'For CRM and customer support users',
          appPurpose:
              'Manage customer follow-ups, service communication, leads, reminders, and support activity.',
          onLoginSuccess: () => context.go(AppRoutes.crmDashboard),
          onForgotPassword: () => context.push(AppRoutes.forgotPassword),
        ),
      ),
      GoRoute(
        path: AppRoutes.forgotPassword,
        name: AppRoutes.forgotPassword,
        builder: (context, state) =>
            ForgotPasswordView(onBackToLogin: () => context.pop()),
      ),
      GoRoute(
        path: AppRoutes.crmDashboard,
        name: AppRoutes.crmDashboard,
        builder: (context, state) => const CrmDashboardView(),
      ),
    ],
  );
});

bool _isCrmRole(UserRole role) {
  return role == UserRole.crmDashboard || role == UserRole.owner;
}
