import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive/hive.dart';
import 'package:shared_core/shared_core.dart';
import 'package:shared_auth/shared_auth.dart';
import 'package:staff_app/core/local/sync_providers.dart';
import 'package:staff_app/features/advisor/data/datasources/advisor_local_datasource.dart';
import 'package:staff_app/features/advisor/data/datasources/advisor_providers.dart';
import 'package:staff_app/features/advisor/domain/entities/advisor_stats_entity.dart';
import 'package:staff_app/features/advisor/domain/entities/followup_reminder_entity.dart';
import 'package:staff_app/features/advisor/domain/entities/job_card_entity.dart';
import 'package:staff_app/features/advisor/domain/entities/pending_approval_entity.dart';

final advisorLocalDataSourceProvider = Provider<AdvisorLocalDataSource>((ref) {
  return AdvisorLocalDataSource(Hive.box<dynamic>('inspections'));
});

final advisorRefreshProvider = StateProvider<int>((ref) => 0);

const _emptyStats = AdvisorStatsEntity(
  newJobCardsToday: 0,
  inspectionsToday: 0,
  pendingApprovals: 0,
  vehiclesWaiting: 0,
  readyForDelivery: 0,
  totalOpenJobCards: 0,
);

/// Loads advisor stats from the backend. Falls back to empty data (never
/// fabricated numbers) when the request fails or the app is offline.
final advisorDashboardProvider = FutureProvider<AdvisorStatsEntity>((
  ref,
) async {
  ref.watch(advisorRefreshProvider);
  final remote = ref.read(advisorRemoteDataSourceProvider);
  try {
    final s = await remote.getStats();
    return AdvisorStatsEntity(
      newJobCardsToday: s.newJobCardsToday,
      inspectionsToday: s.inspectionsToday,
      pendingApprovals: s.pendingApprovals,
      vehiclesWaiting: s.vehiclesWaiting,
      readyForDelivery: s.readyForDelivery,
      totalOpenJobCards: s.totalOpenJobCards,
    );
  } catch (e, st) {
    ref
        .read(loggerProvider)
        .e('Failed to load advisor stats', error: e, stackTrace: st);
    return _emptyStats;
  }
});

final advisorRecentJobCardsProvider = FutureProvider<List<JobCardEntity>>((
  ref,
) async {
  ref.watch(advisorRefreshProvider);
  final remote = ref.read(advisorRemoteDataSourceProvider);
  final page = await remote.getJobCards(page: 1, size: 50);
  return page.content.map((job) {
    return JobCardEntity(
      id: job.id,
      dbId: job.dbId,
      customerName: job.customerName,
      vehicleInfo: job.vehicleInfo,
      time: job.time,
      createdDate: job.createdDate,
      lastUpdated: job.lastUpdated,
      status: JobCardStatus.values.firstWhere(
        (status) => status.name == job.status,
        orElse: () => JobCardStatus.inProgress,
      ),
      technician: job.technician,
      odometer: job.odometer,
      fuelLevel: job.fuelLevel,
    );
  }).toList();
});

final advisorPendingApprovalsProvider =
    FutureProvider<List<PendingApprovalEntity>>((ref) async {
      ref.watch(advisorRefreshProvider);
      final remote = ref.read(advisorRemoteDataSourceProvider);
      try {
        final approvals = await remote.getPendingApprovals();
        return approvals.map((a) {
          return PendingApprovalEntity(
            estimateId: a.estimateId,
            customerName: a.customerName,
            vehicleId: a.vehicleId,
            amount: a.amount,
            timeAgo: a.timeAgo,
          );
        }).toList();
      } catch (e, st) {
        ref
            .read(loggerProvider)
            .e('Failed to load pending approvals', error: e, stackTrace: st);
        return const [];
      }
    });

class ReminderNotifier extends Notifier<List<FollowupReminderEntity>> {
  @override
  List<FollowupReminderEntity> build() {
    final local = _loadFromHive();
    _loadFromRemote();
    return local;
  }

  List<FollowupReminderEntity> _loadFromHive() {
    try {
      final box = Hive.box<dynamic>('inspections');
      return box.values
          .whereType<Map>()
          .map((m) => Map<String, dynamic>.from(m))
          .where((m) => m['type'] == 'reminder')
          .map(
            (m) => FollowupReminderEntity(
              customerName: m['customerName'] as String? ?? '',
              vehicleId: m['vehicleId'] as String? ?? '',
              task: m['task'] as String? ?? '',
              dueDate: m['dueDate'] as String? ?? '',
              priority: ReminderPriority.values.firstWhere(
                (e) => e.name == m['priority'],
                orElse: () => ReminderPriority.medium,
              ),
            ),
          )
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> _loadFromRemote() async {
    try {
      final remote = ref.read(advisorRemoteDataSourceProvider);
      final reminders = await remote.getReminders();
      if (reminders.isEmpty) return;
      state = reminders.map((r) {
        return FollowupReminderEntity(
          customerName: r.customerName,
          vehicleId: r.vehicleId,
          task: r.task,
          dueDate: r.dueDate,
          priority: ReminderPriority.values.firstWhere(
            (e) => e.name == r.priority,
            orElse: () => ReminderPriority.medium,
          ),
        );
      }).toList();
    } catch (e, st) {
      ref
          .read(loggerProvider)
          .e('Failed to load reminders', error: e, stackTrace: st);
    }
  }

  Future<void> addReminder(FollowupReminderEntity reminder) async {
    final local = GenericLocalDataSource(Hive.box<dynamic>('inspections'));
    final id = await IdGenerator.nextId('REM');
    await local.save(id, {
      'id': id,
      'type': 'reminder',
      'customerName': reminder.customerName,
      'vehicleId': reminder.vehicleId,
      'task': reminder.task,
      'dueDate': reminder.dueDate,
      'priority': reminder.priority.name,
    });
    final queue = ref.read(syncQueueProvider);
    await queue.enqueue(
      SyncOperation(
        id: id,
        entityType: 'reminder',
        entityId: id,
        changeType: ChangeType.create,
        payload: {
          'customerName': reminder.customerName,
          'vehicleId': reminder.vehicleId,
          'task': reminder.task,
          'dueDate': reminder.dueDate,
          'priority': reminder.priority.name,
        },
        timestamp: DateTime.now().millisecondsSinceEpoch,
      ),
    );
    await ref.read(syncEngineProvider).syncAll();
    ref.invalidate(advisorRefreshProvider);
    state = _loadFromHive();
  }

  Future<void> dismissReminder(int index) async {
    final box = Hive.box<dynamic>('inspections');
    final reminder = state[index];
    final key = box.keys.firstWhere((k) {
      final v = box.get(k);
      return v is Map &&
          v['type'] == 'reminder' &&
          v['task'] == reminder.task &&
          v['customerName'] == reminder.customerName;
    }, orElse: () => '');
    if (key != '') {
      await box.delete(key);
    }
    ref.invalidate(advisorRefreshProvider);
    state = _loadFromHive();
  }
}

final advisorFollowupRemindersProvider =
    NotifierProvider<ReminderNotifier, List<FollowupReminderEntity>>(
      ReminderNotifier.new,
    );

final advisorInfoProvider = Provider<AdvisorInfo>((ref) {
  final auth = ref.watch(authNotifierProvider);
  if (auth is AuthAuthenticated && auth.profile != null) {
    final profile = auth.profile!;
    return AdvisorInfo(
      name: profile.name.isEmpty ? 'Advisor' : profile.name,
      id: profile.empId,
      branch: profile.branchName,
      shift: profile.shift,
    );
  }
  try {
    final box = Hive.box<dynamic>('inspections');
    final profile = box.get('advisor_profile');
    if (profile is Map) {
      return AdvisorInfo(
        name: (profile['name'] ?? 'Advisor').toString(),
        id: (profile['id'] ?? '').toString(),
        branch: (profile['branch'] ?? '').toString(),
        shift: (profile['shift'] ?? '').toString(),
      );
    }
  } catch (_) {}
  return const AdvisorInfo(name: 'Advisor', id: '', branch: '', shift: '');
});

class AdvisorInfo {
  final String name;
  final String id;
  final String branch;
  final String shift;
  const AdvisorInfo({
    required this.name,
    required this.id,
    required this.branch,
    required this.shift,
  });

  String get initials {
    final parts = name.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty || parts.first.isEmpty) return 'A';
    if (parts.length == 1) return parts.first.substring(0, 1).toUpperCase();
    return (parts.first.substring(0, 1) + parts.last.substring(0, 1))
        .toUpperCase();
  }
}

/// Seamless flow — bookings assigned to this advisor by the supervisor.
final advisorAssignedBookingsProvider =
    FutureProvider<List<AdvisorBookingResponse>>((ref) async {
      ref.watch(advisorRefreshProvider);
      final remote = ref.read(advisorRemoteDataSourceProvider);
      return remote.getAssignedBookings();
    });

/// Seamless flow — technicians available for per-item work assignment.
final advisorTechniciansProvider =
    FutureProvider<List<AdvisorTechnicianResponse>>((ref) async {
      final remote = ref.read(advisorRemoteDataSourceProvider);
      try {
        return await remote.getTechnicians();
      } catch (e, st) {
        ref
            .read(loggerProvider)
            .e('Failed to load technicians', error: e, stackTrace: st);
        return const [];
      }
    });

/// Seamless flow — work items (inspection + work) for a job card.
final advisorWorkItemsProvider =
    FutureProvider.family<List<WorkItemResponse>, String>((
      ref,
      jobCardRef,
    ) async {
      final remote = ref.read(advisorRemoteDataSourceProvider);
      try {
        return await remote.getWorkItems(jobCardRef);
      } catch (e, st) {
        ref
            .read(loggerProvider)
            .e(
              'Failed to load work items for $jobCardRef',
              error: e,
              stackTrace: st,
            );
        return const [];
      }
    });

final advisorWorkItemsRefreshProvider = StateProvider<int>((ref) => 0);

/// Assigns a technician to a single work item; refreshes the item list.
Future<void> advisorAssignWorkItem(
  WidgetRef ref,
  int taskId,
  String empId,
) async {
  final remote = ref.read(advisorRemoteDataSourceProvider);
  final ok = await remote.assignWorkItem(taskId, empId);
  if (ok) {
    ref.read(advisorWorkItemsRefreshProvider.notifier).state++;
  }
}

/// Phase 6 — staff notification feed for the advisor.
final advisorNotificationsProvider =
    FutureProvider<List<StaffNotificationResponse>>((ref) async {
      ref.watch(advisorRefreshProvider);
      final remote = ref.read(advisorRemoteDataSourceProvider);
      try {
        return await remote.getStaffNotifications();
      } catch (e, st) {
        ref
            .read(loggerProvider)
            .e('Failed to load staff notifications', error: e, stackTrace: st);
        return const [];
      }
    });
