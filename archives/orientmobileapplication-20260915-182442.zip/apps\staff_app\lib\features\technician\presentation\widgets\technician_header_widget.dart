import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_core/shared_core.dart';
import 'package:staff_app/core/models/profile_data.dart';
import 'package:staff_app/core/router/app_router.dart';
import 'package:staff_app/features/technician/domain/entities/technician_entities.dart';
import 'package:staff_app/features/technician/presentation/providers/technician_providers.dart';

class TechnicianHeaderWidget extends ConsumerWidget {
  const TechnicianHeaderWidget({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final colors = Theme.of(context).colorScheme;
    final notifier = ref.read(technicianDashboardProvider.notifier);
    final state = ref.watch(technicianDashboardProvider);
    final profile = notifier.profile;
    final status = state.attendanceStatus;

    return Container(
      color: colors.surface,
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: colors.primaryContainer,
                  shape: BoxShape.circle,
                  border: Border.all(color: colors.outlineVariant, width: 1.5),
                ),
                child: Center(
                  child: Text(
                    profile.avatarInitials,
                    style: AppTextStyles.button(
                      color: colors.onPrimaryContainer,
                    ),
                  ),
                ),
              ),
              SizedBox(width: AppDimensions.s12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      profile.name,
                      style: AppTextStyles.button(color: colors.onSurface),
                    ),
                    SizedBox(height: AppDimensions.s4),
                    Text(
                      '${profile.empId} \u2022 ${profile.branch}',
                      style: AppTextStyles.subtitle(
                        color: colors.onSurfaceVariant,
                      ),
                    ),
                    SizedBox(height: AppDimensions.s4),
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: AppDimensions.s8,
                        vertical: AppDimensions.s4,
                      ),
                      decoration: BoxDecoration(
                        color: colors.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(AppDimensions.r20),
                        border: Border.all(color: colors.outlineVariant),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 6,
                            height: 6,
                            decoration: BoxDecoration(
                              color: status == AttendanceStatus.working
                                  ? colors.primary
                                  : status == AttendanceStatus.onBreak
                                  ? AppColors.warning
                                  : colors.onSurfaceVariant,
                              shape: BoxShape.circle,
                            ),
                          ),
                          SizedBox(width: AppDimensions.s4),
                          Text(
                            status.label,
                            style: AppTextStyles.bodySmall(
                              color: colors.onSurface,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              InkResponse(
                onTap: () => _showProfile(context, ref),
                radius: 24,
                child: Tooltip(
                  message: 'Open profile',
                  child: Semantics(
                    button: true,
                    label: 'Open profile',
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        color: colors.primary.withValues(alpha: 0.10),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: colors.primary.withValues(alpha: 0.30),
                          width: 1.5,
                        ),
                      ),
                      child: Center(
                        child: Text(
                          profile.avatarInitials.substring(0, 1),
                          style: AppTextStyles.bodyStrong(
                            color: colors.primary,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showProfile(BuildContext context, WidgetRef ref) {
    final colors = Theme.of(context).colorScheme;
    final notifier = ref.read(technicianDashboardProvider.notifier);
    final profile = notifier.profile;

    showModalBottomSheet(
      context: context,
      backgroundColor: colors.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(AppDimensions.r28),
        ),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: colors.outlineVariant,
                borderRadius: BorderRadius.circular(AppDimensions.r2),
              ),
            ),
            SizedBox(height: AppDimensions.s24),
            CircleAvatar(
              radius: 34,
              backgroundColor: colors.primaryContainer,
              foregroundColor: colors.onPrimaryContainer,
              child: Text(
                profile.avatarInitials,
                style: AppTextStyles.title(color: colors.onPrimaryContainer),
              ),
            ),
            SizedBox(height: AppDimensions.s14),
            Text(
              profile.name,
              style: TextStyle(
                color: colors.onSurface,
                fontSize: 19,
                fontWeight: FontWeight.w700,
                letterSpacing: 0,
              ),
            ),
            SizedBox(height: AppDimensions.s4),
            Container(
              padding: EdgeInsets.symmetric(
                horizontal: AppDimensions.s12,
                vertical: AppDimensions.s4,
              ),
              decoration: BoxDecoration(
                color: colors.primaryContainer,
                borderRadius: BorderRadius.circular(AppDimensions.r20),
              ),
              child: Text(
                '${profile.role} \u2022 ${profile.branch}',
                style: AppTextStyles.subtitle(color: colors.onPrimaryContainer),
              ),
            ),
            SizedBox(height: AppDimensions.s6),
            Text(
              'Shift: ${profile.shift}',
              style: AppTextStyles.bodySmall(color: colors.onSurfaceVariant),
            ),
            SizedBox(height: AppDimensions.s24),
            _menuItem(
              context,
              icon: Icons.person_outline_rounded,
              label: 'My Profile',
              onTap: () {
                Navigator.pop(context);
                context.push(
                  AppRoutes.profile,
                  extra: ProfileData(
                    name: profile.name,
                    id: profile.empId,
                    role: profile.role,
                    branch: profile.branch,
                    shift: profile.shift,
                    avatarInitials: profile.avatarInitials,
                  ),
                );
              },
            ),
            _menuItem(
              context,
              icon: Icons.fingerprint_rounded,
              label: 'Attendance · Punch In / Out',
              onTap: () {
                Navigator.pop(context);
                context.push(AppRoutes.attendance);
              },
            ),
            _menuItem(
              context,
              icon: Icons.calendar_month_outlined,
              label: 'Shift Details',
              onTap: () {
                Navigator.pop(context);
                context.push(
                  AppRoutes.shiftDetails,
                  extra: {
                    'name': profile.name,
                    'id': profile.empId,
                    'shift': profile.shift,
                    'start': profile.shift.split(' - ').first,
                    'end': profile.shift.split(' - ').last,
                    'branch': profile.branch,
                  },
                );
              },
            ),
            _menuItem(
              context,
              icon: Icons.settings_outlined,
              label: 'Settings',
              onTap: () {
                Navigator.pop(context);
                context.push(AppRoutes.settings, extra: {'version': '1.0.0'});
              },
            ),
            SizedBox(height: AppDimensions.s8),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: OutlinedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                  _showLogoutDialog(context);
                },
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.danger,
                  side: BorderSide(color: AppColors.danger, width: 1.5),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppDimensions.r14),
                  ),
                ),
                icon: const Icon(Icons.logout_rounded, size: 18),
                label: Text(
                  'Logout',
                  style: AppTextStyles.subtitle(color: AppColors.danger),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _menuItem(
    BuildContext context, {
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: EdgeInsets.only(bottom: AppDimensions.s6),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(AppDimensions.r12),
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal: AppDimensions.s12,
              vertical: AppDimensions.s14,
            ),
            child: Row(
              children: [
                Icon(icon, size: 20, color: AppColors.text2),
                SizedBox(width: AppDimensions.s12),
                Text(
                  label,
                  style: AppTextStyles.bodyStrong(color: AppColors.textPrimary),
                ),
                const Spacer(),
                Icon(
                  Icons.chevron_right_rounded,
                  size: 18,
                  color: AppColors.text3,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    if (HiveCleaner.hasPendingSync()) {
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: AppColors.surface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppDimensions.r16),
          ),
          title: const Row(
            children: [
              Icon(
                Icons.sync_problem_rounded,
                color: AppColors.warning,
                size: 22,
              ),
              SizedBox(width: 10),
              Text(
                'Sync Pending',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
            ],
          ),
          content: const Text(
            'You have pending sync operations.\nPlease wait for sync to complete before logging out.',
            style: TextStyle(fontSize: 14, color: AppColors.text2, height: 1.5),
          ),
          actions: [
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.warning,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppDimensions.r10),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 12,
                ),
              ),
              child: const Text(
                'OK',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
      );
      return;
    }
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppDimensions.r16),
        ),
        title: const Row(
          children: [
            Icon(Icons.logout_rounded, color: AppColors.danger, size: 22),
            SizedBox(width: 10),
            Text(
              'Logout',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
          ],
        ),
        content: const Text(
          'Are you sure you want to logout?\nAll local data will be cleared.',
          style: TextStyle(fontSize: 14, color: AppColors.text2, height: 1.5),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text(
              'Cancel',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                color: AppColors.text3,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              HiveCleaner.clearAll().then((_) {
                if (context.mounted) context.go(AppRoutes.login);
              });
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.danger,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(AppDimensions.r10),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
            child: const Text(
              'Yes, Logout',
              style: TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }
}
