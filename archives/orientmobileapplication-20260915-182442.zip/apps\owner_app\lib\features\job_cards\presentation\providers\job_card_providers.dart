import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_auth/shared_auth.dart';
import 'package:owner_app/features/dashboard/data/datasources/owner_remote_adapters.dart';
import 'package:owner_app/features/dashboard/data/datasources/owner_remote_datasource.dart';
import 'package:owner_app/features/job_cards/data/repositories/job_card_repository_impl.dart';
import 'package:owner_app/features/job_cards/domain/entities/job_card.dart';
import 'package:owner_app/features/job_cards/domain/repositories/job_card_repository.dart';

final jobCardDatasourceProvider = Provider<JobCardDatasource>((ref) => JobCardRemoteDatasource(OwnerRemoteDataSource(ref.read(apiClientProvider))));
final jobCardRepositoryProvider = Provider<JobCardRepository>((ref) => JobCardRepositoryImpl(ref.watch(jobCardDatasourceProvider)));

class JobCardsState {
  final bool isLoading;
  final String searchQuery;
  final JobCardStatus? activeFilter;
  final List<JobCard> all;
  final List<JobCard> filtered;

  const JobCardsState({
    this.isLoading = true,
    this.searchQuery = '',
    this.activeFilter,
    this.all = const [],
    this.filtered = const [],
  });

  JobCardsState copyWith({
    bool? isLoading,
    String? searchQuery,
    JobCardStatus? activeFilter,
    List<JobCard>? all,
    List<JobCard>? filtered,
  }) {
    return JobCardsState(
      isLoading: isLoading ?? this.isLoading,
      searchQuery: searchQuery ?? this.searchQuery,
      // FE-FIX (audit P1): the raw parameter clobbered the active filter to
      // null on every copyWith (e.g. pull-to-refresh cleared the filter).
      activeFilter: activeFilter ?? this.activeFilter,
      all: all ?? this.all,
      filtered: filtered ?? this.filtered,
    );
  }
}

class JobCardsNotifier extends Notifier<JobCardsState> {
  @override
  JobCardsState build() {
    Future.microtask(load);
    return const JobCardsState();
  }

  Future<void> load() async {
    state = state.copyWith(isLoading: true);
    final cards = await ref.read(jobCardRepositoryProvider).getJobCards();
    state = state.copyWith(isLoading: false, all: cards, filtered: _applyFilters(cards, '', null));
  }

  Future<void> refresh() async {
    await load();
  }

  void onSearch(String query) {
    state = state.copyWith(searchQuery: query, filtered: _applyFilters(state.all, query, state.activeFilter));
  }

  void setFilter(JobCardStatus? status) {
    state = state.copyWith(activeFilter: status, filtered: _applyFilters(state.all, state.searchQuery, status));
  }

  /// Marks a job card as completed — FE-FIX (audit P1): previously local-only
  /// with a success snackbar while the status silently reverted on reload.
  /// The backend endpoint (PUT /owner/job-cards/{id}/status) now exists.
  Future<bool> markComplete(String id) async {
    try {
      final remote = ref.read(jobCardDatasourceProvider);
      final ok = await remote.updateJobCardStatus(id, 'completed');
      if (!ok) return false;
      final updated = state.all
          .map((jc) => jc.id == id ? jc.copyWith(status: JobCardStatus.completed) : jc)
          .toList();
      state = state.copyWith(
        all: updated,
        filtered: _applyFilters(updated, state.searchQuery, state.activeFilter),
      );
      final selected = ref.read(selectedJobCardProvider);
      if (selected != null && selected.id == id) {
        ref.read(selectedJobCardProvider.notifier).state =
            selected.copyWith(status: JobCardStatus.completed);
      }
      return true;
    } catch (_) {
      return false;
    }
  }

  List<JobCard> _applyFilters(List<JobCard> cards, String query, JobCardStatus? status) {
    var result = cards;
    if (query.isNotEmpty) {
      final q = query.toLowerCase();
      result = result.where((jc) =>
        jc.customerName.toLowerCase().contains(q) ||
        jc.id.toLowerCase().contains(q) ||
        jc.vehicle.toLowerCase().contains(q) ||
        jc.plateNumber.toLowerCase().contains(q)
      ).toList();
    }
    if (status != null) {
      result = result.where((jc) => jc.status == status).toList();
    }
    return result;
  }
}

final jobCardsProvider = NotifierProvider<JobCardsNotifier, JobCardsState>(JobCardsNotifier.new);

final selectedJobCardProvider = StateProvider<JobCard?>((ref) => null);
