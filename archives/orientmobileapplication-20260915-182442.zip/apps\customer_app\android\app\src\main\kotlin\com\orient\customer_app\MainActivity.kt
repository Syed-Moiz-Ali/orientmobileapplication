package com.orient.customer_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
