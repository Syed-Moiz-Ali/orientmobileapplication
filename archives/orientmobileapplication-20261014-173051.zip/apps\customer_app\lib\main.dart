import 'package:customer_app/l10n/gen/customer_localizations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_core/shared_core.dart';
import 'package:shared_auth/shared_auth.dart';
import 'package:customer_app/core/notifications/customer_push_scope.dart';
import 'package:customer_app/core/router/app_router.dart';
import 'package:customer_app/core/local/sync_providers.dart';
import 'package:customer_app/features/customer/presentation/providers/customer_providers.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    await EnvironmentConfig.init();
  } catch (e, _) {
    debugPrint('EnvironmentConfig init failed: $e');
  }

  final logger = createLogger();

  try {
    AppErrorHandler.init(logger);
  } catch (e, _) {
    debugPrint('AppErrorHandler init failed: $e');
  }

  try {
    await HiveRegistry.initHive();
  } catch (e, _) {
    debugPrint('HiveRegistry init failed: $e');
  }

  try {
    await PushNotificationService.instance.initialize();
  } catch (e, _) {
    debugPrint('PushNotificationService init failed: $e');
  }

  runApp(
    ProviderScope(
      overrides: [
        loggerProvider.overrideWithValue(logger),
        dioClientProvider.overrideWith((ref) {
          final dio = createDio(appName: 'customer');
          dio.interceptors.add(AuthInterceptor(ref, dio));
          return dio;
        }),
      ],
      child: const CustomerApp(),
    ),
  );
}

class CustomerApp extends ConsumerWidget {
  const CustomerApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(appRouterProvider);
    final brand = ref.watch(brandConfigProvider);
    final effectiveLocale = AppLocales.resolve(
      persisted: ref.watch(localeProvider),
      system: WidgetsBinding.instance.platformDispatcher.locale,
    );
    ref.watch(syncEngineProvider);
    // A session that ends or begins must never inherit the previous account's
    // data: these feature providers outlive the sign-out, so they are cleared
    // on every auth change. Without this, signing out and back in as another
    // customer in the same process shows the first account's vehicles,
    // bookings, invoices and profile until the next refresh.
    ref.listen<AuthState>(authNotifierProvider, (previous, next) {
      ref.invalidate(customerDashboardProvider);
      ref.invalidate(customerBookingsProvider);
      ref.invalidate(customerApprovalsProvider);
      ref.invalidate(customerInvoicesProvider);
    });
    // FE-FIX (pre-deployment): refresh on app-resume so cross-app changes
    // (booking confirmed, estimate awaiting approval, invoice ready) appear
    // as soon as the customer returns to the app.
    return ResumeRefreshScope(
      onResumed: () async {
        await ref.read(syncEngineProvider).syncAll();
        final notifier = ref.read(customerDashboardProvider.notifier);
        await notifier.refresh();
        ref.invalidate(customerBookingsProvider);
        ref.invalidate(customerApprovalsProvider);
      },
      child: AuthenticatedPushNotificationScope(
        // Push events: a foreground push refreshes canonical notification
        // state (the bell badge follows it), a tapped push opens the safe
        // destination for its category.
        child: CustomerPushScope(
          child: MaterialApp.router(
            debugShowCheckedModeBanner: false,
            routerConfig: router,
            title: brand.appName,
            onGenerateTitle: (context) =>
                CustomerLocalizations.of(context)?.appTitle ?? brand.appName,
            locale: effectiveLocale,
            supportedLocales: AppLocales.supported,
            localizationsDelegates: const [
              CustomerLocalizations.delegate,
              SharedCoreLocalizations.delegate,
              SharedAuthLocalizations.delegate,
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            theme: AppTheme.light(brand, locale: effectiveLocale),
            darkTheme: AppTheme.dark(brand, locale: effectiveLocale),
            themeMode: ThemeMode.light,
          ),
        ),
      ),
    );
  }
}
