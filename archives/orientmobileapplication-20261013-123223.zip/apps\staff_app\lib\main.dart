import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_core/shared_core.dart';
import 'package:shared_auth/shared_auth.dart';
import 'package:staff_app/core/local/sync_providers.dart';
import 'package:staff_app/core/router/app_router.dart';
import 'package:staff_app/features/advisor/presentation/providers/advisor_providers.dart';
import 'package:staff_app/features/common/presentation/providers/staff_attendance_provider.dart';
import 'package:staff_app/features/supervisor/presentation/providers/supervisor_providers.dart';
import 'package:staff_app/features/technician/presentation/providers/technician_providers.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await EnvironmentConfig.init();

  final logger = createLogger();
  AppErrorHandler.init(logger);

  await HiveRegistry.initHive();
  await recoverUnsyncedAdvisorIntakes();
  await PushNotificationService.instance.initialize();

  runApp(
    ProviderScope(
      overrides: [
        loggerProvider.overrideWithValue(logger),
        dioClientProvider.overrideWith((ref) {
          final dio = createDio(appName: 'staff');
          dio.interceptors.add(AuthInterceptor(ref, dio));
          return dio;
        }),
      ],
      child: const StaffApp(),
    ),
  );
}

class StaffApp extends ConsumerStatefulWidget {
  const StaffApp({super.key});

  @override
  ConsumerState<StaffApp> createState() => _StaffAppState();
}

class _StaffAppState extends ConsumerState<StaffApp> {
  StreamSubscription<List<ConnectivityResult>>? _connectivitySub;

  @override
  void initState() {
    super.initState();
    // Retry offline media uploads whenever connectivity returns.
    _connectivitySub = Connectivity().onConnectivityChanged.listen((
      results,
    ) async {
      final online = results.any((r) => r != ConnectivityResult.none);
      if (online) {
        final engine = ref.read(syncEngineProvider);
        await engine.syncAll();
        await engine.retryFailed();
        await flushPendingMediaUploads(ref);
        ref.read(advisorRefreshProvider.notifier).state++;
      }
    });
  }

  @override
  void dispose() {
    _connectivitySub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final router = ref.watch(appRouterProvider);
    final brand = ref.watch(brandConfigProvider);
    // Cross-account safety: when the session ends, drop the Technician role
    // providers so a different staff login can never see the previous user's
    // in-memory jobs or profile, and drop the shared attendance state so a
    // previous technician's punch state is never shown to the next user.
    // (Hive caches are cleared by logout itself.)
    ref.listen<AuthState>(authNotifierProvider, (previous, next) {
      if (next is! AuthAuthenticated) {
        ref.invalidate(technicianDashboardProvider);
        ref.invalidate(technicianRefreshProvider);
        ref.invalidate(staffAttendanceProvider);
      }
    });
    // FE-FIX (pre-deployment): on resume, refresh each role's live data so a
    // booking assigned by the supervisor appears immediately for the advisor
    // and a completed job shows up in the supervisor's review tab.
    return ResumeRefreshScope(
      onResumed: () async {
        final auth = ref.read(authNotifierProvider);
        if (auth is! AuthAuthenticated) return;
        switch (auth.role) {
          case UserRole.supervisor:
            final sup = ref.read(supervisorDashboardProvider.notifier);
            await sup.refreshQueue();
            await sup.refreshReview();
            await sup.loadNotifications();
          case UserRole.advisor:
            ref.read(advisorRefreshProvider.notifier).state++;
          case UserRole.technician:
            await ref.read(technicianDashboardProvider.notifier).refresh();
          default:
            return;
        }
      },
      child: AuthenticatedPushNotificationScope(
        child: MaterialApp.router(
          debugShowCheckedModeBanner: false,
          routerConfig: router,
          title: brand.appName,
          theme: AppTheme.light(brand),
        ),
      ),
    );
  }
}
