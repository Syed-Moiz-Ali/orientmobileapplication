import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive/hive.dart';
import 'package:shared_auth/shared_auth.dart';
import 'package:shared_core/shared_core.dart';
import 'package:staff_app/core/local/sync_providers.dart';
import 'package:staff_app/features/advisor/inspection_pages/data/models/inspection_model.dart';
import 'package:staff_app/features/advisor/inspection_pages/data/models/inspection_view_model.dart';
import 'package:staff_app/features/advisor/inspection_pages/data/models/vehicle_damage_map_model.dart';
import 'package:staff_app/features/advisor/data/datasources/advisor_providers.dart';
import 'package:staff_app/features/advisor/presentation/providers/advisor_providers.dart';

class InspectionState {
  final List<InspectionSection> sections;
  final Map<String, ItemStatus> statuses;
  final Map<String, bool> collapsed;
  final Map<String, ItemMedia> media;
  final bool notifyOwner;
  final String globalSearch;
  final Map<String, String> sectionSearch;
  final bool showAll;
  final List<String> preServicePhotos;
  final List<ServiceLineItem> serviceLines;
  final List<PartLineItem> partLines;
  final String referenceNumber;
  final String placeOfSupply;
  final String customerRequests;
  final String garageRecommendations;
  final DateTime? estimatedDelivery;
  final bool notifyOwnerSmsEmail;
  final String tag;
  final String jobCardId;
  final String bookingId;
  final Map<String, VehiclePartInspection> vehiclePartInspections;

  const InspectionState({
    this.sections = kInspectionSections,
    this.statuses = const {},
    this.collapsed = const {},
    this.media = const {},
    this.notifyOwner = false,
    this.globalSearch = '',
    this.sectionSearch = const {},
    this.showAll = true,
    this.preServicePhotos = const [],
    this.serviceLines = const [],
    this.partLines = const [],
    this.referenceNumber = '',
    this.placeOfSupply = '',
    this.customerRequests = '',
    this.garageRecommendations = '',
    this.estimatedDelivery,
    this.notifyOwnerSmsEmail = false,
    this.tag = '',
    this.jobCardId = '',
    this.bookingId = '',
    this.vehiclePartInspections = const {},
  });

  InspectionState copyWith({
    List<InspectionSection>? sections,
    Map<String, ItemStatus>? statuses,
    Map<String, bool>? collapsed,
    Map<String, ItemMedia>? media,
    bool? notifyOwner,
    String? globalSearch,
    Map<String, String>? sectionSearch,
    bool? showAll,
    List<String>? preServicePhotos,
    List<ServiceLineItem>? serviceLines,
    List<PartLineItem>? partLines,
    String? referenceNumber,
    String? placeOfSupply,
    String? customerRequests,
    String? garageRecommendations,
    DateTime? estimatedDelivery,
    bool? notifyOwnerSmsEmail,
    String? tag,
    String? jobCardId,
    String? bookingId,
    Map<String, VehiclePartInspection>? vehiclePartInspections,
  }) {
    return InspectionState(
      sections: sections ?? this.sections,
      statuses: statuses ?? this.statuses,
      collapsed: collapsed ?? this.collapsed,
      media: media ?? this.media,
      notifyOwner: notifyOwner ?? this.notifyOwner,
      globalSearch: globalSearch ?? this.globalSearch,
      sectionSearch: sectionSearch ?? this.sectionSearch,
      showAll: showAll ?? this.showAll,
      preServicePhotos: preServicePhotos ?? this.preServicePhotos,
      serviceLines: serviceLines ?? this.serviceLines,
      partLines: partLines ?? this.partLines,
      referenceNumber: referenceNumber ?? this.referenceNumber,
      placeOfSupply: placeOfSupply ?? this.placeOfSupply,
      customerRequests: customerRequests ?? this.customerRequests,
      garageRecommendations:
          garageRecommendations ?? this.garageRecommendations,
      estimatedDelivery: estimatedDelivery ?? this.estimatedDelivery,
      notifyOwnerSmsEmail: notifyOwnerSmsEmail ?? this.notifyOwnerSmsEmail,
      tag: tag ?? this.tag,
      jobCardId: jobCardId ?? this.jobCardId,
      bookingId: bookingId ?? this.bookingId,
      vehiclePartInspections:
          vehiclePartInspections ?? this.vehiclePartInspections,
    );
  }

  Map<String, dynamic> toPersistableMap() => {
    'templateSections': sections.map((section) => section.toJson()).toList(),
    'statuses': statuses.map((k, v) => MapEntry(k, v.name)),
    'sections': _sectionsPayload(),
    'media': media.map((k, v) => MapEntry(k, v.toJson())),
    'preServicePhotos': preServicePhotos,
    'serviceLines': serviceLines.map((e) => e.toJson()).toList(),
    'partLines': partLines.map((e) => e.toJson()).toList(),
    'referenceNumber': referenceNumber,
    'placeOfSupply': placeOfSupply,
    'customerRequests': customerRequests,
    'garageRecommendations': garageRecommendations,
    'estimatedDelivery': estimatedDelivery?.toIso8601String(),
    'notifyOwner': notifyOwner,
    'notifyOwnerSmsEmail': notifyOwnerSmsEmail,
    'tag': tag,
    'jobCardId': jobCardId,
    'bookingId': bookingId,
    'vehicleBodyCondition': vehicleBodyConditionPayload,
  };

  Map<String, dynamic> toLiveRequestMap() => {
    'sections': _sectionsPayload(),
    if (referenceNumber.isNotEmpty) 'referenceNumber': referenceNumber,
    if (placeOfSupply.isNotEmpty) 'placeOfSupply': placeOfSupply,
    if (customerRequests.isNotEmpty) 'customerRequests': customerRequests,
    if (garageRecommendations.isNotEmpty)
      'garageRecommendations': garageRecommendations,
    if (estimatedDelivery != null)
      'estimatedDelivery': estimatedDelivery!.toIso8601String(),
    'notifyOwnerSmsEmail': notifyOwner || notifyOwnerSmsEmail,
    if (tag.isNotEmpty) 'tag': tag,
    if (jobCardId.isNotEmpty) 'jobCardId': jobCardId,
    if (bookingId.isNotEmpty) 'bookingId': bookingId,
    if (vehiclePartInspections.isNotEmpty)
      'vehicleBodyCondition': vehicleBodyConditionPayload,
  };

  Map<String, dynamic> get vehicleBodyConditionPayload => {
    'mapId': 'advisor_car_top',
    'view': 'top',
    'parts': vehiclePartInspections.map(
      (partId, inspection) => MapEntry(partId, inspection.toJson()),
    ),
  };

  Map<String, dynamic> _sectionsPayload() {
    final payload = <String, dynamic>{};
    for (final section in sections) {
      final items = <String, dynamic>{};
      for (var index = 0; index < section.items.length; index++) {
        final status = statuses['${section.id}_$index'];
        if (status != null) {
          items[section.items[index]] = {'status': status.name};
        }
      }
      if (items.isNotEmpty) payload[section.id] = items;
    }
    return payload;
  }

  factory InspectionState.fromPersistableMap(Map<dynamic, dynamic> rawMap) {
    final map = _deepCastMap(rawMap);
    final statusesRaw = map['statuses'] as Map<String, dynamic>? ?? {};
    final mediaRaw = map['media'] as Map<String, dynamic>? ?? {};
    final serviceLinesRaw = map['serviceLines'] as List<dynamic>? ?? [];
    final partLinesRaw = map['partLines'] as List<dynamic>? ?? [];
    final templateSectionsRaw = map['templateSections'] as List<dynamic>? ?? [];
    final bodyRaw = map['vehicleBodyCondition'] is Map
        ? _deepCastMap(map['vehicleBodyCondition'] as Map)
        : const <String, dynamic>{};
    final bodyParts = bodyRaw['parts'] is Map
        ? _deepCastMap(bodyRaw['parts'] as Map)
        : const <String, dynamic>{};

    return InspectionState(
      sections: templateSectionsRaw.isEmpty
          ? kInspectionSections
          : templateSectionsRaw
                .whereType<Map>()
                .map(
                  (section) =>
                      InspectionSection.fromJson(_deepCastMap(section)),
                )
                .toList(),
      statuses: statusesRaw.map(
        (k, v) => MapEntry(
          k.toString(),
          ItemStatus.values.firstWhere(
            (e) => e.name == v?.toString(),
            orElse: () => ItemStatus.good,
          ),
        ),
      ),
      media: mediaRaw.map(
        (k, v) => MapEntry(
          k.toString(),
          v is Map ? ItemMedia.fromJson(_deepCastMap(v)) : const ItemMedia(),
        ),
      ),
      preServicePhotos:
          (map['preServicePhotos'] as List?)
              ?.map((e) => e.toString())
              .toList() ??
          [],
      serviceLines: serviceLinesRaw
          .whereType<Map>()
          .map((e) => ServiceLineItem.fromJson(_deepCastMap(e)))
          .toList(),
      partLines: partLinesRaw
          .whereType<Map>()
          .map((e) => PartLineItem.fromJson(_deepCastMap(e)))
          .toList(),
      referenceNumber: map['referenceNumber']?.toString() ?? '',
      placeOfSupply: map['placeOfSupply']?.toString() ?? '',
      customerRequests: map['customerRequests']?.toString() ?? '',
      garageRecommendations: map['garageRecommendations']?.toString() ?? '',
      estimatedDelivery: map['estimatedDelivery'] != null
          ? DateTime.tryParse(map['estimatedDelivery'].toString())
          : null,
      notifyOwnerSmsEmail: map['notifyOwnerSmsEmail'] as bool? ?? false,
      notifyOwner: map['notifyOwner'] as bool? ?? false,
      tag: map['tag']?.toString() ?? '',
      jobCardId: map['jobCardId']?.toString() ?? '',
      bookingId: map['bookingId']?.toString() ?? '',
      vehiclePartInspections: bodyParts.map(
        (partId, value) => MapEntry(
          partId,
          value is Map
              ? VehiclePartInspection.fromJson(_deepCastMap(value))
              : VehiclePartInspection(partId: partId),
        ),
      ),
    );
  }

  static Map<String, dynamic> _deepCastMap(Map<dynamic, dynamic> map) {
    return map.map((key, value) {
      if (value is Map) {
        return MapEntry(key.toString(), _deepCastMap(value));
      } else if (value is List) {
        return MapEntry(
          key.toString(),
          value.map((e) => e is Map ? _deepCastMap(e) : e).toList(),
        );
      }
      return MapEntry(key.toString(), value);
    });
  }

  int get totalItems =>
      sections.fold(0, (sum, section) => sum + section.items.length);

  int get completedCount => statuses.length;

  double get progressPercent =>
      totalItems == 0 ? 0 : completedCount / totalItems;

  double get servicesTotal => serviceLines.fold(0, (sum, s) => sum + s.amount);

  double get partsTotal => partLines.fold(0, (sum, p) => sum + p.amount);

  double get grandTotal => servicesTotal + partsTotal;

  List<InspectionSection> get filteredSections {
    return sections.map((sec) {
      final filtered = sec.items.where((item) {
        final g = item.toLowerCase().contains(globalSearch.toLowerCase());
        final s = item.toLowerCase().contains(
          (sectionSearch[sec.id] ?? '').toLowerCase(),
        );
        return g && s;
      }).toList();
      return InspectionSection(id: sec.id, label: sec.label, items: filtered);
    }).toList();
  }
}

class InspectionNotifier extends Notifier<InspectionState> {
  @override
  InspectionState build() {
    try {
      final local = ref.read(advisorLocalDataSourceProvider);
      final draft = local.getDraft();
      if (draft != null) {
        return InspectionState.fromPersistableMap(draft);
      }
    } catch (_) {}

    final box = Hive.box<dynamic>('inspections');
    final intakeBookingId = box.get('intake_booking_id')?.toString() ?? '';
    return InspectionState(bookingId: intakeBookingId);
  }

  void _persistDraft() {
    try {
      final local = ref.read(advisorLocalDataSourceProvider);
      local.saveDraft(state.toPersistableMap());
    } catch (_) {}
  }

  void setStatus(String itemId, ItemStatus? status) {
    final s = Map<String, ItemStatus>.from(state.statuses);
    if (status == null || s[itemId] == status) {
      s.remove(itemId);
    } else {
      s[itemId] = status;
    }
    state = state.copyWith(statuses: s);
    _persistDraft();
  }

  void toggleCollapse(String sectionId) {
    final c = Map<String, bool>.from(state.collapsed);
    c[sectionId] = !(c[sectionId] ?? false);
    state = state.copyWith(collapsed: c);
  }

  void setShowAll() {
    state = state.copyWith(showAll: true, collapsed: {});
  }

  void setCollapseAll() {
    final c = <String, bool>{};
    for (final s in state.sections) {
      c[s.id] = true;
    }
    state = state.copyWith(showAll: false, collapsed: c);
  }

  void setGlobalSearch(String q) {
    state = state.copyWith(globalSearch: q);
  }

  Future<void> loadDefaultTemplate() async {
    try {
      final template = await ref
          .read(advisorRemoteDataSourceProvider)
          .getDefaultInspectionTemplate();
      final sections = template.sections
          .where((section) => section.sectionKey.isNotEmpty)
          .map(
            (section) => InspectionSection(
              id: section.sectionKey,
              label: section.label,
              items: section.items,
            ),
          )
          .where((section) => section.items.isNotEmpty)
          .toList();
      if (sections.isEmpty) return;
      state = state.copyWith(sections: sections);
      _persistDraft();
    } catch (_) {
      // The bundled checklist remains available when offline or during rollout.
    }
  }

  void setSectionSearch(String sectionId, String q) {
    final ss = Map<String, String>.from(state.sectionSearch);
    ss[sectionId] = q;
    state = state.copyWith(sectionSearch: ss);
  }

  void toggleNotifyOwner() {
    state = state.copyWith(notifyOwner: !state.notifyOwner);
  }

  void addPhoto(String itemId, String path) {
    final im = state.media[itemId] ?? const ItemMedia();
    state = state.copyWith(
      media: {
        ...state.media,
        itemId: im.copyWith(photoPaths: [...im.photoPaths, path]),
      },
    );
    _persistDraft();
  }

  void addVideo(String itemId, String path) {
    final im = state.media[itemId] ?? const ItemMedia();
    state = state.copyWith(
      media: {
        ...state.media,
        itemId: im.copyWith(videoPaths: [...im.videoPaths, path]),
      },
    );
    _persistDraft();
  }

  void setAudio(String itemId, String path) {
    final im = state.media[itemId] ?? const ItemMedia();
    state = state.copyWith(
      media: {
        ...state.media,
        itemId: im.copyWith(audioPath: path),
      },
    );
    _persistDraft();
  }

  void setNote(String itemId, String note) {
    final im = state.media[itemId] ?? const ItemMedia();
    state = state.copyWith(
      media: {
        ...state.media,
        itemId: im.copyWith(note: note),
      },
    );
    _persistDraft();
  }

  void removePhoto(String itemId, int index) {
    final im = state.media[itemId];
    if (im == null) return;
    final photos = List<String>.from(im.photoPaths);
    if (index >= 0 && index < photos.length) {
      photos.removeAt(index);
    }
    state = state.copyWith(
      media: {
        ...state.media,
        itemId: im.copyWith(photoPaths: photos),
      },
    );
    _persistDraft();
  }

  void setMedia(String itemId, ItemMedia media) {
    state = state.copyWith(media: {...state.media, itemId: media});
    _persistDraft();
  }

  void setVehiclePartCondition(String partId, VehiclePartCondition condition) {
    final current =
        state.vehiclePartInspections[partId] ??
        VehiclePartInspection(partId: partId);
    state = state.copyWith(
      vehiclePartInspections: {
        ...state.vehiclePartInspections,
        partId: current.copyWith(condition: condition),
      },
    );
    _persistDraft();
  }

  void addVehicleDamageFinding(VehicleDamageFinding finding) {
    final current =
        state.vehiclePartInspections[finding.partId] ??
        VehiclePartInspection(partId: finding.partId);
    state = state.copyWith(
      vehiclePartInspections: {
        ...state.vehiclePartInspections,
        finding.partId: current.copyWith(
          findings: [...current.findings, finding],
        ),
      },
      media: finding.photos.isEmpty
          ? state.media
          : {
              ...state.media,
              'vehicle-damage:${finding.id}': ItemMedia(
                photoPaths: finding.photos,
              ),
            },
    );
    _persistDraft();
  }

  void updateVehicleDamageFinding(VehicleDamageFinding finding) {
    final current = state.vehiclePartInspections[finding.partId];
    if (current == null) return;
    final findings = current.findings
        .map((item) => item.id == finding.id ? finding : item)
        .toList();
    state = state.copyWith(
      vehiclePartInspections: {
        ...state.vehiclePartInspections,
        finding.partId: current.copyWith(findings: findings),
      },
      media: {
        ...state.media,
        'vehicle-damage:${finding.id}': ItemMedia(photoPaths: finding.photos),
      },
    );
    _persistDraft();
  }

  void removeVehicleDamageFinding(String partId, String findingId) {
    final current = state.vehiclePartInspections[partId];
    if (current == null) return;
    final media = Map<String, ItemMedia>.from(state.media)
      ..remove('vehicle-damage:$findingId');
    state = state.copyWith(
      vehiclePartInspections: {
        ...state.vehiclePartInspections,
        partId: current.copyWith(
          findings: current.findings
              .where((item) => item.id != findingId)
              .toList(),
        ),
      },
      media: media,
    );
    _persistDraft();
  }

  void removeVideo(String itemId, int index) {
    final im = state.media[itemId];
    if (im == null) return;
    final videos = List<String>.from(im.videoPaths);
    if (index >= 0 && index < videos.length) {
      videos.removeAt(index);
    }
    state = state.copyWith(
      media: {
        ...state.media,
        itemId: im.copyWith(videoPaths: videos),
      },
    );
    _persistDraft();
  }

  void addPreServicePhoto(String path) {
    state = state.copyWith(preServicePhotos: [...state.preServicePhotos, path]);
    _persistDraft();
  }

  void addServices(List<String> names) {
    final existing = state.serviceLines.map((s) => s.name).toSet();
    final lines = List<ServiceLineItem>.from(state.serviceLines);
    for (final n in names) {
      if (!existing.contains(n)) lines.add(ServiceLineItem(name: n));
    }
    lines.removeWhere((s) => !names.contains(s.name));
    state = state.copyWith(serviceLines: lines);
    _persistDraft();
  }

  void mergeGeneratedServices(List<ServiceLineItem> items) {
    if (items.isEmpty) return;
    final existing = state.serviceLines
        .map((s) => s.name.trim().toLowerCase())
        .toSet();
    final lines = List<ServiceLineItem>.from(state.serviceLines);
    for (final item in items) {
      final name = item.name.trim();
      if (name.isEmpty || existing.contains(name.toLowerCase())) continue;
      lines.add(item);
      existing.add(name.toLowerCase());
    }
    state = state.copyWith(serviceLines: lines);
    _persistDraft();
  }

  void addParts(List<String> names) {
    final existing = state.partLines.map((p) => p.name).toSet();
    final lines = List<PartLineItem>.from(state.partLines);
    for (final n in names) {
      if (!existing.contains(n)) lines.add(PartLineItem(name: n));
    }
    lines.removeWhere((p) => !names.contains(p.name));
    state = state.copyWith(partLines: lines);
    _persistDraft();
  }

  void updateServiceLine(
    int index, {
    int? qty,
    double? rate,
    double? discountPct,
    double? discountAmt,
  }) {
    if (index < 0 || index >= state.serviceLines.length) return;
    final lines = List<ServiceLineItem>.from(state.serviceLines);
    final s = lines[index];
    lines[index] = ServiceLineItem(
      name: s.name,
      qty: qty ?? s.qty,
      rate: rate ?? s.rate,
      discountPercent: discountPct ?? s.discountPercent,
      discountAmount: discountAmt ?? s.discountAmount,
    );
    state = state.copyWith(serviceLines: lines);
    _persistDraft();
  }

  void updatePartLine(
    int index, {
    int? qty,
    double? rate,
    double? discountPct,
    double? discountAmt,
  }) {
    if (index < 0 || index >= state.partLines.length) return;
    final lines = List<PartLineItem>.from(state.partLines);
    final p = lines[index];
    lines[index] = PartLineItem(
      name: p.name,
      qty: qty ?? p.qty,
      rate: rate ?? p.rate,
      discountPercent: discountPct ?? p.discountPercent,
      discountAmount: discountAmt ?? p.discountAmount,
    );
    state = state.copyWith(partLines: lines);
    _persistDraft();
  }

  void setReferenceNumber(String v) {
    state = state.copyWith(referenceNumber: v);
    _persistDraft();
  }

  void setPlaceOfSupply(String v) {
    state = state.copyWith(placeOfSupply: v);
    _persistDraft();
  }

  void setCustomerRequests(String v) {
    state = state.copyWith(customerRequests: v);
    _persistDraft();
  }

  void setGarageRecommendations(String v) {
    state = state.copyWith(garageRecommendations: v);
    _persistDraft();
  }

  void setEstimatedDelivery(DateTime dt) {
    state = state.copyWith(estimatedDelivery: dt);
    _persistDraft();
  }

  void toggleNotifyOwnerSmsEmail() {
    state = state.copyWith(notifyOwnerSmsEmail: !state.notifyOwnerSmsEmail);
    _persistDraft();
  }

  void setJobCardId(String v) {
    state = state.copyWith(jobCardId: v);
    _persistDraft();
  }

  void setTag(String v) {
    state = state.copyWith(tag: v);
    _persistDraft();
  }

  Future<Result<void>> submitInspection() async {
    final local = ref.read(advisorLocalDataSourceProvider);
    final queue = ref.read(syncQueueProvider);
    final id = await IdGenerator.nextId('INS');

    // An inspection must always belong to a real customer/vehicle/job card.
    // Without a job card there is no customer or vehicle context, so refuse to
    // persist an orphan inspection.
    if (state.jobCardId.trim().isEmpty) {
      return const Failure(
        UnknownException(
          'This inspection is not linked to a job card. Start the inspection '
          'from a saved job card so the customer and vehicle are known.',
        ),
      );
    }
    if (state.statuses.isEmpty) {
      return const Failure(
        UnknownException('Rate at least one checkpoint before submitting.'),
      );
    }

    final payload = state.toPersistableMap();
    await local.saveInspection(id, payload);

    try {
      final live = await ref
          .read(advisorRemoteDataSourceProvider)
          .createInspection(state.toLiveRequestMap());
      await uploadInspectionMedia(live.id.isNotEmpty ? live.id : id);
      await _saveNotes(live.id.isNotEmpty ? live.id : id);
      await local.deleteDraft();
      Hive.box<dynamic>('inspections').delete('intake_booking_id');
      ref.read(advisorRefreshProvider.notifier).state++;
      ref.read(advisorWorkItemsRefreshProvider.notifier).state++;
      return const Success(null);
    } catch (_) {
      // Offline or transient failure: keep the inspection durably and queue it
      // for replay. The job card id is part of the payload so the backend can
      // re-link the inspection to the correct customer and vehicle.
      final operation = SyncOperation(
        id: id,
        entityType: 'inspection',
        entityId: id,
        changeType: ChangeType.create,
        payload: payload,
        timestamp: DateTime.now().millisecondsSinceEpoch,
      );
      await queue.enqueue(operation);
      await uploadInspectionMedia(id);
      try {
        await ref.read(syncEngineProvider).syncAll();
      } catch (_) {}
      ref.read(advisorRefreshProvider.notifier).state++;
      ref.read(advisorWorkItemsRefreshProvider.notifier).state++;
      return const Success(null);
    }
  }

  /// Persists checkpoint notes to the backend so they are stored alongside the
  /// uploaded photos/videos/audio in the media index.
  Future<void> _saveNotes(String recordId) async {
    final items = <Map<String, String>>[];
    state.media.forEach((itemId, media) {
      final note = media.note.trim();
      if (note.isNotEmpty) items.add({'itemId': itemId, 'note': note});
    });
    if (items.isEmpty) return;
    try {
      await ref
          .read(advisorRemoteDataSourceProvider)
          .saveInspectionNotes(recordId, items);
    } catch (_) {
      // Notes are best-effort; the inspection itself already saved.
    }
  }

  Future<void> uploadInspectionMedia(String recordId) async {
    final uploads = <({String path, String itemId, String type})>[];
    for (final entry in state.media.entries) {
      final itemId = entry.key;
      final media = entry.value;
      uploads.addAll(
        media.photoPaths.map(
          (path) => (path: path, itemId: itemId, type: 'photo'),
        ),
      );
      uploads.addAll(
        media.videoPaths.map(
          (path) => (path: path, itemId: itemId, type: 'video'),
        ),
      );
      if (media.audioPath.isNotEmpty) {
        uploads.add((path: media.audioPath, itemId: itemId, type: 'audio'));
      }
    }
    for (final path in state.preServicePhotos) {
      uploads.add((path: path, itemId: 'pre-service', type: 'photo'));
    }
    if (uploads.isEmpty || kIsWeb) return;

    final mediaClient = MediaClient(ref.read(dioClientProvider));
    final pending = MediaUploadQueue(Hive.box<dynamic>('pending_media'));
    for (final upload in uploads) {
      try {
        await mediaClient.uploadMedia(
          recordId,
          upload.path,
          itemId: upload.itemId,
          type: upload.type,
          module: 'inspections',
        );
      } catch (_) {
        final pendingId = await IdGenerator.nextId('MED');
        await pending.enqueue(
          PendingMediaUpload(
            id: pendingId,
            recordId: recordId,
            filePath: upload.path,
            itemId: upload.itemId,
            type: upload.type,
            module: 'inspections',
            timestamp: DateTime.now().millisecondsSinceEpoch,
          ),
        );
      }
    }
  }

  void reset() {
    state = const InspectionState();
  }

  void res() {
    state = state.copyWith(
      statuses: {},
      globalSearch: '',
      showAll: true,
      tag: '',
      customerRequests: '',
    );
    _persistDraft();
  }
}

final inspectionProvider =
    NotifierProvider<InspectionNotifier, InspectionState>(
      InspectionNotifier.new,
    );
