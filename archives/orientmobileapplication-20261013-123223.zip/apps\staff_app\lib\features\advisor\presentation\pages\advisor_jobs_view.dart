import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_core/shared_core.dart';
import 'package:staff_app/core/router/app_router.dart';
import 'package:staff_app/features/advisor/domain/entities/job_card_entity.dart';
import 'package:staff_app/features/advisor/presentation/providers/advisor_providers.dart';
import 'package:staff_app/features/advisor/presentation/widgets/advisor_job_card_row.dart';

class AdvisorJobsListView extends ConsumerStatefulWidget {
  final void Function(JobCardEntity) onJobCard;
  const AdvisorJobsListView({super.key, required this.onJobCard});
  @override
  ConsumerState<AdvisorJobsListView> createState() =>
      _AdvisorJobsListViewState();
}

class _AdvisorJobsListViewState extends ConsumerState<AdvisorJobsListView> {
  final _searchCtrl = TextEditingController();
  final _filterChips = [
    'All',
    'In Progress',
    'Completed',
    'Pending',
    'QC Check',
    'Cancelled',
  ];

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final textTheme = theme.textTheme;

    final jobsAsync = ref.watch(advisorRecentJobCardsProvider);
    final bookingsAsync = ref.watch(advisorAssignedBookingsProvider);
    final jobCards = jobsAsync.value ?? const <JobCardEntity>[];
    final selectedFilter = ref.watch(_jobsFilterProvider);

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: colorScheme.surface,
        elevation: 0,
        scrolledUnderElevation: 0,
        title: Text(
          'Workshop Job Cards',
          style: textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w900,
            color: colorScheme.onSurface,
            letterSpacing: -0.3,
          ),
        ),
      ),
      body: Column(
        children: [
          if (jobsAsync.isLoading || bookingsAsync.isLoading)
            const LinearProgressIndicator(minHeight: 3),
          if (jobsAsync.hasError || bookingsAsync.hasError)
            _JobsDataNotice(
              onRetry: () {
                ref.invalidate(advisorRecentJobCardsProvider);
                ref.invalidate(advisorAssignedBookingsProvider);
              },
            ),
          // ── SEARCH FIELD ────────────────────────────────────────────────
          Container(
            color: colorScheme.surface,
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: AppSearchField(
              controller: _searchCtrl,
              hintText: 'Search by registration, customer, or ID...',
              onChanged: (v) => ref.read(_jobsSearchProvider.notifier).state = v,
              onClear: () => ref.read(_jobsSearchProvider.notifier).state = '',
            ),
          ),

          // ── FILTER CHIPS ─────────────────────────────────────────────────
          SizedBox(
            height: 38,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: _filterChips.map((f) {
                final active = f == selectedFilter;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: GestureDetector(
                    onTap: () {
                      HapticFeedback.selectionClick();
                      ref.read(_jobsFilterProvider.notifier).state = f;
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: active
                            ? colorScheme.primary
                            : colorScheme.surface,
                        borderRadius: BorderRadius.circular(100),
                        border: Border.all(
                          color: active
                              ? Colors.transparent
                              : colorScheme.outlineVariant,
                        ),
                      ),
                      child: Text(
                        f,
                        style: TextStyle(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w800,
                          color: active
                              ? colorScheme.onPrimary
                              : colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 8),

          Expanded(
            child: RefreshIndicator(
              color: colorScheme.primary,
              backgroundColor: colorScheme.surface,
              onRefresh: () async =>
                  ref.read(advisorRefreshProvider.notifier).state++,
              child: _buildJobList(jobCards, selectedFilter),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildJobList(List<JobCardEntity> allCards, String filter) {
    final query = ref.watch(_jobsSearchProvider).toLowerCase();
    final bookings =
        ref.watch(advisorAssignedBookingsProvider).value ??
        const <AdvisorBookingResponse>[];
    final showBookings =
        query.isEmpty && filter == 'All' && bookings.isNotEmpty;

    final filtered = allCards.where((jc) {
      final matchesFilter =
          filter == 'All' || _statusLabel(jc.status) == filter;
      final matchesSearch =
          query.isEmpty ||
          jc.id.toLowerCase().contains(query) ||
          jc.customerName.toLowerCase().contains(query) ||
          jc.vehicleInfo.toLowerCase().contains(query);
      return matchesFilter && matchesSearch;
    }).toList();

    if (filtered.isEmpty && !showBookings) {
      return const Center(
        child: EmptyState(
          icon: Icons.assignment_outlined,
          message: 'No matching job cards located',
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 90),
      itemCount: filtered.length + (showBookings ? 1 : 0),
      itemBuilder: (_, i) {
        if (showBookings && i == 0) {
          return _buildAssignedBookingsSection(bookings);
        }
        final index = showBookings ? i - 1 : i;
        if (index < 0 || index >= filtered.length) {
          return const SizedBox.shrink();
        }
        return AdvisorJobCardRow(jc: filtered[index], onTap: widget.onJobCard);
      },
    );
  }

  Widget _buildAssignedBookingsSection(List<AdvisorBookingResponse> bookings) {
    final colorScheme = Theme.of(context).colorScheme;

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: colorScheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.event_available_rounded,
                size: 18,
                color: colorScheme.primary,
              ),
              const SizedBox(width: 8),
              const Expanded(
                child: Text(
                  'Assigned intake queue',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                '${bookings.length} Pending',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  color: colorScheme.primary,
                  fontSize: 11,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ...bookings
              .take(3)
              .map(
                (b) => ListTile(
                  dense: true,
                  title: Text('${b.serviceType} · ${b.vehicleName}'),
                  subtitle: Text('${b.customerName} · ${b.bookingDate}'),
                  trailing: ElevatedButton(
                    onPressed: () {
                      context.push(
                        AppRoutes.advisorCheckIn,
                        extra: {
                          'bookingId': '${b.id}',
                          'customerName': b.customerName,
                          'vehicleInfo': b.vehicleName,
                        },
                      );
                    },
                    child: const Text('Check In'),
                  ),
                ),
              ),
        ],
      ),
    );
  }

  String _statusLabel(JobCardStatus s) => switch (s) {
    JobCardStatus.inProgress => 'In Progress',
    JobCardStatus.pendingApproval => 'Pending',
    JobCardStatus.completed => 'Completed',
    JobCardStatus.waitingParts => 'Waiting Parts',
    JobCardStatus.qualityCheck => 'QC Check',
    JobCardStatus.cancelled => 'Cancelled',
    JobCardStatus.pending => 'Pending',
    JobCardStatus.awaitingSupervisor => 'Awaiting Supervisor',
    JobCardStatus.vehicleReceived => 'Vehicle Received',
    JobCardStatus.inspected => 'Inspected',
    JobCardStatus.approved => 'Approved',
    JobCardStatus.workAssigned => 'Work Assigned',
    JobCardStatus.waitingCustomerApproval => 'Waiting Customer Approval',
    JobCardStatus.delivered => 'Delivered',
    JobCardStatus.qualityCheckPassed => 'QC Passed',
  };
}

final _jobsSearchProvider = StateProvider<String>((ref) => '');
final _jobsFilterProvider = StateProvider<String>((ref) => 'All');

class _JobsDataNotice extends StatelessWidget {
  final VoidCallback onRetry;

  const _JobsDataNotice({required this.onRetry});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      padding: const EdgeInsets.fromLTRB(13, 10, 8, 10),
      decoration: BoxDecoration(
        color: colors.errorContainer.withValues(alpha: 0.55),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Icon(
            Icons.cloud_off_rounded,
            color: colors.onErrorContainer,
            size: 20,
          ),
          const SizedBox(width: 9),
          Expanded(
            child: Text(
              'Some live workshop data could not be loaded.',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: colors.onErrorContainer,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          IconButton(
            tooltip: 'Retry',
            onPressed: onRetry,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
    );
  }
}
