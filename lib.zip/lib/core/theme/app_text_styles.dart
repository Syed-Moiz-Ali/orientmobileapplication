import 'package:flutter/material.dart';

class AppTextStyles {
  AppTextStyles._();

  // ── ORBITRON — Headings & Titles ──────────────────

  static TextStyle orbitronDisplayLarge({Color? color}) => TextStyle(
        fontFamily: 'Orbitron',
        fontSize: 32,
        fontWeight: FontWeight.w900,
        letterSpacing: 3.0,
        color: color,
      );

  static TextStyle orbitronDisplayMedium({Color? color}) => TextStyle(
        fontFamily: 'Orbitron',
        fontSize: 24,
        fontWeight: FontWeight.w700,
        letterSpacing: 2.0,
        color: color,
      );

  static TextStyle orbitronDisplaySmall({Color? color}) => TextStyle(
        fontFamily: 'Orbitron',
        fontSize: 18,
        fontWeight: FontWeight.w700,
        letterSpacing: 1.5,
        color: color,
      );

  /// KPI numbers, job card numbers
  static TextStyle orbitronKpiNumber({Color? color}) => TextStyle(
        fontFamily: 'Orbitron',
        fontSize: 40,
        fontWeight: FontWeight.w900,
        letterSpacing: 1.0,
        color: color,
      );

  /// Sub-section headings, badges
  static TextStyle orbitronHeadline({Color? color}) => TextStyle(
        fontFamily: 'Orbitron',
        fontSize: 14,
        fontWeight: FontWeight.w700,
        letterSpacing: 2.5,
        color: color,
      );

  // ── RAJDHANI — Body Text & Labels ─────────────────

  /// "SUPERVISOR PORTAL" — prominent UI labels
  static TextStyle rajdhaniTitle({Color? color}) => TextStyle(
        fontFamily: 'Rajdhani',
        fontSize: 20,
        fontWeight: FontWeight.w700,
        letterSpacing: 1.2,
        color: color,
      );

  /// Table headers, section labels
  static TextStyle rajdhaniLabel({Color? color}) => TextStyle(
        fontFamily: 'Rajdhani',
        fontSize: 14,
        fontWeight: FontWeight.w600,
        letterSpacing: 1.0,
        color: color,
      );

  /// Navigation items, button text
  static TextStyle rajdhaniButton({Color? color}) => TextStyle(
        fontFamily: 'Rajdhani',
        fontSize: 16,
        fontWeight: FontWeight.w600,
        letterSpacing: 1.5,
        color: color,
      );

  /// Body descriptions, field labels
  static TextStyle rajdhaniBody({Color? color}) => TextStyle(
        fontFamily: 'Rajdhani',
        fontSize: 15,
        fontWeight: FontWeight.w500,
        letterSpacing: 0.3,
        color: color,
      );

  /// Secondary descriptions, hints
  static TextStyle rajdhaniBodySmall({Color? color}) => TextStyle(
        fontFamily: 'Rajdhani',
        fontSize: 13,
        fontWeight: FontWeight.w400,
        letterSpacing: 0.2,
        color: color,
      );

  /// Form field input text
  static TextStyle rajdhaniInput({Color? color}) => TextStyle(
        fontFamily: 'Rajdhani',
        fontSize: 16,
        fontWeight: FontWeight.w500,
        letterSpacing: 0.4,
        color: color,
      );

  // ── JETBRAINS MONO — Technical Data ───────────────

  /// Dates
  static TextStyle monoDate({Color? color}) => TextStyle(
        fontFamily: 'JetBrainsMono',
        fontSize: 13,
        fontWeight: FontWeight.w400,
        letterSpacing: 0.5,
        color: color,
      );

  /// Time values, durations
  static TextStyle monoTime({Color? color}) => TextStyle(
        fontFamily: 'JetBrainsMono',
        fontSize: 15,
        fontWeight: FontWeight.w500,
        letterSpacing: 0.5,
        color: color,
      );

  /// Metric values, sensor readings
  static TextStyle monoMetric({Color? color}) => TextStyle(
        fontFamily: 'JetBrainsMono',
        fontSize: 18,
        fontWeight: FontWeight.w600,
        letterSpacing: 0.8,
        color: color,
      );

  /// IDs, codes, reference numbers
  static TextStyle monoCode({Color? color}) => TextStyle(
        fontFamily: 'JetBrainsMono',
        fontSize: 12,
        fontWeight: FontWeight.w400,
        letterSpacing: 1.0,
        color: color,
      );

  /// Table number cells
  static TextStyle monoTable({Color? color}) => TextStyle(
        fontFamily: 'JetBrainsMono',
        fontSize: 13,
        fontWeight: FontWeight.w500,
        letterSpacing: 0.3,
        color: color,
      );
}