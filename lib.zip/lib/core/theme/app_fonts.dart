// typography/app_fonts.dart

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// ─────────────────────────────────────────
// FONT FAMILIES
// ─────────────────────────────────────────

class AppFonts {
  AppFonts._();

  static const String orbitron = 'Orbitron';
  static const String rajdhani = 'Rajdhani';
  static const String jetBrainsMono = 'JetBrains Mono';
}

// ─────────────────────────────────────────
// TEXT STYLES
// ─────────────────────────────────────────

class AppTextStyles {
  AppTextStyles._();

  // ── ORBITRON — Headings & Titles ──────────────────

  /// e.g. "SUPERVISOR DASHBOARD", "AUTO GARAGE"
  static TextStyle orbitronDisplayLarge({Color? color}) => GoogleFonts.orbitron(
    fontSize: 32,
    fontWeight: FontWeight.w800,
    letterSpacing: 3.0,
    color: color,
  );

  /// e.g. Page titles, section headings
  static TextStyle orbitronDisplayMedium({Color? color}) =>
      GoogleFonts.orbitron(
        fontSize: 24,
        fontWeight: FontWeight.w700,
        letterSpacing: 2.0,
        color: color,
      );

  /// e.g. Card titles, KPI labels
  static TextStyle orbitronDisplaySmall({Color? color}) => GoogleFonts.orbitron(
    fontSize: 18,
    fontWeight: FontWeight.w800,
    letterSpacing: 1.5,
    color: color,
  );

  /// e.g. KPI numbers, job card numbers
  static TextStyle orbitronKpiNumber({Color? color}) => GoogleFonts.orbitron(
    fontSize: 40,
    fontWeight: FontWeight.w900,
    letterSpacing: 1.0,
    color: color,
  );

  /// e.g. Sub-section headings
  static TextStyle orbitronHeadline({Color? color}) => GoogleFonts.orbitron(
    fontSize: 14,
    fontWeight: FontWeight.w700,
    letterSpacing: 2.5,
    color: color,
  );

  // ── RAJDHANI — Body Text & Labels ─────────────────

  /// e.g. "SUPERVISOR PORTAL" — prominent UI labels
  static TextStyle rajdhaniTitle({Color? color}) => GoogleFonts.rajdhani(
    fontSize: 20,
    fontWeight: FontWeight.w700,
    letterSpacing: 1.2,
    color: color,
  );

  /// e.g. Table headers, section labels
  static TextStyle rajdhaniLabel({Color? color}) => GoogleFonts.rajdhani(
    fontSize: 14,
    fontWeight: FontWeight.w600,
    letterSpacing: 1.0,
    color: color,
  );

  /// e.g. Navigation items, button text
  static TextStyle rajdhaniButton({Color? color}) => GoogleFonts.rajdhani(
    fontSize: 16,
    fontWeight: FontWeight.w600,
    letterSpacing: 1.5,
    color: color,
  );

  /// e.g. Body descriptions, field labels
  static TextStyle rajdhaniBody({Color? color}) => GoogleFonts.rajdhani(
    fontSize: 15,
    fontWeight: FontWeight.w800,
    letterSpacing: 0.3,
    color: color,
  );

  /// e.g. Secondary descriptions, hints
  static TextStyle rajdhaniBodySmall({Color? color}) => GoogleFonts.rajdhani(
    fontSize: 13,
    fontWeight: FontWeight.w600,
    letterSpacing: 0.2,
    color: color,
  );

  /// e.g. Form field input text
  static TextStyle rajdhaniInput({Color? color}) => GoogleFonts.rajdhani(
    fontSize: 16,
    //fontWeight: FontWeight.w400,
    letterSpacing: 0.4,
    color: color,
  );

  // ── JETBRAINS MONO — Technical Data ───────────────

  /// e.g. Dates, timestamps
  static TextStyle monoDate({Color? color}) => GoogleFonts.jetBrainsMono(
    fontSize: 13,
    fontWeight: FontWeight.w600,
    letterSpacing: 0.5,
    color: color,
  );

  /// e.g. Time values, durations
  static TextStyle monoTime({Color? color}) => GoogleFonts.jetBrainsMono(
    fontSize: 15,
    fontWeight: FontWeight.w600,
    letterSpacing: 0.5,
    color: color,
  );

  /// e.g. Metric values, sensor readings
  static TextStyle monoMetric({Color? color}) => GoogleFonts.jetBrainsMono(
    fontSize: 18,
    fontWeight: FontWeight.w600,
    letterSpacing: 0.8,
    color: color,
  );

  /// e.g. IDs, codes, reference numbers
  static TextStyle monoCode({Color? color}) => GoogleFonts.jetBrainsMono(
    fontSize: 12,
    fontWeight: FontWeight.w600,
    letterSpacing: 1.0,
    color: color,
  );

  /// e.g. Table number cells
  static TextStyle monoTable({Color? color}) => GoogleFonts.jetBrainsMono(
    fontSize: 13,
    fontWeight: FontWeight.w600,
    letterSpacing: 0.3,
    color: color,
  );
}

// ─────────────────────────────────────────
// THEME INTEGRATION — plug into ThemeData
// ─────────────────────────────────────────

class AppTypography {
  AppTypography._();

  static TextTheme get textTheme => TextTheme(
    // Display → Orbitron (page titles, KPI headings)
    displayLarge: AppTextStyles.orbitronDisplayLarge(),
    displayMedium: AppTextStyles.orbitronDisplayMedium(),
    displaySmall: AppTextStyles.orbitronDisplaySmall(),

    // Headline → Rajdhani (section labels, nav items)
    headlineLarge: AppTextStyles.rajdhaniTitle(),
    headlineMedium: AppTextStyles.rajdhaniLabel(),
    headlineSmall: AppTextStyles.rajdhaniButton(),

    // Title → Rajdhani (card titles, form headers)
    titleLarge: AppTextStyles.rajdhaniTitle(),
    titleMedium: AppTextStyles.rajdhaniLabel(),
    titleSmall: AppTextStyles.rajdhaniBodySmall(),

    // Body → Rajdhani (descriptions, field values)
    bodyLarge: AppTextStyles.rajdhaniBody(),
    bodyMedium: AppTextStyles.rajdhaniBodySmall(),
    bodySmall: AppTextStyles.rajdhaniBodySmall(),

    // Label → JetBrains Mono (technical data, codes)
    labelLarge: AppTextStyles.monoTime(),
    labelMedium: AppTextStyles.monoDate(),
    labelSmall: AppTextStyles.monoCode(),
  );
}
