// lib/core/constants/app_colors.dart
import 'package:flutter/material.dart';

// ── Backgrounds ──────────────────────────────────────────────────
const Color kBg      = Color(0xFFF4F6FA);   // page background
const Color kSurface = Color(0xFFFFFFFF);   // card / top-bar surface

// ── Borders ──────────────────────────────────────────────────────
const Color kBorder   = Color(0xFFE4E7EE);  // subtle border
const Color kBorderMd = Color(0xFFCDD1DB);  // medium border (dashed outlines)

// ── Text ─────────────────────────────────────────────────────────
const Color kText  = Color(0xFF0F172A);     // primary text
const Color kText2 = Color(0xFF334155);     // secondary text
const Color kText3 = Color(0xFF64748B);     // tertiary / hint text
const Color kText4 = Color(0xFF94A3B8);     // disabled / placeholder text

// ── Blue (primary) ───────────────────────────────────────────────
const Color kBlue       = Color(0xFF2563EB);
const Color kBlueBg     = Color(0xFFEFF6FF);
const Color kBlueText   = Color(0xFF2563EB);
const Color kBlueBorder = Color(0xFFBFDBFE);

// ── Green ────────────────────────────────────────────────────────
const Color kGreen       = Color(0xFF16A34A);
const Color kGreenBg     = Color(0xFFF0FDF4);
const Color kGreenBorder = Color(0xFFBBF7D0);

// ── Red ──────────────────────────────────────────────────────────
const Color kRed       = Color(0xFFDC2626);
const Color kRedBg     = Color(0xFFFEF2F2);
const Color kRedBorder = Color(0xFFFECACA);

// ── Amber ────────────────────────────────────────────────────────
const Color kAmber       = Color(0xFFD97706);
const Color kAmberBg     = Color(0xFFFFFBEB);
const Color kAmberBorder = Color(0xFFFDE68A);

// ── Purple ───────────────────────────────────────────────────────
const Color kPurple       = Color(0xFF7C3AED);
const Color kPurpleBg     = Color(0xFFF5F3FF);
const Color kPurpleBorder = Color(0xFFDDD6FE);

// ── Time slots (used in CustomerBookServiceView) ─────────────────
const List<String> kTimeSlots = [
  '08:00 AM', '09:00 AM', '10:00 AM', '11:00 AM',
  '12:00 PM', '01:00 PM', '02:00 PM', '03:00 PM',
  '04:00 PM', '05:00 PM',
];