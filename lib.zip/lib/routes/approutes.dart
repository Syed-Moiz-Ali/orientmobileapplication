import 'package:go_router/go_router.dart';
import 'package:orientmobileapplication/advisor_dashboard/advisor_home_view.dart';
import 'package:orientmobileapplication/advisor_dashboard/inspectionpages/choose_inspection_view.dart';
import 'package:orientmobileapplication/features/crm_dasboard/crm_dasboard_view.dart';
import 'package:orientmobileapplication/features/customer/view/customer_dashboard_view.dart';
import 'package:orientmobileapplication/features/dashboard/view/dashboard_view.dart';
import 'package:orientmobileapplication/features/dashboardmenu/accountsreceivableview.dart';
import 'package:orientmobileapplication/features/dashboardmenu/documentexpiryview.dart';
import 'package:orientmobileapplication/features/dashboardmenu/job_status_view.dart';
import 'package:orientmobileapplication/features/dashboardmenu/pendingapprovalsview.dart';
import 'package:orientmobileapplication/features/job_cards/model/job_card_model.dart';
import 'package:orientmobileapplication/features/job_cards/view/job_card_detail_view.dart';
import 'package:orientmobileapplication/features/role_selection/role_selection_view.dart';
import 'package:orientmobileapplication/features/supervisor/supervisor_dashboard_view.dart';
import 'package:orientmobileapplication/routes/navigatorservice.dart';

class Approutes {
  static const String roleselectionscreen = '/role_selection_view';
  static const String ownerDashboard = '/owner-dashboard';
  static const String advisordashboard = '/advisor_home_view';
  static const String customerportal = '/customer_dashboard_view';
  static const String jobcardportal = '/job_card_detail_view';
  static const String accountrecievale = '/accounts_receivable_view';
  static const String pendingapprovals = '/pending_approvals_view';
  static const String documentexpiry = '/document_expiry_view';
  static const String chooseinspectionview = '/choose_inspection_view';
  static const String superisordashboard = '/supervisor_dashboard_view';
  static const String jobstatuscard = '/job_status_view';
  static const String crmdashboardview = '/crm_dashboard_view';
}

final GoRouter routes = GoRouter(
  navigatorKey: NavigatorService.navigatorKey,
  initialLocation: Approutes.roleselectionscreen,
  routes: [
    GoRoute(
      path: Approutes.roleselectionscreen,
      name: Approutes.roleselectionscreen,
      builder: (context, state) => const RoleSelectionView(),
    ),

    GoRoute(
      path: Approutes.ownerDashboard,
      name: Approutes.ownerDashboard,
      builder: (context, state) => const DashboardView(),
    ),

    // ── Advisor → AdvisorHomeView (new design) ──────────────────────────
    GoRoute(
      path: Approutes.advisordashboard,
      name: Approutes.advisordashboard,
      builder: (context, state) => const AdvisorHomeView(),
    ),

    GoRoute(
      path: Approutes.customerportal,
      name: Approutes.customerportal,
      builder: (context, state) => const CustomerDashboardView(),
    ),

    GoRoute(
      path: Approutes.jobcardportal,
      name: Approutes.jobcardportal,
      builder: (context, state) =>
          JobCardDetailView(jobCard: state.extra as JobCardModel),
    ),

    GoRoute(
      path: Approutes.accountrecievale,
      name: Approutes.accountrecievale,
      builder: (context, state) => const AccountsReceivableView(),
    ),

    GoRoute(
      path: Approutes.pendingapprovals,
      name: Approutes.pendingapprovals,
      builder: (context, state) => const PendingApprovalsView(),
    ),

    GoRoute(
      path: Approutes.documentexpiry,
      name: Approutes.documentexpiry,
      builder: (context, state) => const DocumentExpiryView(),
    ),
    GoRoute(
      path: Approutes.chooseinspectionview,
      name: Approutes.chooseinspectionview,
      builder: (context, state) =>
          ChooseInspectionView(onSelect: () {}, onSkip: () {}, onBack: () {}),
    ),
    GoRoute(
      path: Approutes.superisordashboard,
      name: Approutes.superisordashboard,
      builder: (context, state) => const SupervisorDashboardView(),
    ),
    GoRoute(
      path: Approutes.jobstatuscard,
      name: Approutes.jobstatuscard,
      builder: (context, state) => const JobStatusView(),
    ),

    GoRoute(
      path: Approutes.crmdashboardview,
      name: Approutes.crmdashboardview,
      builder: (context, state) => const CrmDashboardView(),
    ),
  ],
);
