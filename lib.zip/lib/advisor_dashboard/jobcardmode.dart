enum JobCardStatus {
  inProgress,
  pendingApproval,
  completed,
  waitingParts,
  qualityCheck,
  cancelled,
}

class JobCardMode {
  final String id;
  final String customerName;
  final String vehicleInfo;
  final String time;
  final JobCardStatus status;

  const JobCardMode({
    required this.id,
    required this.customerName,
    required this.vehicleInfo,
    required this.time,
    required this.status,
  });

  static const List<JobCardMode> mock = [
    JobCardMode(
      id: 'JC-2024-089',
      customerName: 'Ahmed Hassan',
      vehicleInfo: 'Toyota Camry • D-12345',
      time: '09:15 AM',
      status: JobCardStatus.inProgress,
    ),
    JobCardMode(
      id: 'JC-2024-088',
      customerName: 'Fatima Ali',
      vehicleInfo: 'Honda Accord • D-67890',
      time: '08:45 AM',
      status: JobCardStatus.pendingApproval,
    ),
    JobCardMode(
      id: 'JC-2024-087',
      customerName: 'Khalid Rashid',
      vehicleInfo: 'Nissan Patrol • D-11223',
      time: '08:00 AM',
      status: JobCardStatus.qualityCheck,
    ),
  ];
}
