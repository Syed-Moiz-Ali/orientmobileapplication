class PendingApprovalModel {
  final String estimateId;
  final String customerName;
  final String vehicleId;
  final double amount;
  final String timeAgo;

  const PendingApprovalModel({
    required this.estimateId,
    required this.customerName,
    required this.vehicleId,
    required this.amount,
    required this.timeAgo,
  });

  static const List<PendingApprovalModel> mock = [
    PendingApprovalModel(
      estimateId: 'EST-2024-089',
      customerName: 'Ahmed Hassan',
      vehicleId: 'D-12345',
      amount: 1250,
      timeAgo: '10 mins ago',
    ),
    PendingApprovalModel(
      estimateId: 'EST-2024-088',
      customerName: 'Sara Mohammed',
      vehicleId: 'D-44321',
      amount: 875,
      timeAgo: '25 mins ago',
    ),
  ];
}
