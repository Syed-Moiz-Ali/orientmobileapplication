enum ReminderPriority { high, medium, low }

class FollowupReminderModel {
  final String customerName;
  final String vehicleId;
  final String task;
  final String dueDate;
  final ReminderPriority priority;

  const FollowupReminderModel({
    required this.customerName,
    required this.vehicleId,
    required this.task,
    required this.dueDate,
    required this.priority,
  });

  static const List<FollowupReminderModel> mock = [
    FollowupReminderModel(
      customerName: 'Ahmed Hassan',
      vehicleId: 'D-12345',
      task: 'Follow up on estimate approval',
      dueDate: 'Due: Today, 2:00 PM',
      priority: ReminderPriority.high,
    ),
    FollowupReminderModel(
      customerName: 'Mariam Salem',
      vehicleId: 'D-44556',
      task: 'Notify when parts arrive',
      dueDate: 'Due: Tomorrow, 10:00 AM',
      priority: ReminderPriority.medium,
    ),
    FollowupReminderModel(
      customerName: 'Omar Khalid',
      vehicleId: 'D-99001',
      task: 'Schedule next service',
      dueDate: 'Due: Apr 10, 2024',
      priority: ReminderPriority.low,
    ),
  ];
}
