import 'package:flutter/material.dart';
import 'jobcardmode.dart';
import 'pending_approval_model.dart';
import 'followup_reminder_model.dart';

class AdvisorStats {
  final int newJobCardsToday;
  final int inspectionsToday;
  final int pendingApprovals;
  final int vehiclesWaiting;
  final int readyForDelivery;
  final int totalOpenJobCards;

  const AdvisorStats({
    required this.newJobCardsToday,
    required this.inspectionsToday,
    required this.pendingApprovals,
    required this.vehiclesWaiting,
    required this.readyForDelivery,
    required this.totalOpenJobCards,
  });
}

class AdvisorDashboardViewModel extends ChangeNotifier {
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  String _error = '';
  String get error => _error;

  String get advisorName => 'Ali Rahman';
  String get advisorId => 'ADV001';
  String get branch => 'Main Branch - Dubai';
  String get shift => 'Morning (8:00 AM - 5:00 PM)';

  AdvisorStats get stats => const AdvisorStats(
        newJobCardsToday: 12,
        inspectionsToday: 8,
        pendingApprovals: 5,
        vehiclesWaiting: 3,
        readyForDelivery: 7,
        totalOpenJobCards: 23,
      );

  List<JobCardMode> get recentJobCards => JobCardMode.mock;
  List<PendingApprovalModel> get pendingApprovals => PendingApprovalModel.mock;
  List<FollowupReminderModel> get followupReminders => FollowupReminderModel.mock;

  Future<void> loadDashboard() async {
    _isLoading = true;
    _error = '';
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 600));
    _isLoading = false;
    notifyListeners();
  }

  void onNewJobCard() {}
  void onNewInspection() {}
  void onViewAllJobCards() {}
  void onViewAllApprovals() {}
  void onContactReminder(FollowupReminderModel r) {}
}