// ─────────────────────────────────────────────────────────────────────────────
//  HOW TO WIRE INSPECTION INTO AdvisorHomeView
//  Add these two helpers to _AdvisorHomeViewState
// ─────────────────────────────────────────────────────────────────────────────
//
//  STEP 1 ── Import the inspection pages at the top of advisor_home_view.dart
//
//    import 'inspectionpages/choose_inspection_view.dart';
//    import 'inspectionpages/inspection_sheet_view.dart';
//    import 'inspectionpages/inspection_vew_model.dart';
//
//
//  STEP 2 ── Add these two methods inside _AdvisorHomeViewState:
//
//   // ── Open inspection from New Job Card flow ──────────────────────────
//   void _openChooseInspection() {
//     HapticFeedback.mediumImpact();
//     Navigator.of(context).push(MaterialPageRoute(
//       builder: (_) => ChooseInspectionView(
//         onBack: () => Navigator.pop(context),
//         onSkip: () {
//           // Skip → go straight to repair/job card
//           Navigator.pop(context);
//           _openNewJobCard();
//         },
//         onSelect: () {
//           // Replace ChooseInspection with the actual sheet
//           Navigator.of(context).pushReplacement(MaterialPageRoute(
//             builder: (_) => InspectionSheetView(
//               onSaveDraft: () {
//                 Navigator.pop(context);
//                 _toast('Draft saved', icon: Icons.save_outlined, color: _kAmber);
//               },
//               onPreview: () {
//                 Navigator.of(context).push(MaterialPageRoute(
//                   builder: (_) => const InspectionPreviewView(),
//                 ));
//               },
//             ),
//           ));
//         },
//       ),
//     ));
//   }
//
//   // ── Open inspection sheet directly (from home "Inspection" button) ──
//   void _openInspectionDirect() {
//     HapticFeedback.mediumImpact();
//     Navigator.of(context).push(MaterialPageRoute(
//       builder: (_) => InspectionSheetView(
//         onSaveDraft: () {
//           Navigator.pop(context);
//           _toast('Draft saved', icon: Icons.save_outlined, color: _kAmber);
//         },
//         onPreview: () {
//           Navigator.of(context).push(MaterialPageRoute(
//             builder: (_) => const InspectionPreviewView(),
//           ));
//         },
//       ),
//     ));
//   }
//
//
//  STEP 3 ── In _openNewJobCard(), replace the direct navigation with:
//
//   void _openNewJobCard() {
//     // First show inspection choice, then VehicleCustomerView
//     _openChooseInspection();
//   }
//
//
//  STEP 4 ── In _header(), add an "Inspection" button next to New Job Card.
//            Replace the single _NavyBtn with a Row of two:
//
//   Padding(
//     padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
//     child: Row(children: [
//       Expanded(child: _NavyBtn(
//         label: '+ New Job Card', isPrimary: true,
//         onTap: () { HapticFeedback.mediumImpact(); _openNewJobCard(); },
//       )),
//       const SizedBox(width: 10),
//       Expanded(child: _NavyBtn(
//         label: 'Inspection',
//         icon: Icons.assignment_turned_in_outlined,
//         isPrimary: false,
//         onTap: () => _openInspectionDirect(),
//       )),
//     ]),
//   ),
//
//
//  STEP 5 ── InspectionViewModel is already registered in main.dart providers.
//            Make sure it wraps the InspectionSheetView context. If you use
//            nested providers, wrap InspectionSheetView:
//
//   Navigator.of(context).push(MaterialPageRoute(
//     builder: (_) => ChangeNotifierProvider.value(
//       value: context.read<InspectionViewModel>(),
//       child: const InspectionSheetView(),
//     ),
//   ));
//
// ─────────────────────────────────────────────────────────────────────────────
//  COMPLETE COPY-PASTE SNIPPETS BELOW
// ─────────────────────────────────────────────────────────────────────────────

// Replace _openNewJobCard in _AdvisorHomeViewState with:
/*
  void _openNewJobCard() => _openChooseInspection();

  void _openChooseInspection() {
    HapticFeedback.mediumImpact();
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => ChangeNotifierProvider.value(
        value: context.read<InspectionViewModel>(),
        child: ChooseInspectionView(
          onBack: () => Navigator.pop(context),
          onSkip: () {
            Navigator.pop(context);
            Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const VehicleCustomerView()));
          },
          onSelect: () {
            Navigator.of(context).pushReplacement(MaterialPageRoute(
              builder: (_) => ChangeNotifierProvider.value(
                value: context.read<InspectionViewModel>(),
                child: InspectionSheetView(
                  onSaveDraft: () {
                    Navigator.pop(context);
                    _toast('Draft saved',
                        icon: Icons.save_outlined, color: _kAmber);
                  },
                  onPreview: () => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => ChangeNotifierProvider.value(
                        value: context.read<InspectionViewModel>(),
                        child: const InspectionPreviewView(),
                      ),
                    ),
                  ),
                ),
              ),
            ));
          },
        ),
      ),
    ));
  }

  void _openInspectionDirect() {
    HapticFeedback.mediumImpact();
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => ChangeNotifierProvider.value(
        value: context.read<InspectionViewModel>(),
        child: InspectionSheetView(
          onSaveDraft: () {
            Navigator.pop(context);
            _toast('Draft saved', icon: Icons.save_outlined, color: _kAmber);
          },
          onPreview: () => Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => ChangeNotifierProvider.value(
                value: context.read<InspectionViewModel>(),
                child: const InspectionPreviewView(),
              ),
            ),
          ),
        ),
      ),
    ));
  }
*/
