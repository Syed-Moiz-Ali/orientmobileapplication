// import 'package:flutter/material.dart';

// class AdvisorAppBar extends StatelessWidget implements PreferredSizeWidget {
//   final String advisorName;
//   final String advisorId;
//   final String branch;
//   final String? shift;
//   final List<Widget>? extraActions;

//   const AdvisorAppBar({
//     super.key,
//     required this.advisorName,
//     required this.advisorId,
//     required this.branch,
//     this.shift,
//     this.extraActions,
//   });

//   @override
//   Size get preferredSize =>
//       Size.fromHeight(shift != null ? kToolbarHeight + 36 : kToolbarHeight);

//   @override
//   Widget build(BuildContext context) {
//     return AppBar(
//       backgroundColor: Colors.white,
//       elevation: 0,
//       titleSpacing: 0,
//       leadingWidth: 0,
//       leading: const SizedBox.shrink(),
//       title: Padding(
//         padding: const EdgeInsets.symmetric(horizontal: 16),
//         child: Row(
//           children: [
//             // Brand
//             Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: const [
//                 Text('Auto Garage ERP',
//                     style: TextStyle(
//                         fontSize: 15,
//                         fontWeight: FontWeight.w700,
//                         color: Color(0xFF1A1A2E))),
//                 Text('Service Advisor Portal',
//                     style:
//                         TextStyle(fontSize: 11, color: Color(0xFF8A94A6))),
//               ],
//             ),
//             // Branch separator
//             Container(
//               margin: const EdgeInsets.symmetric(horizontal: 16),
//               width: 1,
//               height: 28,
//               color: const Color(0xFFE5E7EB),
//             ),
//             // Branch info
//             Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 const Text('Branch',
//                     style: TextStyle(
//                         fontSize: 10, color: Color(0xFF8A94A6))),
//                 Text(branch,
//                     style: const TextStyle(
//                         fontSize: 13,
//                         fontWeight: FontWeight.w600,
//                         color: Color(0xFF1A1A2E))),
//               ],
//             ),
//             if (shift != null) ...[
//               Container(
//                 margin: const EdgeInsets.symmetric(horizontal: 16),
//                 width: 1,
//                 height: 28,
//                 color: const Color(0xFFE5E7EB),
//               ),
//               Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   const Text('Shift',
//                       style: TextStyle(
//                           fontSize: 10, color: Color(0xFF8A94A6))),
//                   Text(shift!,
//                       style: const TextStyle(
//                           fontSize: 13,
//                           fontWeight: FontWeight.w600,
//                           color: Color(0xFF1A1A2E))),
//                 ],
//               ),
//             ],
//             const Spacer(),
//             if (extraActions != null) ...extraActions!,
//             // Bell
//             Stack(
//               children: [
//                 IconButton(
//                   onPressed: () {},
//                   icon: const Icon(Icons.notifications_outlined,
//                       color: Color(0xFF4A5568)),
//                 ),
//                 Positioned(
//                   right: 8,
//                   top: 8,
//                   child: Container(
//                     width: 8,
//                     height: 8,
//                     decoration: const BoxDecoration(
//                         color: Colors.red, shape: BoxShape.circle),
//                   ),
//                 ),
//               ],
//             ),
//             // Avatar + name
//             CircleAvatar(
//               radius: 16,
//               backgroundColor: const Color(0xFF3B5BDB),
//               child: Text(
//                 advisorName.length >= 2
//                     ? advisorName.substring(0, 2).toUpperCase()
//                     : advisorName.toUpperCase(),
//                 style: const TextStyle(
//                     color: Colors.white,
//                     fontSize: 12,
//                     fontWeight: FontWeight.bold),
//               ),
//             ),
//             const SizedBox(width: 8),
//             Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Text(advisorName,
//                     style: const TextStyle(
//                         fontSize: 13,
//                         fontWeight: FontWeight.w600,
//                         color: Color(0xFF1A1A2E))),
//                 Text(advisorId,
//                     style: const TextStyle(
//                         fontSize: 11, color: Color(0xFF8A94A6))),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
