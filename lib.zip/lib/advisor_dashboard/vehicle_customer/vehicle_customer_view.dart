import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:orientmobileapplication/routes/approutes.dart';
import 'package:provider/provider.dart';
import 'vehicle_customer_model.dart';
import 'vehicle_customer_viewmodel.dart';
import 'shared_widgets.dart';
import 'select_brand_sheet.dart';

class VehicleCustomerView extends StatelessWidget {
  const VehicleCustomerView({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => VehicleCustomerViewModel(),
      child: const _Body(),
    );
  }
}

class _Body extends StatelessWidget {
  const _Body();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<VehicleCustomerViewModel>();

    return Scaffold(
      backgroundColor: const Color(0xFFF4F6F9),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: kTextColor),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text('Vehicle/Customer Details',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: kTextColor)),
        centerTitle: true,
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(14, 14, 14, 100),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── Hint text ───────────────────────────────────────────
                const Text(
                  'Type VIN/License Plate no./Customer Name If not found create new vehicle.',
                  style: TextStyle(
                      fontSize: 13,
                      color: Color(0xFF6B7280),
                      height: 1.5),
                ),
                const SizedBox(height: 16),

                // ── Search mode (Image 1) ────────────────────────────────
                _SearchModeSection(vm: vm),
                const SizedBox(height: 16),

                // ── Customer Details (Images 3-5) ────────────────────────
                _CustomerDetailsSection(vm: vm),

                // ── Vehicle Details (Images 6-14) ────────────────────────
                _VehicleDetailsSection(vm: vm),

                // ── Additional Information (Image 15) ────────────────────
                _AdditionalInfoSection(vm: vm),
              ],
            ),
          ),

          // ── FAB (teal) ────────────────────────────────────────────────
          Positioned(
            bottom: 80,
            right: 16,
            child: FloatingActionButton(
              backgroundColor: kBlue,
              onPressed: () {},
              child: const Icon(Icons.person_pin, color: Colors.white, size: 26),
            ),
          ),

          // ── NEXT button ────────────────────────────────────────────────
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              color: Colors.white,
              padding: const EdgeInsets.fromLTRB(14, 8, 14, 16),
              child: ElevatedButton(
               onPressed: () {
    context.pushNamed(Approutes.chooseinspectionview);
  },
                style: ElevatedButton.styleFrom(
                  backgroundColor: kBlue,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  minimumSize: const Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('NEXT',
                    style: TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w700,
                        letterSpacing: 1)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  SEARCH MODE SECTION (Image 1)
// ─────────────────────────────────────────────────────────────────────────────
class _SearchModeSection extends StatelessWidget {
  final VehicleCustomerViewModel vm;
  const _SearchModeSection({required this.vm});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: Column(
        children: [
          // By Vehicle Reg No.
          _RadioOption(
            label: 'By Vehicle Reg No.',
            value: SearchMode.byVehicleReg,
            groupValue: vm.form.searchMode,
            onChanged: vm.setSearchMode,
          ),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 10),
            child: Text('OR',
                style: TextStyle(
                    color: Color(0xFF9CA3AF),
                    fontSize: 13,
                    fontWeight: FontWeight.w500)),
          ),
          // By Customer Name / Phone
          _RadioOption(
            label: 'By Customer Name / Phone Number',
            value: SearchMode.byCustomer,
            groupValue: vm.form.searchMode,
            onChanged: vm.setSearchMode,
          ),
          if (vm.form.searchMode == SearchMode.byCustomer) ...[
            const SizedBox(height: 12),
            TextField(
              onChanged: vm.setCustomerSearch,
              decoration: InputDecoration(
                hintText: 'Customer Search',
                hintStyle: const TextStyle(color: kHintColor, fontSize: 13),
                prefixIcon: const Icon(Icons.search, color: kHintColor, size: 18),
                filled: true,
                fillColor: kFieldBg,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none,
                ),
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              ),
            ),
          ],
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 10),
            child: Text('OR',
                style: TextStyle(
                    color: Color(0xFF9CA3AF),
                    fontSize: 13,
                    fontWeight: FontWeight.w500)),
          ),
          // SCAN VIN
          _OutlineButton(
            icon: Icons.qr_code,
            label: 'SCAN VIN',
            onTap: () {},
          ),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 10),
            child: Text('OR',
                style: TextStyle(
                    color: Color(0xFF9CA3AF),
                    fontSize: 13,
                    fontWeight: FontWeight.w500)),
          ),
          // SCAN VEHICLE QR CODE
          _OutlineButton(
            icon: Icons.qr_code_scanner,
            label: 'SCAN VEHICLE QR CODE',
            onTap: () {},
          ),
        ],
      ),
    );
  }
}

class _RadioOption extends StatelessWidget {
  final String label;
  final SearchMode value;
  final SearchMode groupValue;
  final ValueChanged<SearchMode> onChanged;

  const _RadioOption({
    required this.label,
    required this.value,
    required this.groupValue,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final isSelected = value == groupValue;
    return GestureDetector(
      onTap: () => onChanged(value),
      child: Row(
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            width: 22,
            height: 22,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: isSelected ? kBlue : const Color(0xFFCDD2D8),
                width: 2,
              ),
              color: Colors.white,
            ),
            child: isSelected
                ? Center(
                    child: Container(
                      width: 12,
                      height: 12,
                      decoration: const BoxDecoration(
                        color: kBlue,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.check,
                          color: Colors.white, size: 9),
                    ),
                  )
                : null,
          ),
          const SizedBox(width: 10),
          Text(label,
              style: TextStyle(
                  fontSize: 14,
                  color: isSelected ? kTextColor : const Color(0xFF6B7280),
                  fontWeight: isSelected ? FontWeight.w500 : FontWeight.normal)),
        ],
      ),
    );
  }
}

class _OutlineButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _OutlineButton(
      {required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: BoxDecoration(
          border: Border.all(color: kBlue),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: kBlue, size: 18),
            const SizedBox(width: 8),
            Text(label,
                style: const TextStyle(
                    color: kBlue,
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    letterSpacing: 0.5)),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  CUSTOMER DETAILS (Images 3-5)
// ─────────────────────────────────────────────────────────────────────────────
class _CustomerDetailsSection extends StatelessWidget {
  final VehicleCustomerViewModel vm;
  const _CustomerDetailsSection({required this.vm});

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'Customer Details',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // B2B toggle
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              const Text('B2B Customer',
                  style: TextStyle(fontSize: 13, color: kLabelColor)),
              const SizedBox(width: 8),
              Switch(
                value: vm.form.isB2B,
                onChanged: vm.setB2B,
                activeColor: kBlue,
              ),
            ],
          ),
          kGap12,

          FieldLabel('Customer Name', required: true),
          AdvisorTextField(
            hint: 'Customer Name',
            onChanged: vm.setCustomerName,
          ),
          kGap12,

          FieldLabel('Phone Number', required: true),
          AdvisorTextField(
            hint: 'Phone number',
            keyboardType: TextInputType.phone,
            prefix: const Padding(
              padding: EdgeInsets.only(left: 12, right: 4),
              child: Text('+91',
                  style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: kTextColor)),
            ),
            onChanged: vm.setPhone,
          ),
          kGap12,

          const FieldLabel('Email Address'),
          AdvisorTextField(
            hint: 'Email',
            keyboardType: TextInputType.emailAddress,
            onChanged: vm.setEmail,
          ),
          kGap12,

          const FieldLabel('Customer Group'),
          AdvisorDropdown(
            hint: 'Select Customer Group',
            value: vm.form.customerGroup,
            items: kCustomerGroups,
            onChanged: vm.setCustomerGroup,
          ),
          kGap12,

          const FieldLabel('Customer Tag'),
          _TagRow(vm: vm),

          if (vm.showMoreCustomer) ...[
            kGap12,
            const FieldLabel('Gender'),
            AdvisorDropdown(
              hint: 'Select Gender',
              value: vm.form.gender,
              items: kGenders,
              onChanged: vm.setGender,
            ),
            kGap12,

            const FieldLabel('Address'),
            AdvisorDropdown(
              hint: 'Address',
              value: vm.form.address,
              items: kAddresses,
              onChanged: vm.setAddress,
            ),
            kGap12,

            const FieldLabel('Tax Number'),
            AdvisorTextField(
              hint: 'Tax Number',
              onChanged: vm.setTaxNumber,
            ),
            kGap12,

            const FieldLabel('Group Tax Number'),
            AdvisorTextField(
              hint: 'Group Tax Number',
              onChanged: vm.setGroupTaxNumber,
            ),
            kGap12,

            const FieldLabel('Occupation'),
            AdvisorTextField(
              hint: 'Occupation',
              onChanged: vm.setOccupation,
            ),
            kGap12,

            const FieldLabel('Organisation'),
            AdvisorTextField(
              hint: 'Organisation',
              onChanged: vm.setOrganisation,
            ),
            kGap12,

            const FieldLabel('Source'),
            AdvisorTextField(
              hint: 'How did you come to know abo...',
              onChanged: vm.setSource,
            ),
          ],

          const SizedBox(height: 8),
          MoreLessLink(
            showMore: vm.showMoreCustomer,
            onTap: vm.toggleMoreCustomer,
          ),
        ],
      ),
    );
  }
}

class _TagRow extends StatelessWidget {
  final VehicleCustomerViewModel vm;
  const _TagRow({required this.vm});

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        // selected tags
        ...vm.form.selectedTags.map((tag) {
          final t = kCustomerTags.firstWhere(
              (t) => t.label == tag,
              orElse: () => CustomerTag(label: tag, color: kBlue));
          return Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              border: Border.all(color: t.color),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(tag,
                style: TextStyle(
                    color: t.color,
                    fontWeight: FontWeight.w600,
                    fontSize: 12)),
          );
        }),
        // Add tag button
        GestureDetector(
          onTap: () async {
            final result = await showModalBottomSheet<List<String>>(
              context: context,
              isScrollControlled: true,
              shape: const RoundedRectangleBorder(
                borderRadius:
                    BorderRadius.vertical(top: Radius.circular(16)),
              ),
              builder: (_) => CustomerTagSheet(
                  selected: vm.form.selectedTags),
            );
            if (result != null) {
              for (final tag in kCustomerTags.map((t) => t.label)) {
                if (result.contains(tag) &&
                    !vm.form.selectedTags.contains(tag)) {
                  vm.toggleTag(tag);
                } else if (!result.contains(tag) &&
                    vm.form.selectedTags.contains(tag)) {
                  vm.toggleTag(tag);
                }
              }
            }
          },
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: kFieldBg,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: kBorderColor),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.add, size: 14, color: kBlue),
                SizedBox(width: 4),
                Text('Tag',
                    style: TextStyle(
                        fontSize: 12,
                        color: kLabelColor,
                        fontWeight: FontWeight.w500)),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  VEHICLE DETAILS (Images 6-14)
// ─────────────────────────────────────────────────────────────────────────────
class _VehicleDetailsSection extends StatelessWidget {
  final VehicleCustomerViewModel vm;
  const _VehicleDetailsSection({required this.vm});

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'Vehicle Details',
      trailing: OutlinedButton.icon(
        onPressed: () {},
        icon: const Icon(Icons.history, size: 14, color: kBlue),
        label: const Text('View History',
            style: TextStyle(fontSize: 12, color: kBlue)),
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: kBlue),
          padding:
              const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          minimumSize: Size.zero,
          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          FieldLabel('Registration Number', required: true),
          AdvisorTextField(
            hint: '',
            initialValue: vm.form.registrationNumber,
            onChanged: vm.setRegistrationNumber,
            filled: vm.form.registrationNumber.isNotEmpty,
          ),
          kGap12,

          const FieldLabel('VIN (Chasis number)'),
          AdvisorTextField(
            hint: 'VIN(Chasis number)',
            onChanged: vm.setVin,
            suffix: const Padding(
              padding: EdgeInsets.only(right: 10),
              child: Icon(Icons.qr_code_scanner,
                  color: kHintColor, size: 18),
            ),
          ),
          kGap12,

          FieldLabel('Make', required: true),
          _BrandSelector(vm: vm),
          kGap12,

          FieldLabel('Model', required: true),
          _ModelSelector(vm: vm),
          kGap12,

          const FieldLabel('Model Year'),
          _ModelYearSelector(vm: vm),

          if (vm.showMoreVehicle) ...[
            kGap12,
            const FieldLabel('Purchase Date'),
            AdvisorTextField(
              hint: 'MM/YYYY',
              prefix: const Padding(
                padding: EdgeInsets.only(left: 12, right: 4),
                child: Icon(Icons.calendar_today,
                    color: kHintColor, size: 16),
              ),
              onChanged: vm.setPurchaseDate,
            ),
            kGap12,

            const FieldLabel('Number of Cylinders'),
            AdvisorDropdown(
              hint: 'Number of Cylinders',
              value: vm.form.cylinders,
              items: kCylinders,
              onChanged: vm.setCylinders,
            ),
            kGap12,

            const FieldLabel('Engine Capacity'),
            AdvisorTextField(
              hint: 'Engine Capacity',
              onChanged: vm.setEngineCapacity,
            ),
            kGap12,

            const FieldLabel('Vehicle Color'),
            AdvisorTextField(
              hint: 'Vehicle Color',
              onChanged: vm.setVehicleColor,
            ),
            kGap12,

            const FieldLabel('Engine number'),
            AdvisorTextField(
              hint: 'Engine number',
              onChanged: vm.setEngineNumber,
            ),
            kGap12,

            const FieldLabel('Insurance Provider'),
            AdvisorDropdown(
              hint: 'Insurance Provider',
              value: vm.form.insuranceProvider,
              items: kInsuranceProviders,
              onChanged: vm.setInsuranceProvider,
            ),
            kGap12,

            const FieldLabel('Insurance Tax number'),
            AdvisorTextField(
              hint: 'Enter Insurance Tax number',
              onChanged: vm.setInsuranceTaxNumber,
            ),
            kGap12,

            const FieldLabel('Insurance Address'),
            AdvisorTextField(
              hint: 'Insurance Address',
              onChanged: vm.setInsuranceAddress,
            ),
            kGap12,

            const FieldLabel('Policy number'),
            AdvisorTextField(
              hint: 'Policy number',
              onChanged: vm.setPolicyNumber,
            ),
            kGap12,

            const FieldLabel('Insurance expiry date'),
            AdvisorTextField(
              hint: 'Click to select a date',
              prefix: const Padding(
                padding: EdgeInsets.only(left: 12, right: 4),
                child: Icon(Icons.calendar_today,
                    color: kHintColor, size: 16),
              ),
              onChanged: vm.setInsuranceExpiry,
            ),
            kGap12,

            const FieldLabel('Registration Certificate'),
            _ImageUploadButton(label: 'Images', onTap: () {}),
            kGap12,

            const FieldLabel('Insurance'),
            _ImageUploadButton(label: 'Images', onTap: () {}),
          ],

          const SizedBox(height: 8),
          MoreLessLink(
            showMore: vm.showMoreVehicle,
            onTap: vm.toggleMoreVehicle,
          ),
        ],
      ),
    );
  }
}

class _BrandSelector extends StatelessWidget {
  final VehicleCustomerViewModel vm;
  const _BrandSelector({required this.vm});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        final result = await showModalBottomSheet<String>(
          context: context,
          isScrollControlled: true,
          backgroundColor: Colors.transparent,
          builder: (_) =>
              SizedBox(height: MediaQuery.of(context).size.height * 0.85,
                  child: SelectBrandSheet(selected: vm.form.make)),
        );
        if (result != null) vm.setMake(result);
      },
      child: Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        decoration: BoxDecoration(
          color: vm.form.make.isEmpty ? kFieldBg : kTealLight,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                vm.form.make.isEmpty ? 'Select Brand' : vm.form.make,
                style: TextStyle(
                    fontSize: 13,
                    color: vm.form.make.isEmpty
                        ? kHintColor
                        : kTextColor,
                    fontWeight: vm.form.make.isEmpty
                        ? FontWeight.normal
                        : FontWeight.w600),
              ),
            ),
            const Icon(Icons.chevron_right,
                color: kHintColor, size: 18),
          ],
        ),
      ),
    );
  }
}

class _ModelSelector extends StatelessWidget {
  final VehicleCustomerViewModel vm;
  const _ModelSelector({required this.vm});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        if (vm.form.make.isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Please select a brand first')),
          );
          return;
        }
        final result = await showModalBottomSheet<String>(
          context: context,
          isScrollControlled: true,
          backgroundColor: Colors.transparent,
          builder: (_) => SizedBox(
              height: MediaQuery.of(context).size.height * 0.85,
              child: SelectModelSheet(
                  brand: vm.form.make, selected: vm.form.model)),
        );
        if (result != null) vm.setModel(result);
      },
      child: Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        decoration: BoxDecoration(
          color: vm.form.model.isEmpty ? kFieldBg : kTealLight,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                vm.form.model.isEmpty ? 'Select Model' : vm.form.model,
                style: TextStyle(
                    fontSize: 13,
                    color: vm.form.model.isEmpty
                        ? kHintColor
                        : kTextColor,
                    fontWeight: vm.form.model.isEmpty
                        ? FontWeight.normal
                        : FontWeight.w600),
              ),
            ),
            const Icon(Icons.chevron_right,
                color: kHintColor, size: 18),
          ],
        ),
      ),
    );
  }
}

class _ModelYearSelector extends StatelessWidget {
  final VehicleCustomerViewModel vm;
  const _ModelYearSelector({required this.vm});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        final result =
            await showModelYearDialog(context, vm.form.modelYear);
        if (result != null) vm.setModelYear(result);
      },
      child: Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        decoration: BoxDecoration(
          color: vm.form.modelYear.isEmpty ? kFieldBg : kTealLight,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                vm.form.modelYear.isEmpty
                    ? 'Select Model Year'
                    : vm.form.modelYear,
                style: TextStyle(
                    fontSize: 13,
                    color: vm.form.modelYear.isEmpty
                        ? kHintColor
                        : kTextColor,
                    fontWeight: vm.form.modelYear.isEmpty
                        ? FontWeight.normal
                        : FontWeight.w600),
              ),
            ),
            const Icon(Icons.keyboard_arrow_down,
                color: kHintColor, size: 20),
          ],
        ),
      ),
    );
  }
}

class _ImageUploadButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _ImageUploadButton({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: kFieldBg,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: kBorderColor),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.add_circle, color: kBlue, size: 18),
            const SizedBox(width: 6),
            Text(label,
                style: const TextStyle(
                    fontSize: 13, color: kBlue, fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  ADDITIONAL INFORMATION (Image 15)
// ─────────────────────────────────────────────────────────────────────────────
class _AdditionalInfoSection extends StatelessWidget {
  final VehicleCustomerViewModel vm;
  const _AdditionalInfoSection({required this.vm});

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'Additional Information',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const FieldLabel('Odometer Reading(in Kms)'),
          AdvisorTextField(
            hint: 'Odometer (in Kms)',
            keyboardType: TextInputType.number,
            onChanged: vm.setOdometer,
          ),
          kGap16,

          // Fuel level slider
          const Text('Fuel level',
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: kLabelColor)),
          const SizedBox(height: 8),
          _FuelLevelSlider(
            value: vm.form.fuelLevel,
            onChanged: vm.setFuelLevel,
          ),
          kGap16,

          // Customer Consent toggle
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: kFieldBg,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              children: [
                const Text('Customer\nConsent',
                    style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: kLabelColor)),
                const Spacer(),
                Switch(
                  value: vm.form.customerConsent,
                  onChanged: vm.setConsent,
                  activeColor: kBlue,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FuelLevelSlider extends StatelessWidget {
  final int value;
  final ValueChanged<int> onChanged;
  const _FuelLevelSlider({required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        // Ticks bar
        Expanded(
          child: Row(
            children: List.generate(10, (i) {
              final isFilled = i < value;
              return Expanded(
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 1),
                  height: 16,
                  decoration: BoxDecoration(
                    color: isFilled
                        ? kBlue
                        : const Color(0xFFE0E0E0),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              );
            }),
          ),
        ),
        const SizedBox(width: 8),
        const Icon(Icons.local_gas_station,
            color: kLabelColor, size: 20),
      ],
    );
  }
}
