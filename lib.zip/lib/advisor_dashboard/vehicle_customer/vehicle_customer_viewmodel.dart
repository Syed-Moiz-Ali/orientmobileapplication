import 'package:flutter/material.dart';
import 'vehicle_customer_model.dart';

class VehicleCustomerViewModel extends ChangeNotifier {
  final VehicleCustomerFormModel form = VehicleCustomerFormModel();

  bool _showMoreCustomer = false;
  bool get showMoreCustomer => _showMoreCustomer;

  bool _showMoreVehicle = false;
  bool get showMoreVehicle => _showMoreVehicle;

  void toggleMoreCustomer() {
    _showMoreCustomer = !_showMoreCustomer;
    notifyListeners();
  }

  void toggleMoreVehicle() {
    _showMoreVehicle = !_showMoreVehicle;
    notifyListeners();
  }

  void setSearchMode(SearchMode mode) {
    form.searchMode = mode;
    notifyListeners();
  }

  void setCustomerSearch(String v) {
    form.customerSearch = v;
    notifyListeners();
  }

  void setB2B(bool v) {
    form.isB2B = v;
    notifyListeners();
  }

  void setCustomerName(String v) { form.customerName = v; notifyListeners(); }
  void setPhone(String v) { form.phoneNumber = v; notifyListeners(); }
  void setEmail(String v) { form.email = v; notifyListeners(); }
  void setCustomerGroup(String? v) { form.customerGroup = v ?? ''; notifyListeners(); }
  void setGender(String? v) { form.gender = v ?? ''; notifyListeners(); }
  void setAddress(String? v) { form.address = v ?? ''; notifyListeners(); }
  void setTaxNumber(String v) { form.taxNumber = v; notifyListeners(); }
  void setGroupTaxNumber(String v) { form.groupTaxNumber = v; notifyListeners(); }
  void setOccupation(String v) { form.occupation = v; notifyListeners(); }
  void setOrganisation(String v) { form.organisation = v; notifyListeners(); }
  void setSource(String v) { form.source = v; notifyListeners(); }

  void toggleTag(String tag) {
    if (form.selectedTags.contains(tag)) {
      form.selectedTags.remove(tag);
    } else {
      form.selectedTags.add(tag);
    }
    notifyListeners();
  }

  void setRegistrationNumber(String v) { form.registrationNumber = v; notifyListeners(); }
  void setVin(String v) { form.vin = v; notifyListeners(); }
  void setMake(String? v) { form.make = v ?? ''; form.model = ''; notifyListeners(); }
  void setModel(String? v) { form.model = v ?? ''; notifyListeners(); }
  void setModelYear(String? v) { form.modelYear = v ?? ''; notifyListeners(); }
  void setPurchaseDate(String v) { form.purchaseDate = v; notifyListeners(); }
  void setCylinders(String? v) { form.cylinders = v ?? ''; notifyListeners(); }
  void setEngineCapacity(String v) { form.engineCapacity = v; notifyListeners(); }
  void setVehicleColor(String v) { form.vehicleColor = v; notifyListeners(); }
  void setEngineNumber(String v) { form.engineNumber = v; notifyListeners(); }
  void setInsuranceProvider(String? v) { form.insuranceProvider = v ?? ''; notifyListeners(); }
  void setInsuranceTaxNumber(String v) { form.insuranceTaxNumber = v; notifyListeners(); }
  void setInsuranceAddress(String v) { form.insuranceAddress = v; notifyListeners(); }
  void setPolicyNumber(String v) { form.policyNumber = v; notifyListeners(); }
  void setInsuranceExpiry(String v) { form.insuranceExpiryDate = v; notifyListeners(); }

  void setOdometer(String v) { form.odometerReading = v; notifyListeners(); }
  void setFuelLevel(int v) { form.fuelLevel = v; notifyListeners(); }
  void setConsent(bool v) { form.customerConsent = v; notifyListeners(); }

  bool validate() {
    return form.registrationNumber.isNotEmpty;
  }
}
