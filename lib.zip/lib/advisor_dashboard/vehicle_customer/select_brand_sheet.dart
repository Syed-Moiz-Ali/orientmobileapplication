import 'package:flutter/material.dart';
import 'vehicle_customer_model.dart';
import 'shared_widgets.dart';

class SelectBrandSheet extends StatefulWidget {
  final String? selected;
  const SelectBrandSheet({super.key, this.selected});

  @override
  State<SelectBrandSheet> createState() => _SelectBrandSheetState();
}

class _SelectBrandSheetState extends State<SelectBrandSheet> {
  String _query = '';
  String? _selected;

  @override
  void initState() {
    super.initState();
    _selected = widget.selected;
  }

  List<String> get _filtered => kCarBrands
      .where((b) => b.toLowerCase().contains(_query.toLowerCase()))
      .toList();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      child: Column(
        children: [
          // Header
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: const BoxDecoration(
              color: kBlue,
              borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
            ),
            child: Row(
              children: [
                const Text('Select Brand',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 16)),
                const Spacer(),
                GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: const Icon(Icons.close, color: Colors.white),
                ),
              ],
            ),
          ),
          // Search
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              onChanged: (v) => setState(() => _query = v),
              decoration: InputDecoration(
                hintText: 'Search',
                hintStyle: const TextStyle(color: kHintColor, fontSize: 13),
                prefixIcon: const Icon(Icons.search, color: kHintColor, size: 18),
                filled: true,
                fillColor: kFieldBg,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none,
                ),
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              ),
            ),
          ),
          // List
          Expanded(
            child: ListView.separated(
              itemCount: _filtered.length,
              separatorBuilder: (_, __) =>
                  const Divider(height: 1, indent: 16, endIndent: 16),
              itemBuilder: (_, i) {
                final brand = _filtered[i];
                final isSelected = brand == _selected;
                return ListTile(
                  leading: Icon(
                    isSelected ? Icons.star : Icons.star_border,
                    color: isSelected ? kBlue : const Color(0xFFCDD2D8),
                    size: 20,
                  ),
                  title: Text(brand,
                      style: const TextStyle(
                          fontSize: 14, color: kTextColor)),
                  trailing: isSelected
                      ? const Icon(Icons.check_circle,
                          color: kBlue, size: 20)
                      : const Icon(Icons.radio_button_unchecked,
                          color: Color(0xFFCDD2D8), size: 20),
                  onTap: () => Navigator.of(context).pop(brand),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ── Select Model Sheet ────────────────────────────────────────
class SelectModelSheet extends StatefulWidget {
  final String brand;
  final String? selected;

  const SelectModelSheet(
      {super.key, required this.brand, this.selected});

  @override
  State<SelectModelSheet> createState() => _SelectModelSheetState();
}

class _SelectModelSheetState extends State<SelectModelSheet> {
  String _query = '';
  String? _selected;

  @override
  void initState() {
    super.initState();
    _selected = widget.selected;
  }

  List<String> get _models => modelsForBrand(widget.brand);

  List<String> get _filtered => _models
      .where((m) => m.toLowerCase().contains(_query.toLowerCase()))
      .toList();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: const BoxDecoration(
              color: kBlue,
              borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
            ),
            child: Row(
              children: [
                const Text('Models',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 16)),
                const Spacer(),
                GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: const Icon(Icons.close, color: Colors.white),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              onChanged: (v) => setState(() => _query = v),
              decoration: InputDecoration(
                hintText: 'Search',
                hintStyle: const TextStyle(color: kHintColor, fontSize: 13),
                prefixIcon: const Icon(Icons.search, color: kHintColor, size: 18),
                filled: true,
                fillColor: kFieldBg,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none,
                ),
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              ),
            ),
          ),
          Expanded(
            child: ListView.separated(
              itemCount: _filtered.length,
              separatorBuilder: (_, __) =>
                  const Divider(height: 1, indent: 16, endIndent: 16),
              itemBuilder: (_, i) {
                final model = _filtered[i];
                final isSelected = model == _selected;
                return ListTile(
                  leading: Icon(
                    isSelected ? Icons.star : Icons.star_border,
                    color: isSelected ? kBlue : const Color(0xFFCDD2D8),
                    size: 20,
                  ),
                  title: Text(model,
                      style: const TextStyle(
                          fontSize: 14, color: kTextColor)),
                  trailing: isSelected
                      ? const Icon(Icons.check_circle,
                          color: kBlue, size: 20)
                      : const Icon(Icons.radio_button_unchecked,
                          color: Color(0xFFCDD2D8), size: 20),
                  onTap: () => Navigator.of(context).pop(model),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ── Customer Tag Sheet ────────────────────────────────────────
class CustomerTagSheet extends StatefulWidget {
  final List<String> selected;
  const CustomerTagSheet({super.key, required this.selected});

  @override
  State<CustomerTagSheet> createState() => _CustomerTagSheetState();
}

class _CustomerTagSheetState extends State<CustomerTagSheet> {
  late List<String> _selected;

  @override
  void initState() {
    super.initState();
    _selected = List.from(widget.selected);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              const Text('Select Customer Tag',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: kTextColor)),
              const Spacer(),
              GestureDetector(
                onTap: () => Navigator.of(context).pop(_selected),
                child: const Icon(Icons.close, color: kLabelColor),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...kCustomerTags.map((tag) {
            final isSelected = _selected.contains(tag.label);
            return Column(
              children: [
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      border: Border.all(color: tag.color),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(tag.label,
                        style: TextStyle(
                            color: tag.color,
                            fontWeight: FontWeight.w600,
                            fontSize: 13)),
                  ),
                  trailing: GestureDetector(
                    onTap: () {
                      setState(() {
                        if (isSelected) {
                          _selected.remove(tag.label);
                        } else {
                          _selected.add(tag.label);
                        }
                      });
                    },
                    child: Icon(
                      isSelected
                          ? Icons.check_circle
                          : Icons.radio_button_unchecked,
                      color: isSelected ? kBlue : const Color(0xFFCDD2D8),
                    ),
                  ),
                ),
                const Divider(height: 1),
              ],
            );
          }),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}

// ── Model Year Dialog (Image 11) ──────────────────────────────
Future<String?> showModelYearDialog(
    BuildContext context, String? current) async {
  String? selected = current;
  return showDialog<String>(
    context: context,
    builder: (ctx) {
      return StatefulBuilder(
        builder: (ctx, setState) {
          return AlertDialog(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            title: const Text('Select Model Year',
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: kTextColor)),
            content: SizedBox(
              width: 280,
              height: 280,
              child: ListView(
                children: kModelYears.map((y) {
                  return RadioListTile<String>(
                    value: y,
                    groupValue: selected,
                    activeColor: kBlue,
                    title: Text(y,
                        style: const TextStyle(
                            fontSize: 14, color: kTextColor)),
                    onChanged: (v) => setState(() => selected = v),
                  );
                }).toList(),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(),
                child: const Text('CANCEL',
                    style: TextStyle(
                        color: kBlue, fontWeight: FontWeight.w700)),
              ),
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(selected),
                child: const Text('OK',
                    style: TextStyle(
                        color: kBlue, fontWeight: FontWeight.w700)),
              ),
            ],
          );
        },
      );
    },
  );
}
