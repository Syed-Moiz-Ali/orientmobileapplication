import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:orientmobileapplication/advisor_dashboard/inspectionpages/choose_inspection_view.dart';
import 'package:orientmobileapplication/advisor_dashboard/inspectionpages/inspection_preview_view.dart';
import 'package:orientmobileapplication/advisor_dashboard/inspectionpages/inspection_sheet_view.dart';
import 'package:orientmobileapplication/advisor_dashboard/inspectionpages/repair_order_view.dart';
import 'package:provider/provider.dart';
import 'advisor_dashboard_viewmodel.dart';
import 'jobcardmode.dart';
import 'pending_approval_model.dart';
import 'followup_reminder_model.dart';
import 'vehicle_customer/vehicle_customer_view.dart';
import 'scan_vehicle_view.dart';

// ═══════════════════════════════════════════════════════════════════════════════
//  DESIGN TOKENS — unified with dashboard_view.dart (DC palette)
// ═══════════════════════════════════════════════════════════════════════════════

// Brand core
const Color _kPrimary = Color(0xFF0F4C75);
const Color _kAccent = Color(0xFF1B9AAA);
const Color _kAccentLight = Color(0xFFE0F4F6);
const Color _kAccentMid = Color(0xFFB2E0E5);

// Gradient
const Color _kGStart = Color(0xFF0F4C75);
const Color _kGEnd = Color(0xFF1B9AAA);
const List<Color> _kHeaderGrad = [_kGStart, _kGEnd];

// Surface
const Color _kCanvas = Color(0xFFF5F7FA); // DC.scaffold
const Color _kSurface = Color(0xFFFFFFFF); // DC.surface
const Color _kSurfaceAlt = Color(0xFFF0F3F7); // DC.surfaceAlt
const Color _kLine = Color(0xFFE2E8EF); // DC.border
const Color _kStroke = Color(0xFFCBD5E1);

// Text
const Color _kText1 = Color(0xFF0A1628); // DC.textH
const Color _kText2 = Color(0xFF253347); // DC.textB
const Color _kText3 = Color(0xFF5C6E85); // DC.textM

// Semantic
const Color _kBlue = Color(0xFF1B9AAA); // alias → DC.accent
const Color _kBlueFade = Color(0xFFE0F4F6); // alias → DC.accentLight

const Color _kAmber = Color(0xFFD97706); // DC.amber
const Color _kAmberLight = Color(0xFFFB923C);
const Color _kAmberFade = Color(0xFFFFF8EC); // DC.amberBg

const Color _kEmerald = Color(0xFF1A8754); // DC.green
const Color _kEmeraldFade = Color(0xFFEAF7EF); // DC.greenBg

const Color _kRose = Color(0xFFB91C1C); // DC.red
const Color _kRoseFade = Color(0xFFFEECEC); // DC.redBg

const Color _kViolet = Color(0xFF6D28D9); // DC.purple
const Color _kVioletFade = Color(0xFFF0EAFC); // DC.purpleBg

const Color _kSlate = Color(0xFF5C6E85); // DC.textM

// Live indicator
const Color _kLive = Color(0xFF4ADEDF);

// ─────────────────────────────────────────────────────────────────────────────
//  ROOT
// ─────────────────────────────────────────────────────────────────────────────
class AdvisorHomeView extends StatefulWidget {
  const AdvisorHomeView({super.key});
  @override
  State<AdvisorHomeView> createState() => _AdvisorHomeViewState();
}

class _AdvisorHomeViewState extends State<AdvisorHomeView>
    with SingleTickerProviderStateMixin {
  late final TabController _tabCtrl;
  int _navIndex = 0;

  void _openChooseInspection() {
    HapticFeedback.mediumImpact();
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ChooseInspectionView(
          onBack: () => Navigator.pop(context),
          onSkip: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => RepairOrderView(
                  onBack: () => Navigator.pop(context),
                  fromInspection: false,
                ),
              ),
            );
          },
          onSelect: () {
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(
                builder: (_) => InspectionSheetView(
                  onBack: () => Navigator.pop(context),
                  onSaveDraft: () {
                    Navigator.pop(context);
                    _toast(
                      'Draft saved',
                      icon: Icons.save_outlined,
                      color: _kAmber,
                    );
                  },
                  onPreview: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => InspectionPreviewView(
                          onBack: () => Navigator.pop(context),
                          onSubmit: () {
                            Navigator.of(context).pushReplacement(
                              MaterialPageRoute(
                                builder: (_) => RepairOrderView(
                                  onBack: () => Navigator.of(
                                    context,
                                  ).popUntil((r) => r.isFirst),
                                  fromInspection: true,
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    );
                  },
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  void _openInspectionDirect() {
    HapticFeedback.mediumImpact();
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => InspectionSheetView(
          onBack: () => Navigator.pop(context),
          onSaveDraft: () {
            Navigator.pop(context);
            _toast('Draft saved', icon: Icons.save_outlined, color: _kAmber);
          },
          onPreview: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => InspectionPreviewView(
                  onBack: () => Navigator.pop(context),
                  onSubmit: () {
                    _toast(
                      'Inspection Submitted',
                      icon: Icons.check_circle_outline,
                      color: _kEmerald,
                    );
                    Navigator.of(context).popUntil((r) => r.isFirst);
                  },
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 3, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AdvisorDashboardViewModel>().loadDashboard();
      Future.delayed(const Duration(milliseconds: 900), () {
        if (mounted)
          _toast(
            'Good morning, Ali. You have 5 pending approvals.',
            icon: Icons.wb_sunny_outlined,
            color: _kAccent,
          );
      });
    });
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  void _openScan() => Navigator.of(
    context,
  ).push(MaterialPageRoute(builder: (_) => const ScanVehicleView()));

  void _openNewJobCard() => Navigator.of(
    context,
  ).push(MaterialPageRoute(builder: (_) => const VehicleCustomerView()));

  void _toast(String msg, {IconData? icon, Color color = _kAccent}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            if (icon != null) ...[
              Icon(icon, color: Colors.white, size: 16),
              const SizedBox(width: 8),
            ],
            Expanded(
              child: Text(
                msg,
                style: GoogleFonts.rajdhani(
                  fontSize: 14,
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.3,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 14),
        duration: const Duration(seconds: 3),
        elevation: 0,
      ),
    );
  }

  void _sheet(Widget child) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => child,
    );
  }

  void _showProfile() => _sheet(
    _ProfileSheet(
      onLogout: () {
        Navigator.pop(context);
        _toast('Logged out', icon: Icons.logout, color: _kSlate);
      },
    ),
  );

  void _showNotifications() {
    HapticFeedback.lightImpact();
    _sheet(const _NotifSheet());
  }

  void _onJobCard(JobCardMode jc) {
    HapticFeedback.selectionClick();
    _sheet(_JobCardSheet(jc: jc, onOpen: () => Navigator.pop(context)));
  }

  void _onApproval(PendingApprovalModel pa) {
    HapticFeedback.mediumImpact();
    _sheet(
      _ApprovalSheet(
        pa: pa,
        onApprove: () {
          Navigator.pop(context);
          _toast(
            'Estimate ${pa.estimateId} approved',
            icon: Icons.check_circle_outline,
            color: _kEmerald,
          );
        },
        onReject: () {
          Navigator.pop(context);
          _toast('Sent back for revision', icon: Icons.undo, color: _kAmber);
        },
      ),
    );
  }

  void _onContact(FollowupReminderModel r) {
    HapticFeedback.lightImpact();
    _sheet(
      _ContactSheet(
        r: r,
        onCall: () {
          Navigator.pop(context);
          _toast(
            'Calling ${r.customerName}…',
            icon: Icons.phone_outlined,
            color: _kAccent,
          );
        },
        onWhatsApp: () {
          Navigator.pop(context);
          _toast(
            'Opening WhatsApp…',
            icon: Icons.chat_outlined,
            color: _kEmerald,
          );
        },
        onSms: () {
          Navigator.pop(context);
          _toast('SMS sent', icon: Icons.sms_outlined, color: _kAccent);
        },
        onDone: () {
          Navigator.pop(context);
          _toast('Marked as done', icon: Icons.check, color: _kEmerald);
        },
      ),
    );
  }

  void _showSearch() => _sheet(
    _SearchSheet(
      onScan: () {
        Navigator.pop(context);
        _openScan();
      },
    ),
  );

  void _onStat(String label, int count, Color color) {
    showDialog(
      context: context,
      builder: (_) => _StatDialog(label: label, count: count, color: color),
    );
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: _kPrimary,
        statusBarIconBrightness: Brightness.light,
      ),
    );

    final vm = context.watch<AdvisorDashboardViewModel>();
    return Scaffold(
      backgroundColor: _kCanvas,
      body: vm.isLoading ? _loadingView() : _body(vm),
      floatingActionButton: _fab(),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: _bottomBar(),
    );
  }

  Widget _loadingView() => Container(
    decoration: const BoxDecoration(
      gradient: LinearGradient(
        colors: _kHeaderGrad,
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ),
    ),
    child: SafeArea(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(
              width: 26,
              height: 26,
              child: CircularProgressIndicator(
                color: _kAccent,
                strokeWidth: 2.5,
              ),
            ),
            const SizedBox(height: 18),
            Text(
              'Loading…',
              style: GoogleFonts.rajdhani(
                color: Colors.white70,
                fontSize: 15,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    ),
  );

  Widget _body(AdvisorDashboardViewModel vm) {
    return RefreshIndicator(
      color: _kAccent,
      strokeWidth: 2.5,
      displacement: 20,
      onRefresh: () async {
        await vm.loadDashboard();
        if (mounted) _toast('Refreshed', icon: Icons.refresh, color: _kAccent);
      },
      child: CustomScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(child: _header(vm)),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                const SizedBox(height: 20),
                _overviewLabel(),
                const SizedBox(height: 12),
                _statsRow(vm),
                const SizedBox(height: 20),
                _tabPanel(vm),
                const SizedBox(height: 16),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  // ── HEADER ──────────────────────────────────────────────────────────────────
  Widget _header(AdvisorDashboardViewModel vm) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: _kHeaderGrad,
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // ── Top row: avatar + name + notif ──────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: _showProfile,
                    child: Row(
                      children: [
                        _Avatar(initials: 'AR', size: 40),
                        const SizedBox(width: 10),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              vm.advisorName,
                              style: GoogleFonts.rajdhani(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 0.5,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Row(
                              children: [
                                Container(
                                  width: 6,
                                  height: 6,
                                  decoration: const BoxDecoration(
                                    color: _kLive,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  'On Shift',
                                  style: GoogleFonts.rajdhani(
                                    color: _kLive,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.3,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const Spacer(),
                  // Notification bell — matches dashboard AppBar style
                  Stack(
                    clipBehavior: Clip.none,
                    children: [
                      IconButton(
                        icon: const Icon(
                          Icons.notifications_outlined,
                          color: Colors.white,
                          size: 26,
                        ),
                        onPressed: _showNotifications,
                      ),
                      Positioned(
                        right: 10,
                        top: 10,
                        child: Container(
                          width: 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: const Color(0xFFFBBF24),
                            shape: BoxShape.circle,
                            border: Border.all(color: _kGStart, width: 1.5),
                          ),
                        ),
                      ),
                    ],
                  ),
                  // Avatar — matches dashboard profile circle
                  Padding(
                    padding: const EdgeInsets.only(right: 4),
                    child: GestureDetector(
                      onTap: _showProfile,
                      child: Container(
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.20),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: Colors.white.withOpacity(0.5),
                            width: 1.5,
                          ),
                        ),
                        child: Center(
                          child: Text(
                            'A',
                            style: GoogleFonts.rajdhani(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // ── Meta pills ──────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
              child: Row(
                children: [
                  _MetaPill(
                    icon: Icons.business_outlined,
                    label: 'Main Branch · Dubai',
                  ),
                  const SizedBox(width: 8),
                  _MetaPill(
                    icon: Icons.schedule_outlined,
                    label: '08:00 – 17:00',
                  ),
                ],
              ),
            ),

            // ── Live banner row — matches dashboard header banner style ──────
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
              child: Row(
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    margin: const EdgeInsets.only(right: 6, top: 1),
                    decoration: const BoxDecoration(
                      color: _kLive,
                      shape: BoxShape.circle,
                    ),
                  ),
                  Text(
                    'Live',
                    style: GoogleFonts.rajdhani(
                      color: _kLive,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    'Good Morning,',
                    style: GoogleFonts.rajdhani(
                      color: Colors.white70,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    'Advisor Dashboard',
                    style: GoogleFonts.orbitron(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.3,
                    ),
                  ),
                ],
              ),
            ),

            // ── Search bar ──────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
              child: Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: _showSearch,
                      child: Container(
                        height: 42,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.10),
                          borderRadius: BorderRadius.circular(11),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.15),
                          ),
                        ),
                        child: Row(
                          children: [
                            const SizedBox(width: 12),
                            Icon(
                              Icons.search_rounded,
                              color: Colors.white.withOpacity(0.45),
                              size: 18,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              'Search name, plate, phone…',
                              style: GoogleFonts.rajdhani(
                                color: Colors.white.withOpacity(0.45),
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  GestureDetector(
                    onTap: _openScan,
                    child: Container(
                      height: 42,
                      width: 42,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.18),
                        borderRadius: BorderRadius.circular(11),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.25),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.15),
                            blurRadius: 8,
                            offset: const Offset(0, 3),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.qr_code_scanner_rounded,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // ── Action buttons ───────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 10, 20, 16),
              child: Row(
                children: [
                  Expanded(
                    child: _HeaderBtn(
                      label: '+ New Job Card',
                      isPrimary: true,
                      onTap: () {
                        HapticFeedback.mediumImpact();
                        _openNewJobCard();
                      },
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _HeaderBtn(
                      label: 'Inspection',
                      icon: Icons.checklist_rounded,
                      isPrimary: false,
                      onTap: _openInspectionDirect,
                    ),
                  ),
                ],
              ),
            ),

            // ── Curved bottom edge ──────────────────────────────────────────
            Container(
              height: 24,
              decoration: const BoxDecoration(
                color: _kCanvas,
                borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Section label — identical to dashboard _sectionLabel ────────────────
  Widget _overviewLabel() {
    return Row(
      children: [
        Container(
          width: 4,
          height: 20,
          decoration: BoxDecoration(
            color: _kAccent,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 10),
        Text(
          "Today's Overview",
          style: GoogleFonts.rajdhani(
            color: _kText1,
            fontSize: 19,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.5,
          ),
        ),
        const Spacer(),
        _DateChip(),
      ],
    );
  }

  Widget _statsRow(AdvisorDashboardViewModel vm) {
    final s = vm.stats;
    return Row(
      children: [
        _StatTile(
          'Orders',
          s.newJobCardsToday,
          _kAccent,
          _kAccentLight,
          Icons.inbox_outlined,
          () => _onStat('Open Orders', s.newJobCardsToday, _kAccent),
        ),
        const SizedBox(width: 9),
        _StatTile(
          'WIP',
          s.inspectionsToday,
          _kAmber,
          _kAmberFade,
          Icons.build_circle_outlined,
          () => _onStat('WIP', s.inspectionsToday, _kAmber),
        ),
        const SizedBox(width: 9),
        _StatTile(
          'Ready',
          s.readyForDelivery,
          _kEmerald,
          _kEmeraldFade,
          Icons.verified_outlined,
          () => _onStat('Ready', s.readyForDelivery, _kEmerald),
        ),
        const SizedBox(width: 9),
        _StatTile(
          'Delivered',
          4,
          _kViolet,
          _kVioletFade,
          Icons.local_shipping_outlined,
          () => _onStat('Delivered', 4, _kViolet),
        ),
      ],
    );
  }

  Widget _StatTile(
    String label,
    int count,
    Color color,
    Color bg,
    IconData icon,
    VoidCallback onTap,
  ) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.fromLTRB(11, 13, 11, 14),
          decoration: BoxDecoration(
            color: _kSurface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _kLine),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.06),
                blurRadius: 10,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: bg,
                  borderRadius: BorderRadius.circular(9),
                ),
                child: Center(child: Icon(icon, size: 16, color: color)),
              ),
              const SizedBox(height: 10),
              Text(
                '$count',
                style: GoogleFonts.orbitron(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: color,
                  height: 1,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                label,
                style: GoogleFonts.rajdhani(
                  fontSize: 12,
                  color: _kText3,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _tabPanel(AdvisorDashboardViewModel vm) {
    return Container(
      decoration: BoxDecoration(
        color: _kSurface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _kLine),
        boxShadow: [
          BoxShadow(
            color: _kPrimary.withOpacity(0.05),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(5),
            child: Container(
              decoration: BoxDecoration(
                color: _kSurfaceAlt,
                borderRadius: BorderRadius.circular(13),
              ),
              child: Row(
                children: [
                  _Tab(
                    'Job Cards',
                    0,
                    badge: vm.stats.totalOpenJobCards.toString(),
                  ),
                  _Tab(
                    'Approvals',
                    1,
                    badge: vm.pendingApprovals.length.toString(),
                    badgeColor: _kAmber,
                  ),
                  _Tab(
                    'Reminders',
                    2,
                    badge: vm.followupReminders.length.toString(),
                    badgeColor: _kRose,
                  ),
                ],
              ),
            ),
          ),
          SizedBox(
            height: 340,
            child: TabBarView(
              controller: _tabCtrl,
              children: [
                _JobCardsPage(vm: vm, onTap: _onJobCard),
                _ApprovalsPage(vm: vm, onTap: _onApproval),
                _RemindersPage(vm: vm, onContact: _onContact),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _Tab(
    String label,
    int index, {
    String? badge,
    Color badgeColor = _kAccent,
  }) {
    return _TabBtn(
      label: label,
      index: index,
      ctrl: _tabCtrl,
      badge: badge,
      badgeColor: badgeColor,
    );
  }

  Widget _fab() => GestureDetector(
    onTap: () {
      HapticFeedback.heavyImpact();
      _openScan();
    },
    child: Container(
      width: 58,
      height: 58,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: _kHeaderGrad,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        shape: BoxShape.circle,
        border: Border.all(color: _kCanvas, width: 3),
        boxShadow: [
          BoxShadow(
            color: _kAccent.withOpacity(0.40),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.qr_code_scanner_rounded,
            color: Colors.white,
            size: 22,
          ),
          const SizedBox(height: 1),
          Text(
            'SCAN',
            style: GoogleFonts.rajdhani(
              color: Colors.white70,
              fontSize: 8,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.0,
            ),
          ),
        ],
      ),
    ),
  );

  Widget _bottomBar() => BottomAppBar(
    color: _kSurface,
    elevation: 0,
    shadowColor: Colors.transparent,
    notchMargin: 8,
    shape: const CircularNotchedRectangle(),
    child: Container(
      height: 56,
      decoration: const BoxDecoration(
        border: Border(top: BorderSide(color: _kLine, width: 1)),
      ),
      child: Row(
        children: [
          _BottomItem(
            icon: Icons.dashboard_rounded,
            label: 'Home',
            active: _navIndex == 0,
            onTap: () => setState(() => _navIndex = 0),
          ),
          _BottomItem(
            icon: Icons.assignment_outlined,
            label: 'Jobs',
            active: _navIndex == 1,
            onTap: () {
              setState(() => _navIndex = 1);
              _toast('Coming soon');
            },
          ),
          const Expanded(child: SizedBox()),
          _BottomItem(
            icon: Icons.bar_chart_rounded,
            label: 'Reports',
            active: _navIndex == 2,
            onTap: () {
              setState(() => _navIndex = 2);
              _toast('Coming soon');
            },
          ),
          _BottomItem(
            icon: Icons.person_outline_rounded,
            label: 'Profile',
            active: _navIndex == 3,
            onTap: () {
              setState(() => _navIndex = 3);
              _showProfile();
            },
          ),
        ],
      ),
    ),
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
//  TAB PAGES
// ═══════════════════════════════════════════════════════════════════════════════
class _JobCardsPage extends StatelessWidget {
  final AdvisorDashboardViewModel vm;
  final void Function(JobCardMode) onTap;
  const _JobCardsPage({required this.vm, required this.onTap});
  @override
  Widget build(BuildContext context) => Column(
    children: [
      Expanded(
        child: ListView.builder(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
          itemCount: vm.recentJobCards.length,
          itemBuilder: (_, i) =>
              _JobCardRow(jc: vm.recentJobCards[i], onTap: onTap),
        ),
      ),
      _SeeAllBtn('View all job cards', vm.onViewAllJobCards),
    ],
  );
}

class _ApprovalsPage extends StatelessWidget {
  final AdvisorDashboardViewModel vm;
  final void Function(PendingApprovalModel) onTap;
  const _ApprovalsPage({required this.vm, required this.onTap});
  @override
  Widget build(BuildContext context) => Column(
    children: [
      Expanded(
        child: ListView.builder(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
          itemCount: vm.pendingApprovals.length,
          itemBuilder: (_, i) =>
              _ApprovalRow(pa: vm.pendingApprovals[i], onTap: onTap),
        ),
      ),
      _SeeAllBtn('View all approvals', vm.onViewAllApprovals),
    ],
  );
}

class _RemindersPage extends StatelessWidget {
  final AdvisorDashboardViewModel vm;
  final void Function(FollowupReminderModel) onContact;
  const _RemindersPage({required this.vm, required this.onContact});
  @override
  Widget build(BuildContext context) => ListView.builder(
    padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
    itemCount: vm.followupReminders.length,
    itemBuilder: (_, i) => _ReminderRow(
      r: vm.followupReminders[i],
      onContact: () => onContact(vm.followupReminders[i]),
    ),
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
//  ROW TILES
// ═══════════════════════════════════════════════════════════════════════════════
class _JobCardRow extends StatelessWidget {
  final JobCardMode jc;
  final void Function(JobCardMode) onTap;
  const _JobCardRow({required this.jc, required this.onTap});

  _SS get _s => switch (jc.status) {
    JobCardStatus.inProgress => _SS('In Progress', _kAccent, _kAccentLight),
    JobCardStatus.pendingApproval => _SS('Pending', _kAmber, _kAmberFade),
    JobCardStatus.completed => _SS('Completed', _kEmerald, _kEmeraldFade),
    JobCardStatus.waitingParts => _SS('Waiting Parts', _kRose, _kRoseFade),
    JobCardStatus.qualityCheck => _SS('QC Check', _kViolet, _kVioletFade),
    JobCardStatus.cancelled => _SS('Cancelled', _kText3, _kSurfaceAlt),
  };

  @override
  Widget build(BuildContext context) {
    final s = _s;
    return GestureDetector(
      onTap: () => onTap(jc),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          color: _kSurface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _kLine),
          boxShadow: [
            BoxShadow(
              color: _kPrimary.withOpacity(0.05),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 3,
              height: 48,
              decoration: BoxDecoration(
                color: s.color,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(width: 11),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        jc.id,
                        style: GoogleFonts.rajdhani(
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          color: _kText1,
                          letterSpacing: 0.3,
                        ),
                      ),
                      const Spacer(),
                      _StatusBadge(s.label, s.color, s.bg),
                    ],
                  ),
                  const SizedBox(height: 3),
                  Text(
                    jc.customerName,
                    style: const TextStyle(
                      fontSize: 13,
                      color: _kText2,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Row(
                    children: [
                      const Icon(
                        Icons.directions_car_outlined,
                        size: 11,
                        color: _kText3,
                      ),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          jc.vehicleInfo,
                          style: const TextStyle(fontSize: 11, color: _kText3),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Text(
                        jc.time,
                        style: const TextStyle(fontSize: 10, color: _kText3),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 6),
            Icon(Icons.chevron_right_rounded, color: _kStroke, size: 16),
          ],
        ),
      ),
    );
  }
}

class _ApprovalRow extends StatelessWidget {
  final PendingApprovalModel pa;
  final void Function(PendingApprovalModel) onTap;
  const _ApprovalRow({required this.pa, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => onTap(pa),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          color: _kAmberFade,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFE8C97A)),
        ),
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFE8C97A)),
              ),
              child: const Icon(
                Icons.receipt_long_outlined,
                color: _kAmber,
                size: 18,
              ),
            ),
            const SizedBox(width: 11),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    pa.estimateId,
                    style: GoogleFonts.rajdhani(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: _kText1,
                      letterSpacing: 0.3,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${pa.customerName} · ${pa.vehicleId}',
                    style: const TextStyle(fontSize: 12, color: _kText2),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    pa.timeAgo,
                    style: const TextStyle(fontSize: 10, color: _kText3),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  'AED ${pa.amount.toStringAsFixed(0)}',
                  style: GoogleFonts.orbitron(
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    color: _kAmber,
                    letterSpacing: -0.3,
                  ),
                ),
                const SizedBox(height: 4),
                Icon(Icons.chevron_right_rounded, color: _kStroke, size: 14),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ReminderRow extends StatelessWidget {
  final FollowupReminderModel r;
  final VoidCallback onContact;
  const _ReminderRow({required this.r, required this.onContact});

  Color get _pc => r.priority == ReminderPriority.high
      ? _kRose
      : r.priority == ReminderPriority.medium
      ? _kAmber
      : _kAccent;
  Color get _pb => r.priority == ReminderPriority.high
      ? _kRoseFade
      : r.priority == ReminderPriority.medium
      ? _kAmberFade
      : _kAccentLight;
  String get _pl => r.priority == ReminderPriority.high
      ? 'High'
      : r.priority == ReminderPriority.medium
      ? 'Medium'
      : 'Low';

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: _kSurface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _kLine),
        boxShadow: [
          BoxShadow(
            color: _kPrimary.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 3,
            height: 56,
            decoration: BoxDecoration(
              color: _pc,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        r.customerName,
                        style: GoogleFonts.rajdhani(
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                          color: _kText1,
                          letterSpacing: 0.2,
                        ),
                      ),
                    ),
                    _StatusBadge(_pl, _pc, _pb),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  '${r.vehicleId} · ${r.task}',
                  style: const TextStyle(fontSize: 12, color: _kText2),
                ),
                const SizedBox(height: 7),
                Row(
                  children: [
                    const Icon(
                      Icons.calendar_today_outlined,
                      size: 11,
                      color: _kText3,
                    ),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        r.dueDate,
                        style: const TextStyle(fontSize: 10, color: _kText3),
                      ),
                    ),
                    GestureDetector(
                      onTap: onContact,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: _kAccentLight,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: _kAccent.withOpacity(0.25)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.phone_outlined,
                              size: 12,
                              color: _kAccent,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              'Contact',
                              style: GoogleFonts.rajdhani(
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                color: _kAccent,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
//  BOTTOM SHEETS
// ═══════════════════════════════════════════════════════════════════════════════

class _ProfileSheet extends StatelessWidget {
  final VoidCallback onLogout;
  const _ProfileSheet({required this.onLogout});
  @override
  Widget build(BuildContext context) {
    return _Sheet(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const _Handle(),
          const SizedBox(height: 20),
          // Avatar — matches dashboard profile bottom sheet
          Container(
            width: 68,
            height: 68,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [_kGStart, _kGEnd],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                'AR',
                style: GoogleFonts.rajdhani(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 26,
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Text(
            'Ali Rahman',
            style: const TextStyle(
              color: _kText1,
              fontSize: 19,
              fontWeight: FontWeight.w700,
              letterSpacing: -0.3,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'ADV-001 · Service Advisor',
            style: const TextStyle(fontSize: 13, color: _kText2),
          ),
          const SizedBox(height: 8),
          // Role pill — matches dashboard "Admin • Auto Garage ERP" chip
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: _kAccentLight,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 7,
                  height: 7,
                  decoration: const BoxDecoration(
                    color: _kEmerald,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  'On Shift — Morning',
                  style: GoogleFonts.rajdhani(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: _kAccent,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          const _Divider(),
          _MenuItem(
            icon: Icons.person_outline_rounded,
            label: 'My Profile',
            onTap: () => Navigator.pop(context),
          ),
          _MenuItem(
            icon: Icons.swap_horiz_rounded,
            label: 'Switch Branch',
            onTap: () => Navigator.pop(context),
          ),
          _MenuItem(
            icon: Icons.schedule_rounded,
            label: 'Shift Details',
            onTap: () => Navigator.pop(context),
          ),
          _MenuItem(
            icon: Icons.settings_outlined,
            label: 'Settings',
            onTap: () => Navigator.pop(context),
          ),
          const _Divider(),
          // Logout — matches dashboard OutlinedButton.icon style
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: SizedBox(
              width: double.infinity,
              height: 50,
              child: OutlinedButton.icon(
                onPressed: onLogout,
                style: OutlinedButton.styleFrom(
                  foregroundColor: _kRose,
                  side: const BorderSide(color: _kRose, width: 1.5),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                icon: const Icon(Icons.logout_rounded, size: 18),
                label: Text(
                  'Logout',
                  style: GoogleFonts.rajdhani(
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                    color: _kRose,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}

class _NotifSheet extends StatelessWidget {
  const _NotifSheet();
  @override
  Widget build(BuildContext context) {
    final items = [
      _N(
        'Estimate approved',
        'EST-2024-089 approved by customer',
        Icons.check_circle_outline_rounded,
        _kEmerald,
        '2m ago',
      ),
      _N(
        'Parts arrived',
        'Brake pads for JC-2024-087 are ready',
        Icons.inventory_2_outlined,
        _kAccent,
        '18m ago',
      ),
      _N(
        'Awaiting approval',
        'EST-2024-088 pending customer sign-off',
        Icons.pending_outlined,
        _kAmber,
        '1h ago',
      ),
    ];
    return _Sheet(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const _Handle(),
          const SizedBox(height: 16),
          Row(
            children: [
              Text(
                'Notifications',
                style: GoogleFonts.rajdhani(
                  fontSize: 19,
                  fontWeight: FontWeight.w700,
                  color: _kText1,
                  letterSpacing: 0.5,
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: _kAccentLight,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    'Clear all',
                    style: GoogleFonts.rajdhani(
                      fontSize: 12,
                      color: _kAccent,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          ...items.map((n) => _NotifRow(n: n)),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}

class _N {
  final String title, body, time;
  final IconData icon;
  final Color color;
  const _N(this.title, this.body, this.icon, this.color, this.time);
}

class _NotifRow extends StatelessWidget {
  final _N n;
  const _NotifRow({required this.n});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 8),
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: _kCanvas,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: _kLine),
    ),
    child: Row(
      children: [
        Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: n.color.withOpacity(0.10),
            shape: BoxShape.circle,
          ),
          child: Icon(n.icon, color: n.color, size: 18),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                n.title,
                style: GoogleFonts.rajdhani(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: _kText1,
                  letterSpacing: 0.2,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                n.body,
                style: const TextStyle(fontSize: 11, color: _kText2),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Text(n.time, style: const TextStyle(fontSize: 10, color: _kText3)),
      ],
    ),
  );
}

class _JobCardSheet extends StatelessWidget {
  final JobCardMode jc;
  final VoidCallback onOpen;
  const _JobCardSheet({required this.jc, required this.onOpen});

  _SS get _s => switch (jc.status) {
    JobCardStatus.inProgress => _SS('In Progress', _kAccent, _kAccentLight),
    JobCardStatus.pendingApproval => _SS('Pending', _kAmber, _kAmberFade),
    JobCardStatus.completed => _SS('Completed', _kEmerald, _kEmeraldFade),
    JobCardStatus.waitingParts => _SS('Waiting Parts', _kRose, _kRoseFade),
    JobCardStatus.qualityCheck => _SS('QC Check', _kViolet, _kVioletFade),
    JobCardStatus.cancelled => _SS('Cancelled', _kText3, _kSurfaceAlt),
  };

  @override
  Widget build(BuildContext context) {
    final s = _s;
    return _Sheet(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const _Handle(),
          const SizedBox(height: 16),
          Row(
            children: [
              Container(
                width: 4,
                height: 40,
                decoration: BoxDecoration(
                  color: s.color,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      jc.id,
                      style: GoogleFonts.rajdhani(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: _kText1,
                        letterSpacing: 0.3,
                      ),
                    ),
                    Text(
                      jc.customerName,
                      style: const TextStyle(fontSize: 13, color: _kText2),
                    ),
                  ],
                ),
              ),
              _StatusBadge(s.label, s.color, s.bg),
            ],
          ),
          const SizedBox(height: 18),
          const _Divider(),
          const SizedBox(height: 12),
          _DetailLine(
            icon: Icons.directions_car_outlined,
            label: 'Vehicle',
            value: jc.vehicleInfo,
          ),
          _DetailLine(
            icon: Icons.schedule_outlined,
            label: 'Created',
            value: jc.time,
          ),
          _DetailLine(
            icon: Icons.person_outline_rounded,
            label: 'Advisor',
            value: 'Ali Rahman',
          ),
          _DetailLine(
            icon: Icons.build_outlined,
            label: 'Bay',
            value: 'Bay 03',
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(
                child: _OutlineAction(
                  label: 'Call Customer',
                  icon: Icons.phone_outlined,
                  color: _kAccent,
                  onTap: () => Navigator.pop(context),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _SolidAction(
                  label: 'Open Job Card',
                  icon: Icons.open_in_new_rounded,
                  gradient: _kHeaderGrad,
                  onTap: onOpen,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
        ],
      ),
    );
  }
}

class _ApprovalSheet extends StatelessWidget {
  final PendingApprovalModel pa;
  final VoidCallback onApprove;
  final VoidCallback onReject;
  const _ApprovalSheet({
    required this.pa,
    required this.onApprove,
    required this.onReject,
  });
  @override
  Widget build(BuildContext context) => _Sheet(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const _Handle(),
        const SizedBox(height: 16),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 16),
          decoration: BoxDecoration(
            color: _kCanvas,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _kLine),
          ),
          child: Column(
            children: [
              Text(
                'AED ${pa.amount.toStringAsFixed(0)}',
                style: GoogleFonts.orbitron(
                  fontSize: 34,
                  fontWeight: FontWeight.w800,
                  color: _kText1,
                  letterSpacing: -1.0,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '${pa.estimateId} · ${pa.customerName}',
                style: const TextStyle(fontSize: 13, color: _kText2),
              ),
              const SizedBox(height: 2),
              Text(
                pa.timeAgo,
                style: const TextStyle(fontSize: 11, color: _kText3),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _DetailLine(
          icon: Icons.directions_car_outlined,
          label: 'Vehicle',
          value: pa.vehicleId,
        ),
        _DetailLine(
          icon: Icons.receipt_long_outlined,
          label: 'Estimate',
          value: pa.estimateId,
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _OutlineAction(
                label: 'Send Back',
                icon: Icons.undo_rounded,
                color: _kRose,
                onTap: onReject,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _SolidAction(
                label: 'Approve',
                icon: Icons.check_rounded,
                gradient: [_kEmerald, const Color(0xFF2DD4BF)],
                onTap: onApprove,
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
      ],
    ),
  );
}

class _ContactSheet extends StatelessWidget {
  final FollowupReminderModel r;
  final VoidCallback onCall, onWhatsApp, onSms, onDone;
  const _ContactSheet({
    required this.r,
    required this.onCall,
    required this.onWhatsApp,
    required this.onSms,
    required this.onDone,
  });
  @override
  Widget build(BuildContext context) => _Sheet(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const _Handle(),
        const SizedBox(height: 16),
        Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: _kAccentLight,
                shape: BoxShape.circle,
                border: Border.all(
                  color: _kAccent.withOpacity(0.2),
                  width: 1.5,
                ),
              ),
              child: Center(
                child: Text(
                  r.customerName.substring(0, 1),
                  style: GoogleFonts.rajdhani(
                    color: _kAccent,
                    fontWeight: FontWeight.w900,
                    fontSize: 22,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    r.customerName,
                    style: GoogleFonts.rajdhani(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: _kText1,
                      letterSpacing: 0.3,
                    ),
                  ),
                  Text(
                    '${r.vehicleId} · ${r.task}',
                    style: const TextStyle(fontSize: 13, color: _kText2),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        const _Divider(),
        const SizedBox(height: 18),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _ContactOpt(
              icon: Icons.phone_rounded,
              label: 'Call',
              color: _kAccent,
              onTap: onCall,
            ),
            _ContactOpt(
              icon: Icons.chat_rounded,
              label: 'WhatsApp',
              color: const Color(0xFF25D366),
              onTap: onWhatsApp,
            ),
            _ContactOpt(
              icon: Icons.sms_outlined,
              label: 'SMS',
              color: _kViolet,
              onTap: onSms,
            ),
          ],
        ),
        const SizedBox(height: 18),
        _SolidAction(
          label: 'Mark Reminder as Done',
          icon: Icons.check_circle_outline_rounded,
          gradient: [_kEmerald, const Color(0xFF2DD4BF)],
          onTap: onDone,
        ),
        const SizedBox(height: 6),
      ],
    ),
  );
}

class _ContactOpt extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _ContactOpt({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Column(
      children: [
        Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(
            color: color.withOpacity(0.10),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: color, size: 26),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: GoogleFonts.rajdhani(
            fontSize: 12,
            fontWeight: FontWeight.w700,
            color: _kText2,
          ),
        ),
      ],
    ),
  );
}

class _SearchSheet extends StatefulWidget {
  final VoidCallback onScan;
  const _SearchSheet({required this.onScan});
  @override
  State<_SearchSheet> createState() => _SearchSheetState();
}

class _SearchSheetState extends State<_SearchSheet> {
  final _ctrl = TextEditingController();
  final _filters = <String>{};
  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => _Sheet(
    child: Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const _Handle(),
          const SizedBox(height: 14),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Search',
              style: GoogleFonts.rajdhani(
                fontSize: 19,
                fontWeight: FontWeight.w700,
                color: _kText1,
                letterSpacing: 0.5,
              ),
            ),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _ctrl,
            autofocus: true,
            style: const TextStyle(fontSize: 13, color: _kText1),
            decoration: InputDecoration(
              hintText: 'Name, plate, phone, email…',
              hintStyle: GoogleFonts.rajdhani(color: _kText3, fontSize: 13),
              prefixIcon: const Icon(
                Icons.search_rounded,
                color: _kText3,
                size: 20,
              ),
              suffixIcon: GestureDetector(
                onTap: widget.onScan,
                child: Container(
                  margin: const EdgeInsets.all(8),
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: _kHeaderGrad),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.qr_code_scanner_rounded,
                    color: Colors.white,
                    size: 16,
                  ),
                ),
              ),
              filled: true,
              fillColor: _kCanvas,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: _kLine),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: _kLine),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: _kAccent, width: 1.5),
              ),
              contentPadding: const EdgeInsets.symmetric(vertical: 13),
            ),
          ),
          const SizedBox(height: 14),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Filter by status',
              style: GoogleFonts.rajdhani(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: _kText2,
                letterSpacing: 0.3,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 7,
            children: ['In Progress', 'Pending Approval', 'Ready', 'Today Only']
                .map((f) {
                  final sel = _filters.contains(f);
                  return GestureDetector(
                    onTap: () => setState(
                      () => sel ? _filters.remove(f) : _filters.add(f),
                    ),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 140),
                      margin: const EdgeInsets.only(bottom: 6),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 13,
                        vertical: 7,
                      ),
                      decoration: BoxDecoration(
                        color: sel ? _kAccent : _kCanvas,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: sel ? _kAccent : _kStroke),
                      ),
                      child: Text(
                        f,
                        style: GoogleFonts.rajdhani(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: sel ? Colors.white : _kText2,
                        ),
                      ),
                    ),
                  );
                })
                .toList(),
          ),
          const SizedBox(height: 14),
          _SolidAction(
            label: 'Search',
            icon: Icons.search_rounded,
            gradient: _kHeaderGrad,
            onTap: () => Navigator.pop(context),
          ),
          const SizedBox(height: 8),
        ],
      ),
    ),
  );
}

class _StatDialog extends StatelessWidget {
  final String label;
  final int count;
  final Color color;
  const _StatDialog({
    required this.label,
    required this.count,
    required this.color,
  });
  @override
  Widget build(BuildContext context) => Dialog(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    backgroundColor: _kSurface,
    elevation: 0,
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              color: color.withOpacity(0.10),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                '$count',
                style: GoogleFonts.orbitron(
                  fontSize: 28,
                  fontWeight: FontWeight.w800,
                  color: color,
                  letterSpacing: -0.5,
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Text(
            label,
            style: GoogleFonts.rajdhani(
              fontSize: 19,
              fontWeight: FontWeight.w700,
              color: _kText1,
              letterSpacing: 0.3,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Tap below to view the full list',
            style: const TextStyle(fontSize: 12, color: _kText2),
          ),
          const SizedBox(height: 22),
          Row(
            children: [
              Expanded(
                child: _OutlineAction(
                  label: 'Close',
                  icon: Icons.close_rounded,
                  color: _kSlate,
                  onTap: () => Navigator.pop(context),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _SolidAction(
                  label: 'View all',
                  icon: Icons.arrow_forward_rounded,
                  gradient: [color, color.withOpacity(0.75)],
                  onTap: () => Navigator.pop(context),
                ),
              ),
            ],
          ),
        ],
      ),
    ),
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
//  REUSABLE PRIMITIVES  (all typography now uses GoogleFonts.rajdhani / orbitron)
// ═══════════════════════════════════════════════════════════════════════════════

class _Sheet extends StatelessWidget {
  final Widget child;
  const _Sheet({required this.child});
  @override
  Widget build(BuildContext context) => Container(
    decoration: const BoxDecoration(
      color: _kSurface,
      borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
    ),
    padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
    child: child,
  );
}

class _Handle extends StatelessWidget {
  const _Handle();
  @override
  Widget build(BuildContext context) => Center(
    child: Container(
      margin: const EdgeInsets.only(top: 12),
      width: 40,
      height: 4,
      decoration: BoxDecoration(
        color: _kLine,
        borderRadius: BorderRadius.circular(2),
      ),
    ),
  );
}

class _Avatar extends StatelessWidget {
  final String initials;
  final double size;
  const _Avatar({required this.initials, required this.size});
  @override
  Widget build(BuildContext context) => Container(
    width: size,
    height: size,
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(0.20),
      shape: BoxShape.circle,
      border: Border.all(color: Colors.white.withOpacity(0.5), width: 1.5),
    ),
    child: Center(
      child: Text(
        initials,
        style: GoogleFonts.rajdhani(
          color: Colors.white,
          fontWeight: FontWeight.w900,
          fontSize: 16,
        ),
      ),
    ),
  );
}

class _MetaPill extends StatelessWidget {
  final IconData icon;
  final String label;
  const _MetaPill({required this.icon, required this.label});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(0.10),
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: Colors.white.withOpacity(0.15)),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: Colors.white.withOpacity(0.55), size: 11),
        const SizedBox(width: 5),
        Text(
          label,
          style: GoogleFonts.rajdhani(
            color: Colors.white.withOpacity(0.75),
            fontSize: 12,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.2,
          ),
        ),
      ],
    ),
  );
}

class _HeaderBtn extends StatelessWidget {
  final String label;
  final IconData? icon;
  final bool isPrimary;
  final VoidCallback onTap;
  const _HeaderBtn({
    required this.label,
    this.icon,
    required this.isPrimary,
    required this.onTap,
  });
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      height: 44,
      decoration: BoxDecoration(
        color: isPrimary ? Colors.white : Colors.white.withOpacity(0.13),
        borderRadius: BorderRadius.circular(14),
        border: isPrimary
            ? null
            : Border.all(color: Colors.white.withOpacity(0.22)),
        boxShadow: isPrimary
            ? [
                BoxShadow(
                  color: Colors.black.withOpacity(0.12),
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ]
            : null,
      ),
      child: Center(
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Icon(icon, color: isPrimary ? _kPrimary : Colors.white, size: 15),
              const SizedBox(width: 6),
            ],
            Text(
              label,
              style: GoogleFonts.rajdhani(
                color: isPrimary ? _kPrimary : Colors.white,
                fontWeight: FontWeight.w800,
                fontSize: 14,
                letterSpacing: 0.3,
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

class _TabBtn extends StatefulWidget {
  final String label;
  final int index;
  final TabController ctrl;
  final String? badge;
  final Color badgeColor;
  const _TabBtn({
    required this.label,
    required this.index,
    required this.ctrl,
    this.badge,
    this.badgeColor = _kAccent,
  });
  @override
  State<_TabBtn> createState() => _TabBtnState();
}

class _TabBtnState extends State<_TabBtn> {
  @override
  void initState() {
    super.initState();
    widget.ctrl.addListener(() {
      if (mounted) setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    final on = widget.ctrl.index == widget.index;
    return Expanded(
      child: GestureDetector(
        onTap: () => widget.ctrl.animateTo(widget.index),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOutCubic,
          margin: const EdgeInsets.all(4),
          padding: const EdgeInsets.symmetric(vertical: 9),
          decoration: BoxDecoration(
            color: on ? _kSurface : Colors.transparent,
            borderRadius: BorderRadius.circular(10),
            boxShadow: on
                ? [
                    BoxShadow(
                      color: _kPrimary.withOpacity(0.07),
                      blurRadius: 6,
                      offset: const Offset(0, 2),
                    ),
                  ]
                : [],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                widget.label,
                style: GoogleFonts.rajdhani(
                  fontSize: 13,
                  fontWeight: on ? FontWeight.w800 : FontWeight.w600,
                  color: on ? _kText1 : _kText3,
                  letterSpacing: on ? 0.3 : 0,
                ),
              ),
              if (widget.badge != null) ...[
                const SizedBox(width: 5),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 6,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: on
                        ? widget.badgeColor
                        : widget.badgeColor.withOpacity(0.6),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    widget.badge!,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _SeeAllBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _SeeAllBtn(this.label, this.onTap);
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 13),
      decoration: const BoxDecoration(
        border: Border(top: BorderSide(color: _kLine)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            label,
            style: GoogleFonts.rajdhani(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: _kAccent,
              letterSpacing: 0.3,
            ),
          ),
          const SizedBox(width: 5),
          const Icon(Icons.arrow_forward_rounded, color: _kAccent, size: 13),
        ],
      ),
    ),
  );
}

class _StatusBadge extends StatelessWidget {
  final String label;
  final Color color;
  final Color bg;
  const _StatusBadge(this.label, this.color, this.bg);
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
    decoration: BoxDecoration(
      color: bg,
      borderRadius: BorderRadius.circular(7),
    ),
    child: Text(
      label,
      style: GoogleFonts.rajdhani(
        fontSize: 10,
        fontWeight: FontWeight.w800,
        color: color,
        letterSpacing: 0.3,
      ),
    ),
  );
}

class _MenuItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color? color;
  final VoidCallback onTap;
  final bool showChevron;
  const _MenuItem({
    required this.icon,
    required this.label,
    this.color,
    required this.onTap,
    this.showChevron = true,
  });
  @override
  Widget build(BuildContext context) {
    final c = color ?? _kText1;
    return ListTile(
      contentPadding: EdgeInsets.zero,
      dense: true,
      leading: Container(
        width: 34,
        height: 34,
        decoration: BoxDecoration(
          color: c.withOpacity(0.07),
          borderRadius: BorderRadius.circular(9),
        ),
        child: Icon(icon, color: c, size: 17),
      ),
      title: Text(
        label,
        style: GoogleFonts.rajdhani(
          fontSize: 14,
          fontWeight: FontWeight.w700,
          color: c,
          letterSpacing: 0.2,
        ),
      ),
      trailing: showChevron
          ? Icon(Icons.chevron_right_rounded, color: _kStroke, size: 18)
          : null,
      onTap: onTap,
    );
  }
}

class _DetailLine extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _DetailLine({
    required this.icon,
    required this.label,
    required this.value,
  });
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 11),
    child: Row(
      children: [
        Icon(icon, size: 14, color: _kText3),
        const SizedBox(width: 9),
        Text(
          label,
          style: GoogleFonts.rajdhani(
            fontSize: 13,
            color: _kText2,
            fontWeight: FontWeight.w600,
          ),
        ),
        const Spacer(),
        Text(
          value,
          style: GoogleFonts.rajdhani(
            fontSize: 13,
            fontWeight: FontWeight.w800,
            color: _kText1,
            letterSpacing: 0.2,
          ),
        ),
      ],
    ),
  );
}

class _OutlineAction extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _OutlineAction({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.45), width: 1.5),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 15),
          const SizedBox(width: 6),
          Text(
            label,
            style: GoogleFonts.rajdhani(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: color,
              letterSpacing: 0.3,
            ),
          ),
        ],
      ),
    ),
  );
}

/// [_SolidAction] uses gradient to match dashboard _ActionButton style.
class _SolidAction extends StatelessWidget {
  final String label;
  final IconData icon;
  final List<Color> gradient;
  final VoidCallback onTap;
  const _SolidAction({
    required this.label,
    required this.icon,
    required this.gradient,
    required this.onTap,
  });
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: gradient),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: gradient.first.withOpacity(0.30),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: Colors.white, size: 15),
          const SizedBox(width: 6),
          Text(
            label,
            style: GoogleFonts.rajdhani(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    ),
  );
}

class _Divider extends StatelessWidget {
  const _Divider();
  @override
  Widget build(BuildContext context) => Container(
    height: 1,
    color: _kLine,
    margin: const EdgeInsets.symmetric(vertical: 4),
  );
}

class _DateChip extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    final label = '${now.day} ${months[now.month - 1]} ${now.year}';
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5),
      decoration: BoxDecoration(
        color: _kSurface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _kLine),
        boxShadow: [
          BoxShadow(
            color: _kPrimary.withOpacity(0.05),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Text(
        label,
        style: GoogleFonts.rajdhani(
          fontSize: 12,
          color: _kText2,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.2,
        ),
      ),
    );
  }
}

class _BottomItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;
  const _BottomItem({
    required this.icon,
    required this.label,
    required this.active,
    required this.onTap,
  });
  @override
  Widget build(BuildContext context) => Expanded(
    child: GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeOutCubic,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
            decoration: BoxDecoration(
              color: active ? _kAccentLight : Colors.transparent,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Icon(icon, color: active ? _kAccent : _kText3, size: 22),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: GoogleFonts.rajdhani(
              fontSize: 11,
              color: active ? _kAccent : _kText3,
              fontWeight: active ? FontWeight.w800 : FontWeight.w500,
              letterSpacing: active ? 0.2 : 0,
            ),
          ),
        ],
      ),
    ),
  );
}

class _SS {
  final String label;
  final Color color;
  final Color bg;
  const _SS(this.label, this.color, this.bg);
}
