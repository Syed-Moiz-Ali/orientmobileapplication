// lib/advisor_dashboard/inspectionpages/inspection_vew_model.dart

import 'dart:io';
import 'package:flutter/material.dart';
import 'inspection_model.dart';

// ── Per-item media & note data ─────────────────────────────────────────────
class ItemMedia {
  List<String> photoPaths;   // file paths from camera / gallery
  List<String> videoPaths;   // file paths from camera
  String audioPath;          // file path from recorder
  String note;

  ItemMedia({
    List<String>? photoPaths,
    List<String>? videoPaths,
    this.audioPath = '',
    this.note = '',
  })  : photoPaths = photoPaths ?? [],
        videoPaths = videoPaths ?? [];

  bool get hasMedia =>
      photoPaths.isNotEmpty ||
      videoPaths.isNotEmpty ||
      audioPath.isNotEmpty ||
      note.isNotEmpty;
}

// ── Service line item ──────────────────────────────────────────────────────
class ServiceLineItem {
  final String name;
  int qty;
  double rate;
  double discountPercent;
  double discountAmount;

  ServiceLineItem({
    required this.name,
    this.qty = 1,
    this.rate = 0,
    this.discountPercent = 0,
    this.discountAmount = 0,
  });

  double get amount => (rate * qty) - discountAmount;
}

// ── Part line item ─────────────────────────────────────────────────────────
class PartLineItem {
  final String name;
  int qty;
  double rate;
  double discountPercent;
  double discountAmount;

  PartLineItem({
    required this.name,
    this.qty = 1,
    this.rate = 0,
    this.discountPercent = 0,
    this.discountAmount = 0,
  });

  double get amount => (rate * qty) - discountAmount;
}

// ─────────────────────────────────────────────────────────────────────────────
//  MAIN VIEW MODEL
// ─────────────────────────────────────────────────────────────────────────────
class InspectionViewModel extends ChangeNotifier {

  // ── Inspection state ───────────────────────────────────────────────────────
  final Map<String, ItemStatus> statuses = {};
  final Map<String, bool> collapsed = {};
  final Map<String, ItemMedia> media = {};   // keyed by itemId
  bool notifyOwner = false;
  String globalSearch = '';
  final Map<String, String> sectionSearch = {};
  bool showAll = true;

  // ── Pre-service media ──────────────────────────────────────────────────────
  List<String> preServicePhotos = [];

  // ── Repair order state ─────────────────────────────────────────────────────
  List<ServiceLineItem> serviceLines = [];
  List<PartLineItem> partLines = [];
  String referenceNumber = '';
  String placeOfSupply = '';
  String customerRequests = '';
  String garageRecommendations = '';
  DateTime? estimatedDelivery;
  bool notifyOwnerSmsEmail = false;
  String tag = '';

  // ── Getters ────────────────────────────────────────────────────────────────
  int get totalItems =>
      kInspectionSections.fold(0, (sum, s) => sum + s.items.length);

  int get completedCount => statuses.length;

  double get progressPercent =>
      totalItems == 0 ? 0 : completedCount / totalItems;

  double get servicesTotal =>
      serviceLines.fold(0, (sum, s) => sum + s.amount);

  double get partsTotal =>
      partLines.fold(0, (sum, p) => sum + p.amount);

  double get grandTotal => servicesTotal + partsTotal;

  ItemMedia mediaOf(String itemId) =>
      media.putIfAbsent(itemId, () => ItemMedia());

  // ── Inspection mutations ───────────────────────────────────────────────────
  void setStatus(String itemId, ItemStatus? status) {
    if (status == null) {
      statuses.remove(itemId);
    } else if (statuses[itemId] == status) {
      statuses.remove(itemId); // toggle off
    } else {
      statuses[itemId] = status;
    }
    notifyListeners();
  }

  void toggleCollapse(String sectionId) {
    collapsed[sectionId] = !(collapsed[sectionId] ?? false);
    notifyListeners();
  }

  void setShowAll() {
    showAll = true;
    collapsed.clear();
    notifyListeners();
  }

  void setCollapseAll() {
    showAll = false;
    for (final s in kInspectionSections) {
      collapsed[s.id] = true;
    }
    notifyListeners();
  }

  void setGlobalSearch(String q) {
    globalSearch = q;
    notifyListeners();
  }

  void setSectionSearch(String sectionId, String q) {
    sectionSearch[sectionId] = q;
    notifyListeners();
  }

  void toggleNotifyOwner() {
    notifyOwner = !notifyOwner;
    notifyListeners();
  }

  // ── Media mutations ────────────────────────────────────────────────────────
  void addPhoto(String itemId, String path) {
    mediaOf(itemId).photoPaths.add(path);
    notifyListeners();
  }

  void addVideo(String itemId, String path) {
    mediaOf(itemId).videoPaths.add(path);
    notifyListeners();
  }

  void setAudio(String itemId, String path) {
    mediaOf(itemId).audioPath = path;
    notifyListeners();
  }

  void setNote(String itemId, String note) {
    mediaOf(itemId).note = note;
    notifyListeners();
  }

  void removePhoto(String itemId, int index) {
    mediaOf(itemId).photoPaths.removeAt(index);
    notifyListeners();
  }

  void removeVideo(String itemId, int index) {
    mediaOf(itemId).videoPaths.removeAt(index);
    notifyListeners();
  }

  void addPreServicePhoto(String path) {
    preServicePhotos.add(path);
    notifyListeners();
  }

  // ── Filtered sections ──────────────────────────────────────────────────────
  List<InspectionSection> get filteredSections {
    return kInspectionSections.map((sec) {
      final filtered = sec.items.where((item) {
        final g = item.toLowerCase().contains(globalSearch.toLowerCase());
        final s = item.toLowerCase()
            .contains((sectionSearch[sec.id] ?? '').toLowerCase());
        return g && s;
      }).toList();
      return InspectionSection(id: sec.id, label: sec.label, items: filtered);
    }).toList();
  }

  // ── Repair order mutations ─────────────────────────────────────────────────
  void addServices(List<String> names) {
    // Preserve existing lines, add new ones
    final existing = serviceLines.map((s) => s.name).toSet();
    for (final n in names) {
      if (!existing.contains(n)) serviceLines.add(ServiceLineItem(name: n));
    }
    // Remove deselected
    serviceLines.removeWhere((s) => !names.contains(s.name));
    notifyListeners();
  }

  void addParts(List<String> names) {
    final existing = partLines.map((p) => p.name).toSet();
    for (final n in names) {
      if (!existing.contains(n)) partLines.add(PartLineItem(name: n));
    }
    partLines.removeWhere((p) => !names.contains(p.name));
    notifyListeners();
  }

  void updateServiceLine(int index, {int? qty, double? rate, double? discountPct, double? discountAmt}) {
    if (index < 0 || index >= serviceLines.length) return;
    final s = serviceLines[index];
    if (qty != null) s.qty = qty;
    if (rate != null) s.rate = rate;
    if (discountPct != null) s.discountPercent = discountPct;
    if (discountAmt != null) s.discountAmount = discountAmt;
    notifyListeners();
  }

  void updatePartLine(int index, {int? qty, double? rate, double? discountPct, double? discountAmt}) {
    if (index < 0 || index >= partLines.length) return;
    final p = partLines[index];
    if (qty != null) p.qty = qty;
    if (rate != null) p.rate = rate;
    if (discountPct != null) p.discountPercent = discountPct;
    if (discountAmt != null) p.discountAmount = discountAmt;
    notifyListeners();
  }

  void setReferenceNumber(String v) { referenceNumber = v; notifyListeners(); }
  void setPlaceOfSupply(String v) { placeOfSupply = v; notifyListeners(); }
  void setCustomerRequests(String v) { customerRequests = v; notifyListeners(); }
  void setGarageRecommendations(String v) { garageRecommendations = v; notifyListeners(); }
  void setEstimatedDelivery(DateTime dt) { estimatedDelivery = dt; notifyListeners(); }
  void toggleNotifyOwnerSmsEmail() { notifyOwnerSmsEmail = !notifyOwnerSmsEmail; notifyListeners(); }
  void setTag(String v) { tag = v; notifyListeners(); }

  void reset() {
    statuses.clear();
    collapsed.clear();
    media.clear();
    preServicePhotos.clear();
    notifyOwner = false;
    globalSearch = '';
    sectionSearch.clear();
    showAll = true;
    serviceLines.clear();
    partLines.clear();
    referenceNumber = '';
    placeOfSupply = '';
    customerRequests = '';
    garageRecommendations = '';
    estimatedDelivery = null;
    notifyOwnerSmsEmail = false;
    tag = '';
    notifyListeners();
  }

  void res(){
   statuses.clear();
   globalSearch="";
   showAll=true;
   tag = "";
   notifyListeners();
   estimatedDelivery=null;
   customerRequests="";

   
  }
}
