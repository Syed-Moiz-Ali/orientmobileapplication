// lib/advisor_dashboard/inspectionpages/inspection_widgets.dart

import 'package:flutter/material.dart';
import 'inspection_model.dart';

// ── Colors ────────────────────────────────────────────────────────────────────
class IC {
  static const navy     = Color(0xFF0F1D3A);
  static const accent   = Color(0xFF2B6BE6);
  static const accentBg = Color(0xFFEBF1FC);
  static const surface  = Color(0xFFFFFFFF);
  static const canvas   = Color(0xFFF4F6FA);
  static const line     = Color(0xFFE9ECF2);
  static const stroke   = Color(0xFFD4D9E6);
  static const text1    = Color(0xFF0F1D3A);
  static const text2    = Color(0xFF5A6478);
  static const text3    = Color(0xFF9BA5BA);

  // ── BLUE replaces all previous greens ─────────────────────────────────────
  static const green    = Color(0xFF2B6BE6);   // was green, now blue
  static const greenBg  = Color(0xFFEBF1FC);   // was green bg, now blue bg

  static const amber    = Color(0xFFB86B00);
  static const amberBg  = Color(0xFFFFF3E0);
  static const red      = Color(0xFFC0392B);
  static const redBg    = Color(0xFFFDECEC);
  static const purple   = Color(0xFF5B3FA6);
  static const purpleBg = Color(0xFFEFEBFA);
  //static const teal     = Color(0xFF0F766E);
  static const tealBg   = Color(0xFFE0F5F3);
}

// ── Status color helper ───────────────────────────────────────────────────────
({Color color, Color bg, String label}) statusColors(ItemStatus s) {
  switch (s) {
    case ItemStatus.good: return (color: IC.accent, bg: IC.accentBg, label: 'Good');   // blue
    case ItemStatus.fair: return (color: IC.amber,  bg: IC.amberBg,  label: 'Fair');
    case ItemStatus.poor: return (color: IC.red,    bg: IC.redBg,    label: 'Poor');
  }
}

// ── AppBadge ──────────────────────────────────────────────────────────────────
class AppBadge extends StatelessWidget {
  final String label;
  final Color color;
  final Color bg;
  final bool small;
  const AppBadge({super.key, required this.label, required this.color, required this.bg, this.small = false});

  @override
  Widget build(BuildContext context) => Container(
    padding: EdgeInsets.symmetric(horizontal: small ? 7 : 9, vertical: small ? 2 : 3),
    decoration: BoxDecoration(
      color: bg, borderRadius: BorderRadius.circular(6),
      border: Border.all(color: color.withOpacity(0.14)),
    ),
    child: Text(label, style: TextStyle(color: color, fontSize: small ? 10 : 11, fontWeight: FontWeight.w700, letterSpacing: 0.2)),
  );
}

// ── SolidBtn ──────────────────────────────────────────────────────────────────
class SolidBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final Color color;
  final bool small;
  final bool loading;
  const SolidBtn({super.key, required this.label, required this.onTap, this.color = IC.accent, this.small = false, this.loading = false});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: loading ? null : onTap,
    child: Container(
      padding: small ? const EdgeInsets.symmetric(horizontal: 14, vertical: 8) : const EdgeInsets.symmetric(vertical: 13),
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(10)),
      alignment: small ? null : Alignment.center,
      child: loading
          ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
          : Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13, letterSpacing: -0.1)),
    ),
  );
}

// ── OutlineBtn ────────────────────────────────────────────────────────────────
class OutlineBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final Color color;
  const OutlineBtn({super.key, required this.label, required this.onTap, this.color = IC.text2});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.5), width: 1.5),
      ),
      alignment: Alignment.center,
      child: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 13, letterSpacing: -0.1)),
    ),
  );
}

// ── StatusBoxes ───────────────────────────────────────────────────────────────
class StatusBoxes extends StatelessWidget {
  final String itemId;
  final Map<String, ItemStatus> statuses;
  final void Function(String, ItemStatus?) setStatus;
  const StatusBoxes({super.key, required this.itemId, required this.statuses, required this.setStatus});

  @override
  Widget build(BuildContext context) {
    final boxes = [
      // Good → blue (was green)
      (key: ItemStatus.good, bg: IC.accentBg, border: IC.accent, fill: IC.accent),
      (key: ItemStatus.fair, bg: IC.amberBg,  border: IC.amber,  fill: IC.amber),
      (key: ItemStatus.poor, bg: IC.redBg,    border: IC.red,    fill: IC.red),
    ];
    return Row(
      children: boxes.map((b) {
        final sel = statuses[itemId] == b.key;
        return GestureDetector(
          onTap: () => setStatus(itemId, sel ? null : b.key),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            width: 28, height: 28,
            margin: const EdgeInsets.only(left: 5),
            decoration: BoxDecoration(
              color: sel ? b.fill : b.bg,
              borderRadius: BorderRadius.circular(7),
              border: Border.all(color: b.border, width: 2),
            ),
            child: sel ? const Icon(Icons.check, color: Colors.white, size: 14) : null,
          ),
        );
      }).toList(),
    );
  }
}

// ── ActionIconBtn ─────────────────────────────────────────────────────────────
class ActionIconBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback? onTap;
  final bool active;
  const ActionIconBtn({super.key, required this.icon, required this.label, this.color = IC.text3, this.onTap, this.active = false});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Column(
      children: [
        Container(
          width: 28, height: 28,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(7),
            border: Border.all(color: active ? IC.accent : color.withOpacity(0.6), width: 1.5),
            color: active ? IC.tealBg : Colors.transparent,
          ),
          child: Icon(icon, size: 13, color: active ? IC.accent : color),
        ),
        const SizedBox(height: 2),
        Text(label, style: TextStyle(fontSize: 9, color: active ? IC.accent : color, fontWeight: FontWeight.w500)),
      ],
    ),
  );
}

// ── TealSwitch ────────────────────────────────────────────────────────────────
class TealSwitch extends StatelessWidget {
  final bool value;
  final VoidCallback onToggle;
  const TealSwitch({super.key, required this.value, required this.onToggle});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onToggle,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      width: 42, height: 24,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: value ? IC.accent : IC.stroke,
        borderRadius: BorderRadius.circular(12),
      ),
      alignment: value ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(width: 18, height: 18,
          decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle)),
    ),
  );
}

// ── SearchField ───────────────────────────────────────────────────────────────
class SearchField extends StatelessWidget {
  final String hint;
  final ValueChanged<String> onChanged;
  const SearchField({super.key, required this.hint, required this.onChanged});

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      color: IC.canvas, borderRadius: BorderRadius.circular(10),
      border: Border.all(color: IC.line, width: 1.5),
    ),
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
    child: Row(children: [
      const Icon(Icons.search, color: IC.text3, size: 16),
      const SizedBox(width: 8),
      Expanded(child: TextField(
        onChanged: onChanged,
        style: const TextStyle(fontSize: 13, color: IC.text1),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(fontSize: 13, color: IC.text3),
          isDense: true, border: InputBorder.none, contentPadding: EdgeInsets.zero,
        ),
      )),
    ]),
  );
}

// ── InfoCard ──────────────────────────────────────────────────────────────────
class InfoCard extends StatelessWidget {
  final Widget child;
  const InfoCard({super.key, required this.child});

  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: IC.surface, borderRadius: BorderRadius.circular(12),
      border: Border.all(color: IC.line, width: 1.5),
    ),
    child: child,
  );
}

// ── SmallTag ──────────────────────────────────────────────────────────────────
class SmallTag extends StatelessWidget {
  final String label;
  final Color color;
  final Color bg;
  const SmallTag({super.key, required this.label, required this.color, required this.bg});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(6)),
    child: Text(label, style: TextStyle(fontSize: 9, fontWeight: FontWeight.w800, color: color)),
  );
}