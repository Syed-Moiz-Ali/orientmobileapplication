// lib/advisor_dashboard/inspectionpages/vehicle_inspection_flow.dart
//
// ─── HOW TO USE ───────────────────────────────────────────────────────────────
//
// From AdvisorHomeView, call:
//
//   launchInspectionFlow(context);
//
// Or wire into the "+ New Job Card" button:
//
//   void _openNewJobCard() => launchInspectionFlow(context);
//
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'choose_inspection_view.dart';
import 'inspection_sheet_view.dart';
import 'inspection_preview_view.dart';
import 'inspection_vew_model.dart';
import 'repair_order_view.dart';

enum _FlowScreen { choose, sheet, preview, repairOrder }

class VehicleInspectionFlow extends StatefulWidget {
  const VehicleInspectionFlow({super.key});

  @override
  State<VehicleInspectionFlow> createState() => _VehicleInspectionFlowState();
}

class _VehicleInspectionFlowState extends State<VehicleInspectionFlow> {
  _FlowScreen _screen = _FlowScreen.choose;
  bool _fromInspection = false;

  void _go(_FlowScreen s) => setState(() => _screen = s);

  void _toast(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.white)),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      margin: const EdgeInsets.all(12),
      duration: const Duration(seconds: 2),
    ));
  }

  @override
  Widget build(BuildContext context) {
    switch (_screen) {

      // ── 1. Choose Inspection ────────────────────────────────────────────
      case _FlowScreen.choose:
        return ChooseInspectionView(
          onBack: () => Navigator.pop(context),
          onSelect: () => _go(_FlowScreen.sheet),
          onSkip: () {
            _fromInspection = false;
            _go(_FlowScreen.repairOrder);
          },
        );

      // ── 2. Inspection Sheet ─────────────────────────────────────────────
      case _FlowScreen.sheet:
        return InspectionSheetView(
          onBack: () => _go(_FlowScreen.choose),
          onSaveDraft: () {
            _toast('Draft saved', const Color(0xFFB86B00));
          },
          onPreview: () => _go(_FlowScreen.preview),
        );

      // ── 3. Inspection Preview ────────────────────────────────────────────
      case _FlowScreen.preview:
        return InspectionPreviewView(
          onBack: () => _go(_FlowScreen.sheet),
          onSubmit: () {
            HapticFeedback.mediumImpact();
            _fromInspection = true;
            _go(_FlowScreen.repairOrder);
            _toast('Inspection submitted', const Color(0xFF1A7A4A));
          },
        );

      // ── 4. Repair Order ──────────────────────────────────────────────────
      case _FlowScreen.repairOrder:
        return RepairOrderView(
          onBack: () => Navigator.pop(context),
          fromInspection: _fromInspection,
        );
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  CONVENIENCE LAUNCHER — call this from any button
// ─────────────────────────────────────────────────────────────────────────────
void launchInspectionFlow(BuildContext context) {
  HapticFeedback.mediumImpact();
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => ChangeNotifierProvider<InspectionViewModel>(
        create: (_) => InspectionViewModel(),
        child: const VehicleInspectionFlow(),
      ),
    ),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
//  LAUNCH DIRECTLY TO SHEET (from home "Inspection" button)
// ─────────────────────────────────────────────────────────────────────────────
void launchInspectionSheetDirect(BuildContext context) {
  HapticFeedback.mediumImpact();
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => ChangeNotifierProvider<InspectionViewModel>(
        create: (_) => InspectionViewModel(),
        child: _DirectSheetFlow(),
      ),
    ),
  );
}

class _DirectSheetFlow extends StatefulWidget {
  @override
  State<_DirectSheetFlow> createState() => _DirectSheetFlowState();
}

class _DirectSheetFlowState extends State<_DirectSheetFlow> {
  bool _preview = false;

  @override
  Widget build(BuildContext context) {
    if (_preview) {
      return InspectionPreviewView(
        onBack: () => setState(() => _preview = false),
        onSubmit: () {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Inspection submitted'),
            backgroundColor: Color(0xFF1A7A4A),
            behavior: SnackBarBehavior.floating,
          ));
          Navigator.pop(context);
        },
      );
    }
    return InspectionSheetView(
      onBack: () => Navigator.pop(context),
      onSaveDraft: () {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Draft saved'),
          backgroundColor: Color(0xFFB86B00),
          behavior: SnackBarBehavior.floating,
        ));
      },
      onPreview: () => setState(() => _preview = true),
    );
  }
}
