// lib/advisor_dashboard/inspectionpages/choose_inspection_view.dart

import 'package:flutter/material.dart';
import 'package:orientmobileapplication/advisor_dashboard/inspectionpages/inspection_sheet_view.dart';
import 'package:orientmobileapplication/advisor_dashboard/inspectionpages/inspection_vew_model.dart';
import 'package:orientmobileapplication/advisor_dashboard/inspectionpages/repair_order_view.dart';
import 'package:provider/provider.dart';
import 'inspection_widgets.dart';

class ChooseInspectionView extends StatelessWidget {
  final VoidCallback onSelect;
  final VoidCallback onSkip;
  final VoidCallback onBack;

  const ChooseInspectionView({
    super.key,
    required this.onSelect,
    required this.onSkip,
    required this.onBack,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: IC.canvas,

      // ── AppBar ─────────────────────────────────────────────
      appBar: AppBar(
        backgroundColor: IC.navy,
        elevation: 0,
        centerTitle: false,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: onBack,
        ),
        title: const Text(
          'Choose Inspection',
          style: TextStyle(
            color: Colors.white,
            fontSize: 15,
            fontWeight: FontWeight.w700,
          ),
        ),
        actions: [
          Center(
            child: Padding(
              padding: const EdgeInsets.only(right: 16),
              child: GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => RepairOrderView(
                        onBack: () => Navigator.pop(context),
                        fromInspection: true,
                      ),
                    ),
                  );
                },
                child: const Text(
                  'SKIP INSPECTION',
                  style: TextStyle(
                    color: IC.text3,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.3,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),

      // ── Body ──────────────────────────────────────────────
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: InfoCard(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Icon
              Container(
                width: 40,
                height: 40,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: IC.tealBg,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.assignment_turned_in_outlined,
                  color: IC.accent,
                  size: 20,
                ),
              ),

              const SizedBox(width: 12),

              // Text
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    Text(
                      'Vehicle Inspection Sheet',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: IC.text1,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      '4 sections · 24 items',
                      style: TextStyle(
                        fontSize: 11,
                        color: IC.text2,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 12),

              // Button
              SolidBtn(
                label: 'SELECT AND CONTINUE',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ChangeNotifierProvider(
                        create: (_) => InspectionViewModel(),
                        child: InspectionSheetView(
                          onBack: () => Navigator.pop(context),
                          onSaveDraft: () {
                            // TODO: Save draft logic
                          },
                          onPreview: () {
                            // TODO: Preview logic
                          },
                        ),
                      ),
                    ),
                  );
                },
                color: IC.accent,
                small: true,
              ),
            ],
          ),
        ),
      ),
    );
  }
}