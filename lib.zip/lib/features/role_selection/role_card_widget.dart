import 'package:flutter/material.dart';
import 'package:orientmobileapplication/features/login_pages/login_view.dart';
import 'package:orientmobileapplication/features/role_selection/role_selection_viewmodel.dart';
import 'package:orientmobileapplication/features/role_selection/user_role_model.dart';
import 'package:provider/provider.dart';

class RoleCardWidget extends StatefulWidget {
  final UserRoleModel roleModel;

  const RoleCardWidget({super.key, required this.roleModel});

  @override
  State<RoleCardWidget> createState() => _RoleCardWidgetState();
}

class _RoleCardWidgetState extends State<RoleCardWidget>
    with SingleTickerProviderStateMixin {
  bool _isHovered = false;
  late AnimationController _controller;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );
    _scaleAnim = Tween<double>(
      begin: 1.0,
      end: 0.98,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _onHover(bool hovering) {
    setState(() => _isHovered = hovering);
    hovering ? _controller.forward() : _controller.reverse();
  }

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<RoleSelectionViewModel>();
    final isLoading = vm.isLoadingFor(widget.roleModel.role);

    return MouseRegion(
      onEnter: (_) => _onHover(true),
      onExit: (_) => _onHover(false),
      child: GestureDetector(
        onTapDown: (_) => _controller.forward(),
        onTapUp: (_) => _controller.reverse(),
        onTapCancel: () => _controller.reverse(),
        onTap: isLoading
            ? null
            : () => context.read<RoleSelectionViewModel>().proceedWithRole(
                context,
                widget.roleModel.role,
                onSuccess: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => LoginView(role: widget.roleModel.role),
                    ),
                  );
                },
              ),
        child: ScaleTransition(
          scale: _scaleAnim,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
            decoration: BoxDecoration(
              color: _isHovered
                  ? Colors.white.withOpacity(0.14)
                  : Colors.white.withOpacity(0.08),
              border: Border.all(
                color: _isHovered
                    ? Colors.white.withOpacity(0.28)
                    : Colors.white.withOpacity(0.14),
                width: 1,
              ),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: widget.roleModel.iconBackgroundColor,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    widget.roleModel.icon,
                    color: Colors.white,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 14),

                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        widget.roleModel.title,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.1,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        widget.roleModel.subtitle,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.65),
                          fontSize: 12,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),

                if (isLoading)
                  const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2,
                    ),
                  )
                else
                  Icon(
                    Icons.chevron_right_rounded,
                    color: Colors.white.withOpacity(0.6),
                    size: 22,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
