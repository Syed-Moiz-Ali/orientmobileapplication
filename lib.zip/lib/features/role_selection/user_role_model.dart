import 'package:flutter/material.dart';

enum UserRole { owner, advisor, technician, customer, supervisor, crmdasboard }

class UserRoleModel {
  final UserRole role;
  final String title;
  final String subtitle;
  final List<String> features;
  final Color iconBackgroundColor;
  final Color buttonColor;
  final String buttonLabel;
  final IconData icon;

  const UserRoleModel({
    required this.role,
    required this.title,
    required this.subtitle,
    required this.features,
    required this.iconBackgroundColor,
    required this.buttonColor,
    required this.buttonLabel,
    required this.icon,
  });

  static const List<UserRoleModel> roles = [
    UserRoleModel(
      role: UserRole.owner,
      title: 'Owner Dashboard',
      subtitle:
          'Access business analytics, financials, reports, and management tools',
      features: [
        'View KPIs and performance',
        'Monitor financials',
        'Manage approvals',
      ],
      iconBackgroundColor: Color(0xFF1565C0),
      buttonColor: Color(0xFF1976D2),
      buttonLabel: 'Continue as Owner',
      icon: Icons.dashboard_rounded,
    ),
    UserRoleModel(
      role: UserRole.advisor,
      title: 'Service Advisor',
      subtitle:
          'Create job cards, perform inspections, and manage customer intake',
      features: [
        'Create job cards',
        'Perform inspections',
        'Share via print/email',
      ],
      iconBackgroundColor: Color(0xFF37474F),
      buttonColor: Color(0xFF455A64),
      buttonLabel: 'Login as Advisor',
      icon: Icons.assignment_rounded,
    ),
    UserRoleModel(
      role: UserRole.technician,
      title: 'Technician Portal',
      subtitle:
          'Track attendance, manage assigned jobs, and update work status',
      features: ['Mark attendance', 'View assigned jobs', 'Update task status'],
      iconBackgroundColor: Color(0xFF2E7D32),
      buttonColor: Color(0xFF388E3C),
      buttonLabel: 'Login as Technician',
      icon: Icons.build_rounded,
    ),
    UserRoleModel(
      role: UserRole.customer,
      title: 'Customer Portal',
      subtitle: 'Book services, track vehicles, approve estimates, and more',
      features: ['Book appointments', 'Approve estimates', "Track status"],
      iconBackgroundColor: Color(0xFF6A1B9A),
      buttonColor: Color(0xFF7B1FA2),
      buttonLabel: 'Login as Customer',
      icon: Icons.person_rounded,
    ),

    UserRoleModel(
      role: UserRole.supervisor,
      title: 'Supervisor Portal',
      subtitle: 'Book services, track vehicles, approve estimates, and more',
      features: ['Manage vehicles', 'Book appointments', 'Approve estimates'],
      iconBackgroundColor: Color(0xFF00695C),
      buttonColor: Color(0xFF00796B),
      buttonLabel: 'Login as Supervisor',
      icon: Icons.supervisor_account_rounded,
    ),

    UserRoleModel(
      role: UserRole.crmdasboard,
      title: 'CRM Dashboard',
      subtitle: 'Dashboard',
      features: ['Manage vehicles', 'Book appointments', 'Approve estimates'],
      iconBackgroundColor: Color(0xFF0097A7),
      buttonColor: Color(0xFF00838F),
      buttonLabel: 'Login as CRM Dashboard',
      icon: Icons.bar_chart_rounded,
    ),
  ];
}



class RoleModel {
  final String title;
  final String description;
  final IconData icon;
  final VoidCallback onTap;

  const RoleModel({
    required this.title,
    required this.description,
    required this.icon,
    required this.onTap,
  });
}
