import 'package:flutter/material.dart';
import 'package:orientmobileapplication/features/role_selection/user_role_model.dart';

class RoleSelectionViewModel extends ChangeNotifier {
  UserRole? _selectedRole;
  bool _isLoading = false;

  UserRole? get selectedRole => _selectedRole;
  bool get isLoading => _isLoading;
  List<UserRoleModel> get roles => UserRoleModel.roles;

  bool isLoadingFor(UserRole role) => _isLoading && _selectedRole == role;

  Future<void> proceedWithRole(
    BuildContext context,
    UserRole role, {
    required VoidCallback onSuccess,
  }) async {
    _selectedRole = role;
    _isLoading = true;
    notifyListeners();

    await Future.delayed(const Duration(milliseconds: 800));

    _isLoading = false;
    notifyListeners();

    onSuccess();
  }

  void reset() {
    _selectedRole = null;
    _isLoading = false;
    notifyListeners();
  }

  
}