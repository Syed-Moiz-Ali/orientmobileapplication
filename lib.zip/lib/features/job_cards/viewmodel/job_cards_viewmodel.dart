import 'package:flutter/material.dart';
import 'package:orientmobileapplication/features/job_cards/model/job_card_model.dart';

class JobCardsViewModel extends ChangeNotifier {
  final TextEditingController searchController = TextEditingController();

  List<JobCardModel> _all = List.from(JobCardModel.mockData);
  List<JobCardModel> _filtered = List.from(JobCardModel.mockData);

  List<JobCardModel> get jobCards => _filtered;

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  JobCardStatus? _activeFilter;
  JobCardStatus? get activeFilter => _activeFilter;

  JobCardsViewModel() {
    searchController.addListener(_onSearch);
  }

  void _onSearch() {
    _applyFilters();
  }

  void setFilter(JobCardStatus? status) {
    _activeFilter = status;
    _applyFilters();
  }

  void _applyFilters() {
    final query = searchController.text.toLowerCase();
    _filtered = _all.where((jc) {
      final matchesQuery = query.isEmpty ||
          jc.customerName.toLowerCase().contains(query) ||
          jc.id.toLowerCase().contains(query) ||
          jc.vehicle.toLowerCase().contains(query) ||
          jc.plateNumber.toLowerCase().contains(query);

      final matchesStatus =
          _activeFilter == null || jc.status == _activeFilter;

      return matchesQuery && matchesStatus;
    }).toList();
    notifyListeners();
  }

  Future<void> refresh() async {
    _isLoading = true;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 700));
    _all = List.from(JobCardModel.mockData);
    _applyFilters();
    _isLoading = false;
    notifyListeners();
  }

  String formatAmount(double amount) {
    final s = amount.toStringAsFixed(0).replaceAllMapped(
          RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
          (m) => '${m[1]},',
        );
    return 'AED $s';
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }
}
