import 'package:flutter/material.dart';
import 'package:orientmobileapplication/features/job_cards/model/job_card_model.dart';

class FilterChipBar extends StatelessWidget {
  final JobCardStatus? activeFilter;
  final ValueChanged<JobCardStatus?> onFilterChanged;

  const FilterChipBar({
    super.key,
    required this.activeFilter,
    required this.onFilterChanged,
  });

  static const _filters = [
    (null, 'All'),
    (JobCardStatus.inProgress, 'In Progress'),
    (JobCardStatus.waitingParts, 'Waiting Parts'),
    (JobCardStatus.qualityCheck, 'Quality Check'),
    (JobCardStatus.completed, 'Completed'),
  ];

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: _filters.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final (status, label) = _filters[i];
          final isActive = activeFilter == status;
          return GestureDetector(
            onTap: () => onFilterChanged(status),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
              decoration: BoxDecoration(
                color: isActive
                    ? const Color(0xFF2563EB)
                    : Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: isActive
                      ? const Color(0xFF2563EB)
                      : const Color(0xFFE5E7EB),
                ),
              ),
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: isActive
                      ? Colors.white
                      : const Color(0xFF6B7280),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
