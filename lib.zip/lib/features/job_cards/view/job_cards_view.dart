import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../viewmodel/job_cards_viewmodel.dart';
import '../widgets/job_card_tile.dart';
import '../widgets/filter_chip_bar.dart';
import 'job_card_detail_view.dart';
import '../../dashboard/widgets/app_bottom_nav.dart';

class JobCardsView extends StatefulWidget {
  const JobCardsView({super.key});

  @override
  State<JobCardsView> createState() => _JobCardsViewState();
}

class _JobCardsViewState extends State<JobCardsView> {
  int _navIndex = 1;

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => JobCardsViewModel(),
      child: Consumer<JobCardsViewModel>(
        builder: (context, vm, _) {
          return Scaffold(
            backgroundColor: const Color(0xFFF9FAFB),
            appBar: _buildAppBar(),
            body: Column(
              children: [
                // Search bar
                _SearchBar(vm: vm),
                const SizedBox(height: 10),
                // Filter chips
                FilterChipBar(
                  activeFilter: vm.activeFilter,
                  onFilterChanged: vm.setFilter,
                ),
                const SizedBox(height: 10),
                // List
                Expanded(
                  child: vm.isLoading
                      ? const Center(
                          child: CircularProgressIndicator(
                              color: Color(0xFF2563EB)))
                      : vm.jobCards.isEmpty
                          ? _buildEmpty()
                          : RefreshIndicator(
                              color: const Color(0xFF2563EB),
                              onRefresh: vm.refresh,
                              child: ListView.builder(
                                padding: const EdgeInsets.only(bottom: 12),
                                itemCount: vm.jobCards.length,
                                itemBuilder: (context, i) {
                                  final jc = vm.jobCards[i];
                                  return JobCardTile(
                                    jobCard: jc,
                                    formattedAmount: vm.formatAmount(jc.amount),
                                    onViewDetails: () {
                                      Navigator.of(context).push(
                                        MaterialPageRoute(
                                          builder: (_) => JobCardDetailView(
                                              jobCard: jc),
                                        ),
                                      );
                                    },
                                  );
                                },
                              ),
                            ),
                ),
              ],
            ),
            bottomNavigationBar: AppBottomNav(
              currentIndex: _navIndex,
              onTap: (i) {
                if (i == 0) {
                  Navigator.of(context).pop();
                } else {
                  setState(() => _navIndex = i);
                }
              },
            ),
          );
        },
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.white,
      elevation: 0,
      centerTitle: true,
      leading: IconButton(
        icon: const Icon(Icons.menu, color: Color(0xFF111827), size: 22),
        onPressed: () {},
      ),
      title: const Text(
        'Active Job Cards',
        style: TextStyle(
          color: Color(0xFF111827),
          fontWeight: FontWeight.w700,
          fontSize: 17,
        ),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.notifications_outlined,
              color: Color(0xFF111827), size: 22),
          onPressed: () {},
        ),
      ],
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.assignment_outlined,
              size: 56, color: Colors.grey.shade300),
          const SizedBox(height: 12),
          Text(
            'No job cards found',
            style: TextStyle(
                fontSize: 15,
                color: Colors.grey.shade500,
                fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}

class _SearchBar extends StatelessWidget {
  final JobCardsViewModel vm;
  const _SearchBar({required this.vm});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 12, 12, 0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: TextField(
        controller: vm.searchController,
        style: const TextStyle(fontSize: 13, color: Color(0xFF111827)),
        decoration: const InputDecoration(
          hintText: 'Search job cards...',
          hintStyle: TextStyle(color: Color(0xFF9CA3AF), fontSize: 13),
          prefixIcon:
              Icon(Icons.search, color: Color(0xFF9CA3AF), size: 20),
          suffixIcon:
              Icon(Icons.filter_list, color: Color(0xFF6B7280), size: 20),
          border: InputBorder.none,
          contentPadding:
              EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        ),
      ),
    );
  }
}
