enum JobCardStatus { inProgress, waitingParts, qualityCheck, completed, cancelled, pendingApproval }

class JobCardModel {
  final String id;
  final String customerName;
  final String vehicle;
  final String plateNumber;
  final List<String> services;
  final String technician;
  final String estCompletion;
  final double amount;
  final JobCardStatus status;

  const JobCardModel({
    required this.id,
    required this.customerName,
    required this.vehicle,
    required this.plateNumber,
    required this.services,
    required this.technician,
    required this.estCompletion,
    required this.amount,
    required this.status, required String vehicleInfo, required String time,
  });

  String get vehicleDisplay => '$vehicle - $plateNumber';

  String get statusLabel {
    switch (status) {
      case JobCardStatus.inProgress:
        return 'In Progress';
      case JobCardStatus.waitingParts:
        return 'Waiting Parts';
      case JobCardStatus.qualityCheck:
        return 'Quality Check';
      case JobCardStatus.completed:
        return 'Completed';
      case JobCardStatus.cancelled:
        return 'Cancelled';
      case JobCardStatus.pendingApproval:
        // TODO: Handle this case.
        throw UnimplementedError();
    }
  }

  int get statusColor {
    switch (status) {
      case JobCardStatus.inProgress:
        return 0xFF2563EB;
      case JobCardStatus.waitingParts:
        return 0xFFD97706;
      case JobCardStatus.qualityCheck:
        return 0xFF7C3AED;
      case JobCardStatus.completed:
        return 0xFF16A34A;
      case JobCardStatus.cancelled:
        return 0xFFDC2626;
      case JobCardStatus.pendingApproval:
        // TODO: Handle this case.
        throw UnimplementedError();
    }
  }

  int get statusBgColor {
    switch (status) {
      case JobCardStatus.inProgress:
        return 0xFFEFF6FF;
      case JobCardStatus.waitingParts:
        return 0xFFFFFBEB;
      case JobCardStatus.qualityCheck:
        return 0xFFF5F3FF;
      case JobCardStatus.completed:
        return 0xFFF0FDF4;
      case JobCardStatus.cancelled:
        return 0xFFFEF2F2;
      case JobCardStatus.pendingApproval:
        // TODO: Handle this case.
        throw UnimplementedError();
    }
  }

  static const List<JobCardModel> mockData = [
    JobCardModel(
      id: 'JC-2024-001',
      customerName: 'Ahmed Al Mansouri',
      vehicle: 'Toyota Camry',
      plateNumber: 'AA-12345',
      services: ['Oil Change', 'Brake Inspection'],
      technician: 'Mohammed Hassan',
      estCompletion: '2024-04-01',
      amount: 850,
      status: JobCardStatus.inProgress, vehicleInfo: '', time: '',
    ),
    JobCardModel(
      id: 'JC-2024-002',
      customerName: 'Fatima Ali',
      vehicle: 'Honda Accord',
      plateNumber: 'BB-67890',
      services: ['Transmission Repair'],
      technician: 'Ali Ahmed',
      estCompletion: '2024-04-02',
      amount: 3200,
      status: JobCardStatus.waitingParts, vehicleInfo: '', time: '',
    ),
    JobCardModel(
      id: 'JC-2024-003',
      customerName: 'Khalid Rashid',
      vehicle: 'Nissan Patrol',
      plateNumber: 'CC-11223',
      services: ['AC Repair', 'Battery Replacement'],
      technician: 'Hassan Ibrahim',
      estCompletion: '2024-04-01',
      amount: 1450,
      status: JobCardStatus.inProgress, vehicleInfo: '', time: '',
    ),
    JobCardModel(
      id: 'JC-2024-004',
      customerName: 'Mariam Salem',
      vehicle: 'BMW X5',
      plateNumber: 'DD-44556',
      services: ['Engine Diagnostics', 'Spark Plug Change'],
      technician: 'Omar Khalid',
      estCompletion: '2024-03-31',
      amount: 2100,
      status: JobCardStatus.qualityCheck, vehicleInfo: '', time: '',
    ),
    JobCardModel(
      id: 'JC-2024-005',
      customerName: 'Saeed Mohammed',
      vehicle: 'Mercedes C-Class',
      plateNumber: 'EE-77889',
      services: ['Brake Pad Replacement', 'Wheel Alignment'],
      technician: 'Yousef Ali',
      estCompletion: '2024-04-02',
      amount: 1750,
      status: JobCardStatus.inProgress, vehicleInfo: '', time: '',
    ),
    JobCardModel(
      id: 'JC-2024-006',
      customerName: 'Noura Al Zaabi',
      vehicle: 'Audi Q7',
      plateNumber: 'FF-33210',
      services: ['Full Service', 'Tire Rotation'],
      technician: 'Bilal Khan',
      estCompletion: '2024-04-03',
      amount: 2800,
      status: JobCardStatus.completed, vehicleInfo: '', time: '',
    ),
  ];
}
