// ─────────────────────────────────────────────────────────────────────────────
// technician_dashboard_viewmodel.dart
// lib/features/technician/viewmodel/technician_dashboard_viewmodel.dart
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:orientmobileapplication/features/technician/model/technician_dashboard_model.dart';

class TechnicianDashboardViewModel extends ChangeNotifier {
  // ─────────────────────────────────────────────────────────────────────────
  // NAVIGATION  (bottom tabs)
  // ─────────────────────────────────────────────────────────────────────────

  int _selectedTab = 0;
  int get selectedTab => _selectedTab;

  void selectTab(int i) {
    if (_selectedTab == i) return;
    _selectedTab = i;
    notifyListeners();
  }

  // ─────────────────────────────────────────────────────────────────────────
  // LOADING
  // ─────────────────────────────────────────────────────────────────────────

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  bool _isSaving = false;
  bool get isSaving => _isSaving;

  // ─────────────────────────────────────────────────────────────────────────
  // PROFILE
  // ─────────────────────────────────────────────────────────────────────────

  final TechnicianProfile profile = TechnicianProfile.mock;

  String get currentDateTime =>
      DateFormat('EEEE, MMMM d, yyyy \'at\' hh:mm a')
          .format(DateTime.now());

  // ─────────────────────────────────────────────────────────────────────────
  // ATTENDANCE
  // ─────────────────────────────────────────────────────────────────────────

  AttendanceStatus _attendanceStatus = AttendanceStatus.working;
  AttendanceStatus get attendanceStatus => _attendanceStatus;

  AttendanceSummary _attendanceSummary = const AttendanceSummary(
    punchIn: '08:15 AM',
    punchOut: '--:--',
    breakTime: '25 min',
    workHours: '4h 35m',
  );
  AttendanceSummary get attendanceSummary => _attendanceSummary;

  Future<void> punchIn() async {
    if (_attendanceStatus != AttendanceStatus.notPunchedIn) return;
    _attendanceStatus = AttendanceStatus.working;
    final now = TimeOfDay.now();
    _attendanceSummary = AttendanceSummary(
      punchIn: _fmt(now),
      punchOut: '--:--',
      breakTime: '0 min',
      workHours: '0h 0m',
    );
    notifyListeners();
  }

  Future<void> punchOut() async {
    if (_attendanceStatus == AttendanceStatus.notPunchedIn ||
        _attendanceStatus == AttendanceStatus.punchedOut) return;
    _attendanceStatus = AttendanceStatus.punchedOut;
    final now = TimeOfDay.now();
    _attendanceSummary = AttendanceSummary(
      punchIn: _attendanceSummary.punchIn,
      punchOut: _fmt(now),
      breakTime: _attendanceSummary.breakTime,
      workHours: _attendanceSummary.workHours,
    );
    notifyListeners();
  }

  Future<void> startBreak() async {
    if (_attendanceStatus != AttendanceStatus.working) return;
    _attendanceStatus = AttendanceStatus.onBreak;
    notifyListeners();
  }

  Future<void> endBreak() async {
    if (_attendanceStatus != AttendanceStatus.onBreak) return;
    _attendanceStatus = AttendanceStatus.working;
    notifyListeners();
  }

  String _fmt(TimeOfDay t) {
    final h = t.hourOfPeriod == 0 ? 12 : t.hourOfPeriod;
    final m = t.minute.toString().padLeft(2, '0');
    final p = t.period == DayPeriod.am ? 'AM' : 'PM';
    return '$h:$m $p';
  }

  // ─────────────────────────────────────────────────────────────────────────
  // PRODUCTIVITY
  // ─────────────────────────────────────────────────────────────────────────

  final ProductivitySummary productivity = const ProductivitySummary(
    assignedJobs: 4,
    inProgress: 1,
    completedToday: 1,
    efficiency: 87,
    avgTimePerJob: '1.2 hrs',
    totalHoursWorked: '4h 35m',
  );

  // ─────────────────────────────────────────────────────────────────────────
  // ASSIGNED JOBS  (dashboard cards)
  // ─────────────────────────────────────────────────────────────────────────

  final List<AssignedJob> _assignedJobs = AssignedJob.mockData;
  List<AssignedJob> get assignedJobs => List.unmodifiable(_assignedJobs);

  void updateAssignedJobStatus(String id, AssignedJobStatus status) {
    final idx = _assignedJobs.indexWhere((j) => j.id == id);
    if (idx == -1) return;
    _assignedJobs[idx].status = status;
    notifyListeners();
  }

  // ─────────────────────────────────────────────────────────────────────────
  // QUICK JOB ACCESS
  // ─────────────────────────────────────────────────────────────────────────

  final TextEditingController jobCardController = TextEditingController();
  String _quickJobError = '';
  String get quickJobError => _quickJobError;

  void searchJobCard() {
    final val = jobCardController.text.trim();
    if (val.isEmpty) {
      _quickJobError = 'Please enter a job card number.';
      notifyListeners();
      return;
    }
    _quickJobError = '';
    // Find in efficiency jobs
    final match = _allJobs
        .where((j) =>
            j.jobCardNo.toLowerCase() == val.toLowerCase())
        .toList();
    if (match.isEmpty) {
      _quickJobError = 'Job card "$val" not found.';
    } else {
      _selectedJob = match.first;
    }
    notifyListeners();
  }

  void clearQuickJobError() {
    _quickJobError = '';
    notifyListeners();
  }

  // ─────────────────────────────────────────────────────────────────────────
  // EFFICIENCY PORTAL — Job list + detail
  // ─────────────────────────────────────────────────────────────────────────

  String _searchQuery = '';
  String get searchQuery => _searchQuery;

  String _selectedFilter = 'All Status';
  String get selectedFilter => _selectedFilter;

  final List<String> filterOptions = const [
    'All Status',
    'In Progress',
    'Completed',
    'Delayed',
    'Pending',
  ];

  void updateSearch(String query) {
    _searchQuery = query.toLowerCase();
    notifyListeners();
  }

  void updateFilter(String filter) {
    _selectedFilter = filter;
    notifyListeners();
  }

  final List<TechJobModel> _allJobs = [
    TechJobModel(
      jobCardNo: 'JC-2026-0423',
      dateOfWork: '2026-04-23',
      startTime: '08:30',
      vehicleBrand: 'Toyota',
      vehicleModel: 'Camry',
      plateNumber: 'ABC-1234',
      status: TechJobStatus.inProgress,
      tasks: [
        WorkTask(id: 1, description: 'Engine oil change and filter replacement',
            status: TaskStatus.completed, startTime: '08:35'),
        WorkTask(id: 2, description: 'Brake pad inspection and replacement',
            status: TaskStatus.inProgress, startTime: '09:15'),
        WorkTask(id: 3, description: 'Tire rotation and alignment check'),
        WorkTask(id: 4, description: 'Battery voltage test and terminal cleaning'),
      ],
    ),
    TechJobModel(
      jobCardNo: 'JC-2026-0422',
      dateOfWork: '2026-04-22',
      startTime: '10:00',
      vehicleBrand: 'Honda',
      vehicleModel: 'Accord',
      plateNumber: 'XYZ-5678',
      status: TechJobStatus.completed,
      tasks: [
        WorkTask(id: 1, description: 'Full service inspection',
            status: TaskStatus.completed, startTime: '10:05', endTime: '11:30'),
        WorkTask(id: 2, description: 'Air filter replacement',
            status: TaskStatus.completed, startTime: '11:35', endTime: '12:00'),
        WorkTask(id: 3, description: 'Coolant top-up and pressure test',
            status: TaskStatus.completed, startTime: '12:05', endTime: '12:45'),
      ],
    ),
    TechJobModel(
      jobCardNo: 'JC-2026-0421',
      dateOfWork: '2026-04-21',
      startTime: '14:30',
      vehicleBrand: 'Ford',
      vehicleModel: 'F-150',
      plateNumber: 'DEF-9012',
      status: TechJobStatus.delayed,
      tasks: [
        WorkTask(id: 1, description: 'Transmission fluid change',
            status: TaskStatus.inProgress, startTime: '14:35'),
        WorkTask(id: 2, description: 'Differential oil replacement'),
      ],
    ),
    TechJobModel(
      jobCardNo: 'JC-2026-0420',
      dateOfWork: '2026-04-20',
      startTime: '09:00',
      vehicleBrand: 'Chevrolet',
      vehicleModel: 'Silverado',
      plateNumber: 'GHI-3456',
      status: TechJobStatus.pending,
      tasks: [
        WorkTask(id: 1, description: 'Spark plug replacement'),
        WorkTask(id: 2, description: 'Throttle body cleaning'),
        WorkTask(id: 3, description: 'PCV valve inspection'),
      ],
    ),
    TechJobModel(
      jobCardNo: 'JC-2026-0419',
      dateOfWork: '2026-04-19',
      startTime: '11:30',
      vehicleBrand: 'BMW',
      vehicleModel: '328i',
      plateNumber: 'JKL-7890',
      status: TechJobStatus.inProgress,
      tasks: [
        WorkTask(id: 1, description: 'DSC sensor calibration',
            status: TaskStatus.completed, startTime: '11:35', endTime: '12:10'),
        WorkTask(id: 2, description: 'Brake fluid flush',
            status: TaskStatus.inProgress, startTime: '12:15'),
        WorkTask(id: 3, description: 'Wheel bearing inspection'),
      ],
    ),
    TechJobModel(
      jobCardNo: 'JC-2026-0418',
      dateOfWork: '2026-04-18',
      startTime: '15:00',
      vehicleBrand: 'Mercedes',
      vehicleModel: 'C-Class',
      plateNumber: 'MNO-2468',
      status: TechJobStatus.pending,
      tasks: [
        WorkTask(id: 1, description: 'AC compressor check'),
        WorkTask(id: 2, description: 'Cabin air filter replacement'),
      ],
    ),
  ];

  List<TechJobModel> get filteredJobs => _allJobs.where((j) {
        final q = _searchQuery;
        final matchSearch = q.isEmpty ||
            j.jobCardNo.toLowerCase().contains(q) ||
            j.vehicleBrand.toLowerCase().contains(q) ||
            j.vehicleModel.toLowerCase().contains(q) ||
            j.plateNumber.toLowerCase().contains(q);
        final matchFilter = _selectedFilter == 'All Status' ||
            j.status.label == _selectedFilter;
        return matchSearch && matchFilter;
      }).toList();

  List<TechJobModel> get allJobs => _allJobs;

  // KPIs derived from jobs
  int get totalJobs        => _allJobs.length;
  int get inProgressJobs   => _allJobs.where((j) => j.status == TechJobStatus.inProgress).length;
  int get completedJobs    => _allJobs.where((j) => j.status == TechJobStatus.completed).length;
  int get delayedJobs      => _allJobs.where((j) => j.status == TechJobStatus.delayed).length;

  // ── Selected job (for detail sheet) ──────────────────────────────────────

  TechJobModel? _selectedJob;
  TechJobModel? get selectedJob => _selectedJob;

  void openJob(TechJobModel job) {
    _selectedJob = job;
    notifyListeners();
  }

  void closeJob() {
    _selectedJob = null;
    notifyListeners();
  }

  // ── Task actions ──────────────────────────────────────────────────────────

  void startTask(TechJobModel job, WorkTask task) {
    final now = DateFormat('HH:mm').format(DateTime.now());
    final idx = job.tasks.indexWhere((t) => t.id == task.id);
    if (idx == -1) return;
    job.tasks[idx] = task.copyWith(status: TaskStatus.inProgress, startTime: now);
    _syncJobStatus(job);
    notifyListeners();
  }

  void completeTask(TechJobModel job, WorkTask task) {
    final now = DateFormat('HH:mm').format(DateTime.now());
    final idx = job.tasks.indexWhere((t) => t.id == task.id);
    if (idx == -1) return;
    job.tasks[idx] = task.copyWith(status: TaskStatus.completed, endTime: now);
    _syncJobStatus(job);
    notifyListeners();
  }

  void updateTaskStatus(TechJobModel job, WorkTask task, TaskStatus newStatus) {
    final now = DateFormat('HH:mm').format(DateTime.now());
    final idx = job.tasks.indexWhere((t) => t.id == task.id);
    if (idx == -1) return;
    job.tasks[idx] = task.copyWith(
      status: newStatus,
      startTime: newStatus == TaskStatus.inProgress ? now : task.startTime,
      endTime: newStatus == TaskStatus.completed ? now : task.endTime,
    );
    _syncJobStatus(job);
    notifyListeners();
  }

  void _syncJobStatus(TechJobModel job) {
    final allDone = job.tasks.every((t) => t.status == TaskStatus.completed);
    final anyProgress = job.tasks.any((t) => t.status == TaskStatus.inProgress);
    if (allDone) {
      job.status = TechJobStatus.completed;
    } else if (anyProgress) {
      job.status = TechJobStatus.inProgress;
    }
  }

  void updateNotes(TechJobModel job, String notes) {
    job.notes = notes;
    notifyListeners();
  }

  Future<void> saveChanges(TechJobModel job) async {
    _isSaving = true;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 900));
    _isSaving = false;
    notifyListeners();
  }

  Future<void> completeJob(TechJobModel job) async {
    _isSaving = true;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 900));
    final now = DateFormat('HH:mm').format(DateTime.now());
    for (var i = 0; i < job.tasks.length; i++) {
      if (job.tasks[i].status != TaskStatus.completed) {
        job.tasks[i] = job.tasks[i].copyWith(
            status: TaskStatus.completed, endTime: now);
      }
    }
    job.status = TechJobStatus.completed;
    _isSaving = false;
    notifyListeners();
  }

  // ─────────────────────────────────────────────────────────────────────────
  // REFRESH
  // ─────────────────────────────────────────────────────────────────────────

  Future<void> refresh() async {
    _isLoading = true;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 600));
    _isLoading = false;
    notifyListeners();
  }

  TechnicianDashboardViewModel() {
    refresh();
  }

  @override
  void dispose() {
    jobCardController.dispose();
    super.dispose();
  }
}