import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:orientmobileapplication/features/technician/model/technician_dashboard_model.dart';
import 'package:provider/provider.dart';
import 'package:orientmobileapplication/features/technician/viewmodel/technician_dashboard_viewmodel.dart';

// ─────────────────────────────────────────────────────────────────────────────
// DESIGN TOKENS — identical to dashboard_view.dart (DC palette)
// ─────────────────────────────────────────────────────────────────────────────

abstract class TC {
  // Brand core
  static const primary = Color(0xFF0F4C75); // DC.primary
  static const accent = Color(0xFF1B9AAA); // DC.accent
  static const accentLight = Color(0xFFE0F4F6); // DC.accentLight
  static const accentMid = Color(0xFFB2E0E5); // DC.accentMid

  // Surface
  static const scaffold = Color(0xFFF5F7FA); // DC.scaffold
  static const surface = Color(0xFFFFFFFF); // DC.surface
  static const surfaceAlt = Color(0xFFF0F3F7); // DC.surfaceAlt
  static const border = Color(0xFFE2E8EF); // DC.border

  // Text
  static const textH = Color(0xFF0A1628); // DC.textH
  static const textB = Color(0xFF253347); // DC.textB
  static const textM = Color(0xFF5C6E85); // DC.textM

  // Semantic
  static const green = Color(0xFF1A8754); // DC.green
  static const greenBg = Color(0xFFEAF7EF); // DC.greenBg
  static const amber = Color(0xFFD97706); // DC.amber
  static const amberBg = Color(0xFFFFF8EC); // DC.amberBg
  static const red = Color(0xFFB91C1C); // DC.red
  static const redBg = Color(0xFFFEECEC); // DC.redBg
  static const purple = Color(0xFF6D28D9); // DC.purple
  static const purpleBg = Color(0xFFF0EAFC); // DC.purpleBg
  static const grey = Color(0xFF5C6E85);
  static const greyBg = Color(0xFFF0F3F7);

  // Gradient
  static const gStart = Color(0xFF0F4C75);
  static const gEnd = Color(0xFF1B9AAA);
}

// ─────────────────────────────────────────────────────────────────────────────
// ENTRY POINT
// ─────────────────────────────────────────────────────────────────────────────

class TechnicianDashboardView extends StatelessWidget {
  const TechnicianDashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => TechnicianDashboardViewModel(),
      child: const _TechBody(),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SCAFFOLD
// ─────────────────────────────────────────────────────────────────────────────

class _TechBody extends StatelessWidget {
  const _TechBody();

  static const _pages = <Widget>[_DashboardTab(), _EfficiencyTab()];

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<TechnicianDashboardViewModel>();

    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: TC.primary,
        statusBarIconBrightness: Brightness.light,
      ),
    );

    return Scaffold(
      backgroundColor: TC.scaffold,
      body: Column(
        children: [
          _TechHeader(vm: vm),
          Container(height: 1, color: TC.border),
          _TechTabBar(selectedTab: vm.selectedTab, onTap: vm.selectTab),
          Container(height: 1, color: TC.border),
          Expanded(
            child: IndexedStack(index: vm.selectedTab, children: _pages),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// CUSTOM HEADER — matches dashboard_view.dart AppBar gradient + typography
// ─────────────────────────────────────────────────────────────────────────────

class _TechHeader extends StatelessWidget {
  final TechnicianDashboardViewModel vm;
  const _TechHeader({required this.vm});

  @override
  Widget build(BuildContext context) {
    final status = vm.attendanceStatus;

    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [TC.gStart, TC.gEnd],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
          child: Row(
            children: [
              // Avatar — matches dashboard profile circle style
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.20),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.white.withOpacity(0.5),
                    width: 1.5,
                  ),
                ),
                child: Center(
                  child: Text(
                    vm.profile.avatarInitials,
                    style: GoogleFonts.rajdhani(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Name — matches dashboard AppBar title style
                    Text(
                      vm.profile.name,
                      style: GoogleFonts.rajdhani(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 2),
                    // Sub-title — matches dashboard AppBar subtitle style
                    Text(
                      '${vm.profile.empId} • ${vm.profile.branch}',
                      style: GoogleFonts.rajdhani(
                        color: Colors.white70,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.4,
                      ),
                    ),
                    const SizedBox(height: 4),
                    // Status pill — matches dashboard header "Live" pill
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.3),
                          width: 1,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 6,
                            height: 6,
                            decoration: BoxDecoration(
                              color: status == AttendanceStatus.working
                                  ? const Color(0xFF4ADEDF)
                                  : status == AttendanceStatus.onBreak
                                  ? const Color(0xFFFBBF24)
                                  : Colors.white54,
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 5),
                          Text(
                            status.label,
                            style: GoogleFonts.rajdhani(
                              color: Colors.white,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.3,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              // Notification bell — matches dashboard AppBar bell
              Stack(
                clipBehavior: Clip.none,
                children: [
                  IconButton(
                    icon: const Icon(
                      Icons.notifications_outlined,
                      color: Colors.white,
                      size: 26,
                    ),
                    onPressed: () {},
                  ),
                  Positioned(
                    right: 10,
                    top: 10,
                    child: Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: const Color(0xFFFBBF24),
                        shape: BoxShape.circle,
                        border: Border.all(color: TC.gStart, width: 1.5),
                      ),
                    ),
                  ),
                ],
              ),
              // More menu — matches dashboard avatar button
              GestureDetector(
                onTap: () => _showProfile(context, vm),
                child: Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.20),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.white.withOpacity(0.5),
                      width: 1.5,
                    ),
                  ),
                  child: Center(
                    child: Text(
                      vm.profile.avatarInitials.substring(0, 1),
                      style: GoogleFonts.rajdhani(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 15,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showProfile(BuildContext context, TechnicianDashboardViewModel vm) {
    showModalBottomSheet(
      context: context,
      backgroundColor: TC.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Handle
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: TC.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 24),
            // Avatar — matches dashboard profile sheet gradient circle
            Container(
              width: 68,
              height: 68,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [TC.gStart, TC.gEnd],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  vm.profile.avatarInitials,
                  style: GoogleFonts.rajdhani(
                    color: Colors.white,
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Text(
              vm.profile.name,
              style: const TextStyle(
                color: TC.textH,
                fontSize: 19,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.3,
              ),
            ),
            const SizedBox(height: 4),
            // Role chip — matches dashboard "Admin • Auto Garage ERP" chip
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: TC.accentLight,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                '${vm.profile.role} • ${vm.profile.branch}',
                style: GoogleFonts.rajdhani(
                  color: TC.accent,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Shift: ${vm.profile.shift}',
              style: GoogleFonts.rajdhani(
                color: TC.textM,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 28),
            // Logout — matches dashboard OutlinedButton.icon style
            SizedBox(
              width: double.infinity,
              height: 50,
              child: OutlinedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.of(context).pop();
                },
                style: OutlinedButton.styleFrom(
                  foregroundColor: TC.red,
                  side: const BorderSide(color: TC.red, width: 1.5),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                icon: const Icon(Icons.logout_rounded, size: 18),
                label: Text(
                  'Logout',
                  style: GoogleFonts.rajdhani(
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                    color: TC.red,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// TAB BAR — matches dashboard BottomNav pill style
// ─────────────────────────────────────────────────────────────────────────────

class _TechTabBar extends StatelessWidget {
  final int selectedTab;
  final void Function(int) onTap;
  const _TechTabBar({required this.selectedTab, required this.onTap});

  @override
  Widget build(BuildContext context) {
    const tabs = [
      (Icons.dashboard_rounded, Icons.dashboard_outlined, 'Dashboard'),
      (
        Icons.assignment_turned_in_rounded,
        Icons.assignment_outlined,
        'My Jobs',
      ),
    ];

    return Container(
      color: TC.surface,
      child: Row(
        children: List.generate(tabs.length, (i) {
          final sel = selectedTab == i;
          return Expanded(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => onTap(i),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          sel ? tabs[i].$1 : tabs[i].$2,
                          size: 19,
                          color: sel ? TC.accent : TC.textM,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          tabs[i].$3,
                          style: GoogleFonts.rajdhani(
                            fontSize: 17,
                            fontWeight: sel ? FontWeight.w800 : FontWeight.w600,
                            color: sel ? TC.accent : TC.textM,
                            letterSpacing: sel ? 0.3 : 0,
                          ),
                        ),
                      ],
                    ),
                  ),
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 220),
                    curve: Curves.easeOutCubic,
                    height: 3,
                    decoration: BoxDecoration(
                      color: sel ? TC.accent : Colors.transparent,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ],
              ),
            ),
          );
        }),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// TAB 1 — DASHBOARD
// ─────────────────────────────────────────────────────────────────────────────

class _DashboardTab extends StatelessWidget {
  const _DashboardTab();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<TechnicianDashboardViewModel>();

    return RefreshIndicator(
      color: TC.accent,
      strokeWidth: 2.5,
      onRefresh: vm.refresh,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          // ── Dashboard title bar — matches dashboard _sectionLabel ──
          Container(
            color: TC.surface,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: [
                Container(
                  width: 4,
                  height: 20,
                  decoration: BoxDecoration(
                    color: TC.accent,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  'Technician Dashboard',
                  style: GoogleFonts.rajdhani(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: TC.textH,
                    letterSpacing: 0.5,
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: vm.refresh,
                  child: vm.isLoading
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2.5,
                            color: TC.accent,
                          ),
                        )
                      : const Icon(
                          Icons.refresh_rounded,
                          color: TC.textM,
                          size: 20,
                        ),
                ),
              ],
            ),
          ),
          Container(height: 1, color: TC.border),
          const SizedBox(height: 14),
          _AttendanceSection(vm: vm),
          const SizedBox(height: 16),
          _ProductivitySection(p: vm.productivity),
          const SizedBox(height: 16),
          _AssignedJobsSection(vm: vm),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}

// ── ATTENDANCE SECTION ────────────────────────────────────────────────────────

class _AttendanceSection extends StatelessWidget {
  final TechnicianDashboardViewModel vm;
  const _AttendanceSection({required this.vm});

  @override
  Widget build(BuildContext context) {
    final status = vm.attendanceStatus;
    final s = vm.attendanceSummary;

    return _Section(
      title: 'Attendance',
      icon: Icons.access_time_rounded,
      child: Column(
        children: [
          Row(
            children: [
              // Status pill
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: status.bgColor,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: status.color.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 7,
                      height: 7,
                      decoration: BoxDecoration(
                        color: status.color,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      status.label,
                      style: GoogleFonts.rajdhani(
                        color: status.color,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.3,
                      ),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              if (status == AttendanceStatus.notPunchedIn)
                _AttBtn(
                  label: 'Punch In',
                  icon: Icons.login_rounded,
                  color: TC.green,
                  onTap: vm.punchIn,
                ),
              if (status == AttendanceStatus.working) ...[
                _AttBtn(
                  label: 'Break',
                  icon: Icons.coffee_rounded,
                  color: TC.amber,
                  onTap: vm.startBreak,
                ),
                const SizedBox(width: 8),
                _AttBtn(
                  label: 'Punch Out',
                  icon: Icons.logout_rounded,
                  color: TC.red,
                  onTap: vm.punchOut,
                ),
              ],
              if (status == AttendanceStatus.onBreak)
                _AttBtn(
                  label: 'End Break',
                  icon: Icons.play_arrow_rounded,
                  color: TC.green,
                  onTap: vm.endBreak,
                ),
              if (status == AttendanceStatus.punchedOut)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: TC.greyBg,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    'Shift Ended',
                    style: GoogleFonts.rajdhani(
                      color: TC.grey,
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _AttCell(
                label: 'Punch In',
                value: s.punchIn,
                icon: Icons.login_rounded,
                color: TC.green,
              ),
              _vDivider(),
              _AttCell(
                label: 'Punch Out',
                value: s.punchOut,
                icon: Icons.logout_rounded,
                color: TC.red,
              ),
              _vDivider(),
              _AttCell(
                label: 'Break',
                value: s.breakTime,
                icon: Icons.coffee_rounded,
                color: TC.amber,
              ),
              _vDivider(),
              _AttCell(
                label: 'Work Hrs',
                value: s.workHours,
                icon: Icons.timer_rounded,
                color: TC.accent,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _vDivider() => Container(
    width: 1,
    height: 40,
    color: TC.border,
    margin: const EdgeInsets.symmetric(horizontal: 4),
  );
}

class _AttBtn extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _AttBtn({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
        decoration: BoxDecoration(
          color: color.withOpacity(0.10),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            Icon(icon, color: color, size: 14),
            const SizedBox(width: 5),
            Text(
              label,
              style: GoogleFonts.rajdhani(
                color: color,
                fontSize: 15,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AttCell extends StatelessWidget {
  final String label, value;
  final IconData icon;
  final Color color;
  const _AttCell({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(height: 4),
          // Value — matches dashboard KPI value style (orbitron)
          Text(
            value,
            style: GoogleFonts.orbitron(
              color: TC.textH,
              fontSize: 15,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.3,
            ),
          ),
          Text(
            label,
            style: GoogleFonts.rajdhani(
              color: TC.textM,
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

// ── PRODUCTIVITY SECTION ──────────────────────────────────────────────────────

class _ProductivitySection extends StatelessWidget {
  final ProductivitySummary p;
  const _ProductivitySection({required this.p});

  @override
  Widget build(BuildContext context) {
    return _Section(
      title: "Today's Productivity",
      icon: Icons.insights_rounded,
      child: Column(
        children: [
          Row(
            children: [
              // Efficiency ring
              SizedBox(
                width: 80,
                height: 80,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    CircularProgressIndicator(
                      value: p.efficiency / 100,
                      strokeWidth: 8,
                      backgroundColor: TC.accentLight,
                      valueColor: const AlwaysStoppedAnimation(TC.accent),
                    ),
                    Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            '${p.efficiency.toInt()}%',
                            style: GoogleFonts.orbitron(
                              color: TC.accent,
                              fontSize: 15,
                              fontWeight: FontWeight.w800,
                              letterSpacing: -0.3,
                            ),
                          ),
                          Text(
                            'Eff.',
                            style: GoogleFonts.rajdhani(
                              color: TC.textM,
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 20),
              Expanded(
                child: Column(
                  children: [
                    Row(
                      children: [
                        _ProdCell(
                          label: 'Assigned',
                          value: '${p.assignedJobs}',
                          color: TC.accent,
                        ),
                        _ProdCell(
                          label: 'In Progress',
                          value: '${p.inProgress}',
                          color: TC.amber,
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        _ProdCell(
                          label: 'Completed',
                          value: '${p.completedToday}',
                          color: TC.green,
                        ),
                        _ProdCell(
                          label: 'Avg Time',
                          value: p.avgTimePerJob,
                          color: TC.grey,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          // Total hours banner — matches dashboard analytics chip row style
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: TC.accentLight,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                const Icon(Icons.timer_outlined, color: TC.accent, size: 18),
                const SizedBox(width: 10),
                Text(
                  'Total Hours Worked:',
                  style: GoogleFonts.rajdhani(
                    color: TC.textB,
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const Spacer(),
                Text(
                  p.totalHoursWorked,
                  style: GoogleFonts.orbitron(
                    color: TC.accent,
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.3,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ProdCell extends StatelessWidget {
  final String label, value;
  final Color color;
  const _ProdCell({
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 2),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Value — orbitron like dashboard KPI values
            Text(
              value,
              style: GoogleFonts.orbitron(
                color: color,
                fontSize: 16,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.3,
              ),
            ),
            Text(
              label,
              style: GoogleFonts.rajdhani(
                color: TC.textM,
                fontSize: 15,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── ASSIGNED JOBS SECTION ─────────────────────────────────────────────────────

class _AssignedJobsSection extends StatelessWidget {
  final TechnicianDashboardViewModel vm;
  const _AssignedJobsSection({required this.vm});

  @override
  Widget build(BuildContext context) {
    return _Section(
      title: 'Assigned Jobs',
      icon: Icons.work_outline_rounded,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Job card search
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: vm.jobCardController,
                  onChanged: (_) => vm.clearQuickJobError(),
                  style: const TextStyle(color: TC.textH, fontSize: 13),
                  decoration: InputDecoration(
                    hintText: 'Enter Job Card Number...',
                    hintStyle: GoogleFonts.rajdhani(
                      color: TC.textM,
                      fontSize: 15,
                    ),
                    prefixIcon: const Icon(
                      Icons.search_rounded,
                      color: TC.textM,
                      size: 18,
                    ),
                    filled: true,
                    fillColor: TC.scaffold,
                    contentPadding: const EdgeInsets.symmetric(vertical: 11),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: TC.border),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: TC.border),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(
                        color: TC.accent,
                        width: 1.5,
                      ),
                    ),
                    errorText: vm.quickJobError.isNotEmpty
                        ? vm.quickJobError
                        : null,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              // Go button — matches dashboard gradient action button
              GestureDetector(
                onTap: () {
                  vm.searchJobCard();
                  if (vm.selectedJob != null) {
                    _openDetail(context, vm, vm.selectedJob!);
                  }
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 14,
                  ),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [TC.gStart, TC.gEnd],
                    ),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: TC.accent.withOpacity(0.30),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Text(
                    'Go',
                    style: GoogleFonts.rajdhani(
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                      fontSize: 15,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          ...vm.assignedJobs.map((job) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _AssignedJobCard(
                job: job,
                onStatusChanged: (s) => vm.updateAssignedJobStatus(job.id, s),
              ),
            );
          }),
        ],
      ),
    );
  }

  void _openDetail(
    BuildContext context,
    TechnicianDashboardViewModel vm,
    TechJobModel job,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => ChangeNotifierProvider.value(
        value: vm,
        child: _JobDetailSheet(job: job),
      ),
    ).whenComplete(vm.closeJob);
  }
}

class _AssignedJobCard extends StatelessWidget {
  final AssignedJob job;
  final void Function(AssignedJobStatus) onStatusChanged;
  const _AssignedJobCard({required this.job, required this.onStatusChanged});

  @override
  Widget build(BuildContext context) {
    final status = job.status;
    return Container(
      decoration: BoxDecoration(
        color: TC.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: TC.border),
        boxShadow: [
          BoxShadow(
            color: TC.primary.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          // Card header — matches dashboard job card register header row
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: const BoxDecoration(
              color: TC.surfaceAlt,
              borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.receipt_long_rounded,
                  size: 13,
                  color: TC.accent,
                ),
                const SizedBox(width: 6),
                Text(
                  job.id,
                  style: GoogleFonts.rajdhani(
                    color: TC.accent,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.3,
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 9,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: status.bgColor,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: status.color.withOpacity(0.3)),
                  ),
                  child: Text(
                    status.label,
                    style: GoogleFonts.rajdhani(
                      color: status.color,
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.2,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    // Avatar — matches dashboard message tile avatar style
                    Container(
                      width: 36,
                      height: 36,
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          colors: [TC.gStart, TC.gEnd],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Text(
                          job.customerName[0],
                          style: GoogleFonts.rajdhani(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            job.customerName,
                            style: const TextStyle(
                              color: TC.textH,
                              fontSize: 15,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Text(
                            job.vehicle,
                            style: const TextStyle(
                              color: TC.textM,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Container(height: 1, color: TC.border),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Service',
                            style: GoogleFonts.rajdhani(
                              color: TC.textM,
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          Text(
                            job.service,
                            style: const TextStyle(
                              color: TC.textB,
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                    _AssignedActionButton(
                      label: status.actionLabel,
                      color: status.color,
                      bg: status.bgColor,
                      onTap: () {
                        if (status == AssignedJobStatus.pending) {
                          onStatusChanged(AssignedJobStatus.inProgress);
                        } else if (status == AssignedJobStatus.inProgress) {
                          onStatusChanged(AssignedJobStatus.completed);
                        }
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _AssignedActionButton extends StatelessWidget {
  final String label;
  final Color color, bg;
  final VoidCallback onTap;
  const _AssignedActionButton({
    required this.label,
    required this.color,
    required this.bg,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withOpacity(0.35)),
        ),
        child: Text(
          label,
          style: GoogleFonts.rajdhani(
            color: color,
            fontSize: 12,
            fontWeight: FontWeight.w800,
            letterSpacing: 0.2,
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// TAB 2 — EFFICIENCY PORTAL  (My Jobs)
// ─────────────────────────────────────────────────────────────────────────────

class _EfficiencyTab extends StatelessWidget {
  const _EfficiencyTab();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<TechnicianDashboardViewModel>();

    return RefreshIndicator(
      color: TC.accent,
      strokeWidth: 2.5,
      onRefresh: vm.refresh,
      child: CustomScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: [
          // KPI chips — matches dashboard KPI grid style tokens
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: Row(
                children: [
                  _KpiChip(
                    label: 'Total',
                    value: '${vm.totalJobs}',
                    color: TC.accent,
                    bg: TC.accentLight,
                  ),
                  const SizedBox(width: 8),
                  _KpiChip(
                    label: 'In Progress',
                    value: '${vm.inProgressJobs}',
                    color: TC.amber,
                    bg: TC.amberBg,
                  ),
                  const SizedBox(width: 8),
                  _KpiChip(
                    label: 'Done',
                    value: '${vm.completedJobs}',
                    color: TC.green,
                    bg: TC.greenBg,
                  ),
                  const SizedBox(width: 8),
                  _KpiChip(
                    label: 'Delayed',
                    value: '${vm.delayedJobs}',
                    color: TC.red,
                    bg: TC.redBg,
                  ),
                ],
              ),
            ),
          ),
          // Search + filter row
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      onChanged: vm.updateSearch,
                      style: const TextStyle(color: TC.textH, fontSize: 13),
                      decoration: InputDecoration(
                        hintText: 'Search job card, vehicle, plate...',
                        hintStyle: GoogleFonts.rajdhani(
                          color: TC.textM,
                          fontSize: 14,
                        ),
                        prefixIcon: const Icon(
                          Icons.search_rounded,
                          color: TC.textM,
                          size: 18,
                        ),
                        filled: true,
                        fillColor: TC.surface,
                        contentPadding: const EdgeInsets.symmetric(
                          vertical: 11,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: TC.border),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: TC.border),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(
                            color: TC.accent,
                            width: 1.5,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Container(
                    height: 44,
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    decoration: BoxDecoration(
                      color: TC.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: TC.border),
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.filter_list_rounded,
                          color: TC.textM,
                          size: 16,
                        ),
                        const SizedBox(width: 4),
                        DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: vm.selectedFilter,
                            dropdownColor: TC.surface,
                            style: GoogleFonts.rajdhani(
                              color: TC.textH,
                              fontSize: 12,
                            ),
                            icon: const Icon(
                              Icons.keyboard_arrow_down_rounded,
                              color: TC.textM,
                              size: 16,
                            ),
                            onChanged: (v) =>
                                vm.updateFilter(v ?? 'All Status'),
                            items: vm.filterOptions
                                .map(
                                  (f) => DropdownMenuItem(
                                    value: f,
                                    child: Text(f),
                                  ),
                                )
                                .toList(),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          // Table header — matches dashboard job card register header row
          SliverToBoxAdapter(
            child: Container(
              margin: const EdgeInsets.fromLTRB(16, 14, 16, 0),
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: TC.accentLight,
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(12),
                ),
                border: Border.all(color: TC.accentMid),
              ),
              child: const Row(
                children: [
                  Expanded(flex: 3, child: _ColHead('JOB CARD #')),
                  Expanded(flex: 2, child: _ColHead('DATE')),
                  Expanded(flex: 2, child: _ColHead('BRAND')),
                  Expanded(flex: 2, child: _ColHead('MODEL')),
                  Expanded(flex: 2, child: _ColHead('PLATE')),
                  Expanded(flex: 2, child: _ColHead('STATUS')),
                ],
              ),
            ),
          ),
          vm.filteredJobs.isEmpty
              ? SliverFillRemaining(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          Icons.search_off_rounded,
                          size: 48,
                          color: TC.textM,
                        ),
                        const SizedBox(height: 12),
                        Text(
                          'No jobs found',
                          style: GoogleFonts.rajdhani(
                            color: TC.textM,
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              : SliverList(
                  delegate: SliverChildBuilderDelegate((context, i) {
                    final job = vm.filteredJobs[i];
                    return _JobRow(
                      job: job,
                      isEven: i % 2 == 0,
                      onTap: () => _openDetail(context, vm, job),
                    );
                  }, childCount: vm.filteredJobs.length),
                ),
          const SliverToBoxAdapter(child: SizedBox(height: 32)),
        ],
      ),
    );
  }

  void _openDetail(
    BuildContext context,
    TechnicianDashboardViewModel vm,
    TechJobModel job,
  ) {
    vm.openJob(job);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => ChangeNotifierProvider.value(
        value: vm,
        child: _JobDetailSheet(job: job),
      ),
    ).whenComplete(vm.closeJob);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// JOB ROW
// ─────────────────────────────────────────────────────────────────────────────

class _JobRow extends StatelessWidget {
  final TechJobModel job;
  final bool isEven;
  final VoidCallback onTap;
  const _JobRow({required this.job, required this.isEven, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
        decoration: BoxDecoration(
          color: isEven ? TC.surface : TC.surfaceAlt,
          border: const Border(
            left: BorderSide(color: TC.accentMid),
            right: BorderSide(color: TC.accentMid),
            bottom: BorderSide(color: TC.border),
          ),
        ),
        child: Row(
          children: [
            Expanded(
              flex: 3,
              child: Text(
                job.jobCardNo,
                style: GoogleFonts.rajdhani(
                  color: TC.accent,
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.2,
                ),
              ),
            ),
            Expanded(
              flex: 2,
              child: Text(
                job.dateOfWork,
                style: const TextStyle(color: TC.textB, fontSize: 11),
              ),
            ),
            Expanded(
              flex: 2,
              child: Text(
                job.vehicleBrand,
                style: const TextStyle(color: TC.textB, fontSize: 11),
              ),
            ),
            Expanded(
              flex: 2,
              child: Text(
                job.vehicleModel,
                style: const TextStyle(color: TC.textB, fontSize: 11),
              ),
            ),
            Expanded(
              flex: 2,
              child: Text(
                job.plateNumber,
                style: const TextStyle(color: TC.textB, fontSize: 11),
              ),
            ),
            Expanded(flex: 2, child: _StatusBadge(status: job.status)),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// STATUS BADGE
// ─────────────────────────────────────────────────────────────────────────────

class _StatusBadge extends StatelessWidget {
  final TechJobStatus status;
  const _StatusBadge({required this.status});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: status.bgColor,
        borderRadius: BorderRadius.circular(7),
        border: Border.all(color: status.color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 5,
            height: 5,
            decoration: BoxDecoration(
              color: status.color,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 4),
          Flexible(
            child: Text(
              status.label,
              style: GoogleFonts.rajdhani(
                color: status.color,
                fontSize: 9,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.2,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// JOB DETAIL BOTTOM SHEET
// ─────────────────────────────────────────────────────────────────────────────

class _JobDetailSheet extends StatefulWidget {
  final TechJobModel job;
  const _JobDetailSheet({required this.job});

  @override
  State<_JobDetailSheet> createState() => _JobDetailSheetState();
}

class _JobDetailSheetState extends State<_JobDetailSheet> {
  late TextEditingController _notesCtrl;

  @override
  void initState() {
    super.initState();
    _notesCtrl = TextEditingController(text: widget.job.notes);
  }

  @override
  void dispose() {
    _notesCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<TechnicianDashboardViewModel>();
    final job = widget.job;

    return DraggableScrollableSheet(
      initialChildSize: 0.92,
      minChildSize: 0.5,
      maxChildSize: 0.97,
      builder: (_, ctrl) => Container(
        decoration: const BoxDecoration(
          color: TC.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: Column(
          children: [
            // Handle
            Padding(
              padding: const EdgeInsets.only(top: 10, bottom: 4),
              child: Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: TC.border,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
            ),
            // Sheet header — gradient matching dashboard header banner
            Container(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [TC.gStart, TC.gEnd],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        job.jobCardNo,
                        style: GoogleFonts.orbitron(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.3,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: Colors.white38),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 6,
                              height: 6,
                              decoration: const BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 5),
                            Text(
                              job.status.label,
                              style: GoogleFonts.rajdhani(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 0.3,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Spacer(),
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          width: 30,
                          height: 30,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.18),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.close,
                            color: Colors.white,
                            size: 16,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Text(
                        '${job.vehicleBrand} ${job.vehicleModel}',
                        style: GoogleFonts.rajdhani(
                          color: Colors.white70,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: TC.accentLight,
                          borderRadius: BorderRadius.circular(7),
                        ),
                        child: Text(
                          job.plateNumber,
                          style: GoogleFonts.rajdhani(
                            color: TC.accent,
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 0.3,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Text(
                        'Job Progress',
                        style: GoogleFonts.rajdhani(
                          color: Colors.white70,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        '${job.completedTasks}/${job.tasks.length} tasks (${(job.progressPercent * 100).toInt()}%)',
                        style: GoogleFonts.rajdhani(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: LinearProgressIndicator(
                      value: job.progressPercent,
                      backgroundColor: Colors.white.withOpacity(0.2),
                      valueColor: const AlwaysStoppedAnimation(Colors.white),
                      minHeight: 7,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                controller: ctrl,
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                children: [
                  // Section label — matches dashboard _sectionLabel
                  Row(
                    children: [
                      Container(
                        width: 4,
                        height: 20,
                        decoration: BoxDecoration(
                          color: TC.accent,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text(
                        'Work Tasks',
                        style: GoogleFonts.rajdhani(
                          color: TC.textH,
                          fontSize: 19,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Track and update task progress',
                    style: GoogleFonts.rajdhani(
                      color: TC.textM,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 12),
                  // Table header
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: TC.accentLight,
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(10),
                      ),
                      border: Border.all(color: TC.accentMid),
                    ),
                    child: const Row(
                      children: [
                        SizedBox(width: 28, child: _ColHead('S.No')),
                        Expanded(flex: 4, child: _ColHead('Description')),
                        SizedBox(width: 46, child: _ColHead('Start')),
                        SizedBox(width: 38, child: _ColHead('End')),
                        SizedBox(width: 88, child: _ColHead('Status')),
                        SizedBox(width: 64, child: _ColHead('Action')),
                      ],
                    ),
                  ),
                  ...job.tasks.asMap().entries.map((e) {
                    final task = e.value;
                    return _TaskRow(
                      index: e.key + 1,
                      task: task,
                      isEven: e.key % 2 == 0,
                      onStart: () => vm.startTask(job, task),
                      onComplete: () => vm.completeTask(job, task),
                      onStatusChanged: (s) => vm.updateTaskStatus(job, task, s),
                    );
                  }),
                  Container(
                    height: 1,
                    margin: const EdgeInsets.only(bottom: 20),
                    decoration: const BoxDecoration(
                      border: Border(
                        left: BorderSide(color: TC.accentMid),
                        right: BorderSide(color: TC.accentMid),
                        bottom: BorderSide(color: TC.accentMid),
                      ),
                    ),
                  ),
                  // Notes label — matches dashboard section label style
                  Row(
                    children: [
                      Container(
                        width: 4,
                        height: 20,
                        decoration: BoxDecoration(
                          color: TC.accent,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                      const SizedBox(width: 10),
                      const Icon(
                        Icons.sticky_note_2_outlined,
                        size: 16,
                        color: TC.textM,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        'Technician Notes',
                        style: GoogleFonts.rajdhani(
                          color: TC.textH,
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.3,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _notesCtrl,
                    maxLines: 4,
                    onChanged: (v) => vm.updateNotes(job, v),
                    style: const TextStyle(color: TC.textH, fontSize: 13),
                    decoration: InputDecoration(
                      hintText:
                          'Add any notes or observations about this job...',
                      hintStyle: GoogleFonts.rajdhani(
                        color: TC.textM,
                        fontSize: 12,
                      ),
                      filled: true,
                      fillColor: TC.scaffold,
                      contentPadding: const EdgeInsets.all(14),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: TC.border),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: TC.border),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: TC.accent,
                          width: 1.5,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
            // Bottom action row — matches dashboard Quick Actions bar
            Container(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
              decoration: const BoxDecoration(
                color: TC.surface,
                border: Border(top: BorderSide(color: TC.border)),
              ),
              child: SafeArea(
                top: false,
                child: Row(
                  children: [
                    // Close — outline style
                    OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: TC.textB,
                        side: const BorderSide(color: TC.border),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 14,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text(
                        'Close',
                        style: GoogleFonts.rajdhani(
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                          color: TC.textB,
                        ),
                      ),
                    ),
                    const Spacer(),
                    // Save — outline accent
                    OutlinedButton.icon(
                      onPressed: vm.isSaving ? null : () => vm.saveChanges(job),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: TC.accent,
                        side: const BorderSide(color: TC.accent, width: 1.5),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 14,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      icon: vm.isSaving
                          ? const SizedBox(
                              width: 14,
                              height: 14,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: TC.accent,
                              ),
                            )
                          : const Icon(Icons.save_rounded, size: 16),
                      label: Text(
                        'Save',
                        style: GoogleFonts.rajdhani(
                          fontWeight: FontWeight.w800,
                          fontSize: 13,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    // Complete Job — gradient button matching dashboard _ActionButton
                    GestureDetector(
                      onTap: vm.isSaving
                          ? null
                          : () async {
                              await vm.completeJob(job);
                              if (context.mounted) {
                                Navigator.pop(context);
                              }
                            },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 14,
                        ),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [TC.gStart, TC.gEnd],
                          ),
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: TC.accent.withOpacity(0.30),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.check_circle_outline_rounded,
                              color: Colors.white,
                              size: 16,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              'Complete Job',
                              style: GoogleFonts.rajdhani(
                                color: Colors.white,
                                fontWeight: FontWeight.w800,
                                fontSize: 13,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// TASK ROW
// ─────────────────────────────────────────────────────────────────────────────

class _TaskRow extends StatelessWidget {
  final int index;
  final WorkTask task;
  final bool isEven;
  final VoidCallback onStart;
  final VoidCallback onComplete;
  final void Function(TaskStatus) onStatusChanged;

  const _TaskRow({
    required this.index,
    required this.task,
    required this.isEven,
    required this.onStart,
    required this.onComplete,
    required this.onStatusChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        color: isEven ? TC.surface : TC.surfaceAlt,
        border: const Border(
          left: BorderSide(color: TC.accentMid),
          right: BorderSide(color: TC.accentMid),
          bottom: BorderSide(color: TC.border),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            width: 28,
            child: Text(
              '$index',
              style: GoogleFonts.rajdhani(
                color: TC.textM,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Expanded(
            flex: 4,
            child: Text(
              task.description,
              style: const TextStyle(color: TC.textB, fontSize: 11),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          SizedBox(
            width: 46,
            child: Text(
              task.startTime ?? '–',
              style: const TextStyle(color: TC.textM, fontSize: 11),
            ),
          ),
          SizedBox(
            width: 38,
            child: Text(
              task.endTime ?? '–',
              style: const TextStyle(color: TC.textM, fontSize: 11),
            ),
          ),
          SizedBox(
            width: 88,
            child: _TaskStatusDropdown(
              status: task.status,
              onChanged: onStatusChanged,
            ),
          ),
          SizedBox(
            width: 64,
            child: _TaskActionButton(
              task: task,
              onStart: onStart,
              onComplete: onComplete,
            ),
          ),
        ],
      ),
    );
  }
}

class _TaskStatusDropdown extends StatelessWidget {
  final TaskStatus status;
  final void Function(TaskStatus) onChanged;
  const _TaskStatusDropdown({required this.status, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    Color border, bg;
    switch (status) {
      case TaskStatus.completed:
        border = TC.green;
        bg = TC.greenBg;
        break;
      case TaskStatus.inProgress:
        border = TC.accent;
        bg = TC.accentLight;
        break;
      default:
        border = TC.border;
        bg = TC.scaffold;
    }
    return Container(
      height: 30,
      padding: const EdgeInsets.symmetric(horizontal: 6),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: border),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<TaskStatus>(
          value: status,
          isDense: true,
          dropdownColor: TC.surface,
          icon: const Icon(
            Icons.keyboard_arrow_down_rounded,
            size: 12,
            color: TC.textM,
          ),
          style: GoogleFonts.rajdhani(
            color: TC.textH,
            fontSize: 10,
            fontWeight: FontWeight.w700,
          ),
          onChanged: (v) {
            if (v != null) onChanged(v);
          },
          items: TaskStatus.values
              .map(
                (s) => DropdownMenuItem(
                  value: s,
                  child: Text(
                    s.label,
                    style: GoogleFonts.rajdhani(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              )
              .toList(),
        ),
      ),
    );
  }
}

class _TaskActionButton extends StatelessWidget {
  final WorkTask task;
  final VoidCallback onStart;
  final VoidCallback onComplete;
  const _TaskActionButton({
    required this.task,
    required this.onStart,
    required this.onComplete,
  });

  @override
  Widget build(BuildContext context) {
    if (task.status == TaskStatus.completed) {
      return const SizedBox.shrink();
    }
    final inProg = task.status == TaskStatus.inProgress;
    return GestureDetector(
      onTap: inProg ? onComplete : onStart,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
        decoration: BoxDecoration(
          color: inProg ? TC.greenBg : TC.accentLight,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: inProg ? TC.green : TC.accent),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              inProg
                  ? Icons.check_circle_outline_rounded
                  : Icons.play_arrow_rounded,
              color: inProg ? TC.green : TC.accent,
              size: 12,
            ),
            const SizedBox(width: 3),
            Text(
              inProg ? 'Done' : 'Start',
              style: GoogleFonts.rajdhani(
                color: inProg ? TC.green : TC.accent,
                fontSize: 10,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SHARED SMALL WIDGETS
// ─────────────────────────────────────────────────────────────────────────────

/// [_Section] — matches dashboard _SurfaceCard + _sectionLabel combined
class _Section extends StatelessWidget {
  final String title;
  final IconData icon;
  final Widget child;
  const _Section({
    required this.title,
    required this.icon,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: TC.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: TC.border),
        boxShadow: [
          BoxShadow(
            color: TC.primary.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Section header — matches dashboard _sectionLabel accent bar style
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: const BoxDecoration(
              color: TC.surfaceAlt,
              borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
            ),
            child: Row(
              children: [
                Container(
                  width: 4,
                  height: 20,
                  decoration: BoxDecoration(
                    color: TC.accent,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 10),
                Container(
                  width: 28,
                  height: 28,
                  decoration: BoxDecoration(
                    color: TC.accentLight,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, color: TC.accent, size: 15),
                ),
                const SizedBox(width: 10),
                Text(
                  title,
                  style: GoogleFonts.rajdhani(
                    color: TC.textH,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
          Padding(padding: const EdgeInsets.all(16), child: child),
        ],
      ),
    );
  }
}

/// [_KpiChip] — matches dashboard _KpiCard condensed chip version
class _KpiChip extends StatelessWidget {
  final String label, value;
  final Color color, bg;
  const _KpiChip({
    required this.label,
    required this.value,
    required this.color,
    required this.bg,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        decoration: BoxDecoration(
          color: TC.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: TC.border),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.06),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Value — orbitron matching dashboard KPI card values
            Text(
              value,
              style: GoogleFonts.orbitron(
                color: color,
                fontSize: 18,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.3,
              ),
            ),
            Text(
              label,
              style: GoogleFonts.rajdhani(
                color: TC.textM,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}

/// [_ColHead] — matches dashboard Job Card Register table header style
class _ColHead extends StatelessWidget {
  final String text;
  const _ColHead(this.text);

  @override
  Widget build(BuildContext context) => Text(
    text,
    style: GoogleFonts.rajdhani(
      color: TC.accent,
      fontSize: 10,
      fontWeight: FontWeight.w800,
      letterSpacing: 0.5,
    ),
  );
}
