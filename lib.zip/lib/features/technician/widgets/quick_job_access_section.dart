// import 'package:flutter/material.dart';
// import 'package:orientmobileapplication/features/technician/viewmodel/technician_dashboard_viewmodel.dart';
// import 'attendance_section.dart';

// class QuickJobAccessSection extends StatelessWidget {
//   final TechnicianDashboardViewModel vm;

//   const QuickJobAccessSection({super.key, required this.vm});

//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         TechSectionHeader(
//           label: 'Quick Job Access',
//           icon: Icons.qr_code_2,
//           color: const Color(0xFFEA580C),
//         ),
//         const SizedBox(height: 14),

//         // Scan QR button
//         Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 12),
//           child: GestureDetector(
//             onTap: () {},
//             child: Container(
//               width: double.infinity,
//               height: 64,
//               decoration: BoxDecoration(
//                 color: const Color(0xFFF97316),
//                 borderRadius: BorderRadius.circular(10),
//               ),
//               child: const Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Icon(Icons.qr_code_scanner, color: Colors.white, size: 22),
//                   SizedBox(height: 4),
//                   Text(
//                     'Scan QR Code',
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontWeight: FontWeight.w700,
//                       fontSize: 14,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//         const SizedBox(height: 12),

//         // OR divider
//         Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 12),
//           child: Row(
//             children: [
//               const Expanded(child: Divider(color: Color(0xFFE5E7EB))),
//               Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 12),
//                 child: Text(
//                   'OR',
//                   style: TextStyle(
//                     fontSize: 12,
//                     color: Colors.grey.shade400,
//                     fontWeight: FontWeight.w500,
//                   ),
//                 ),
//               ),
//               const Expanded(child: Divider(color: Color(0xFFE5E7EB))),
//             ],
//           ),
//         ),
//         const SizedBox(height: 12),

//         // Enter Job Card Number
//         Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 12),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               const Text(
//                 'Enter Job Card Number',
//                 style: TextStyle(
//                   fontSize: 12,
//                   fontWeight: FontWeight.w600,
//                   color: Color(0xFF374151),
//                 ),
//               ),
//               const SizedBox(height: 6),
//               Row(
//                 children: [
//                   Expanded(
//                     child: Container(
//                       decoration: BoxDecoration(
//                         color: const Color(0xFFF3F4F6),
//                         borderRadius: BorderRadius.circular(10),
//                         border: Border.all(color: const Color(0xFFE5E7EB)),
//                       ),
//                       child: TextField(
//                         controller: vm.jobCardController,
//                         style: const TextStyle(
//                             fontSize: 13, color: Color(0xFF111827)),
//                         decoration: const InputDecoration(
//                           hintText: 'e.g., JC-2024-1245',
//                           hintStyle: TextStyle(
//                               color: Color(0xFF9CA3AF), fontSize: 13),
//                           border: InputBorder.none,
//                           contentPadding: EdgeInsets.symmetric(
//                               horizontal: 14, vertical: 12),
//                         ),
//                       ),
//                     ),
//                   ),
//                   const SizedBox(width: 8),
//                   Container(
//                     width: 46,
//                     height: 46,
//                     decoration: BoxDecoration(
//                       color: const Color(0xFF111827),
//                       borderRadius: BorderRadius.circular(10),
//                     ),
//                     child: const Icon(Icons.search,
//                         color: Colors.white, size: 20),
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         ),
//         const SizedBox(height: 4),
//       ],
//     );
//   }
// }
