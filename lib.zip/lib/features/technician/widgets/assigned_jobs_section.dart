// import 'package:flutter/material.dart';
// import 'package:orientmobileapplication/features/technician/model/technician_dashboard_model.dart';
// import 'attendance_section.dart';

// class AssignedJobsSection extends StatelessWidget {
//   final List<AssignedJob> jobs;

//   const AssignedJobsSection({super.key, required this.jobs});

//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         TechSectionHeader(
//           label: 'Assigned Jobs',
//           icon: Icons.assignment_outlined,
//           color: const Color(0xFF16A34A),
//           trailing: Container(
//             padding:
//                 const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
//             decoration: BoxDecoration(
//               color: Colors.white24,
//               borderRadius: BorderRadius.circular(20),
//             ),
//             child: Text(
//               '${jobs.length} Jobs',
//               style: const TextStyle(
//                 color: Colors.white,
//                 fontSize: 11,
//                 fontWeight: FontWeight.w600,
//               ),
//             ),
//           ),
//         ),
//         const SizedBox(height: 10),
//         ...jobs.map((job) => _JobRow(job: job)),
//         const SizedBox(height: 8),
//       ],
//     );
//   }
// }

// class _JobRow extends StatelessWidget {
//   final AssignedJob job;
//   const _JobRow({required this.job});

//   @override
//   Widget build(BuildContext context) {
//     final statusColor = Color(job.statusColor);
//     final statusBg = Color(job.statusBg);
//     final actionColor = Color(job.actionColor);

//     return Container(
//       margin: const EdgeInsets.fromLTRB(12, 0, 12, 8),
//       padding: const EdgeInsets.all(14),
//       decoration: BoxDecoration(
//         color: Colors.white,
//         borderRadius: BorderRadius.circular(10),
//         border: Border.all(color: const Color(0xFFE5E7EB), width: 0.8),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.black.withOpacity(0.03),
//             blurRadius: 6,
//             offset: const Offset(0, 2),
//           ),
//         ],
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           // ID + status badge
//           Row(
//             children: [
//               Text(
//                 job.id,
//                 style: const TextStyle(
//                   fontSize: 12,
//                   fontWeight: FontWeight.w600,
//                   color: Color(0xFF374151),
//                 ),
//               ),
//               const SizedBox(width: 8),
//               Container(
//                 padding:
//                     const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
//                 decoration: BoxDecoration(
//                   color: statusBg,
//                   borderRadius: BorderRadius.circular(20),
//                 ),
//                 child: Text(
//                   job.statusLabel,
//                   style: TextStyle(
//                     fontSize: 10,
//                     fontWeight: FontWeight.w600,
//                     color: statusColor,
//                   ),
//                 ),
//               ),
//             ],
//           ),
//           const SizedBox(height: 5),

//           // Customer name
//           Text(
//             job.customerName,
//             style: const TextStyle(
//               fontSize: 14,
//               fontWeight: FontWeight.w700,
//               color: Color(0xFF111827),
//             ),
//           ),
//           const SizedBox(height: 2),

//           // Vehicle
//           Text(
//             job.vehicle,
//             style: const TextStyle(
//                 fontSize: 12, color: Color(0xFF6B7280)),
//           ),
//           const SizedBox(height: 4),

//           // Service
//           Text(
//             job.service,
//             style: const TextStyle(
//                 fontSize: 12, color: Color(0xFF374151)),
//           ),

//           if (job.amount > 0) ...[
//             const SizedBox(height: 8),
//             const Divider(height: 1, color: Color(0xFFF3F4F6)),
//             const SizedBox(height: 8),
//             Row(
//               children: [
//                 Text(
//                   '${job.amount} hrs',
//                   style: const TextStyle(
//                     fontSize: 12,
//                     color: Color(0xFF6B7280),
//                   ),
//                 ),
//                 const Spacer(),
//                 _ActionChip(
//                     label: job.actionLabel, color: actionColor),
//               ],
//             ),
//           ] else ...[
//             const SizedBox(height: 8),
//             const Divider(height: 1, color: Color(0xFFF3F4F6)),
//             const SizedBox(height: 8),
//             Align(
//               alignment: Alignment.centerRight,
//               child:
//                   _ActionChip(label: job.actionLabel, color: actionColor),
//             ),
//           ],
//         ],
//       ),
//     );
//   }
// }

// class _ActionChip extends StatelessWidget {
//   final String label;
//   final Color color;
//   const _ActionChip({required this.label, required this.color});

//   @override
//   Widget build(BuildContext context) {
//     return GestureDetector(
//       onTap: () {},
//       child: Container(
//         padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
//         decoration: BoxDecoration(
//           color: color.withOpacity(0.1),
//           borderRadius: BorderRadius.circular(20),
//           border: Border.all(color: color.withOpacity(0.3)),
//         ),
//         child: Text(
//           label,
//           style: TextStyle(
//             fontSize: 12,
//             fontWeight: FontWeight.w600,
//             color: color,
//           ),
//         ),
//       ),
//     );
//   }
// }
