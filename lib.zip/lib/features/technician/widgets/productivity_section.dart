// import 'package:flutter/material.dart';
// import 'package:orientmobileapplication/features/technician/model/technician_dashboard_model.dart';
// import 'attendance_section.dart';

// class ProductivitySection extends StatelessWidget {
//   final ProductivitySummary productivity;

//   const ProductivitySection({super.key, required this.productivity});

//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         TechSectionHeader(
//           label: "Today's Productivity",
//           icon: Icons.trending_up,
//           color: const Color(0xFF7C3AED),
//         ),
//         const SizedBox(height: 14),

//         Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 12),
//           child: Column(
//             children: [
//               // Row 1: Assigned Jobs + In Progress
//               Row(
//                 children: [
//                   Expanded(
//                     child: _StatCard(
//                       label: 'Assigned Jobs',
//                       value: '${productivity.assignedJobs}',
//                       icon: Icons.adjust,
//                       iconColor: const Color(0xFF2563EB),
//                       bgColor: const Color(0xFFEFF6FF),
//                     ),
//                   ),
//                   const SizedBox(width: 10),
//                   Expanded(
//                     child: _StatCard(
//                       label: 'In Progress',
//                       value: '${productivity.inProgress}',
//                       icon: Icons.access_time,
//                       iconColor: const Color(0xFFD97706),
//                       bgColor: const Color(0xFFFFFBEB),
//                     ),
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 10),
//               // Row 2: Completed Today + Efficiency
//               Row(
//                 children: [
//                   Expanded(
//                     child: _StatCard(
//                       label: 'Completed Today',
//                       value: '${productivity.completedToday}',
//                       icon: Icons.check_circle_outline,
//                       iconColor: const Color(0xFF16A34A),
//                       bgColor: const Color(0xFFF0FDF4),
//                     ),
//                   ),
//                   const SizedBox(width: 10),
//                   Expanded(
//                     child: _StatCard(
//                       label: 'Efficiency',
//                       value: '${productivity.efficiency.toInt()}%',
//                       icon: Icons.bar_chart,
//                       iconColor: const Color(0xFF7C3AED),
//                       bgColor: const Color(0xFFF5F3FF),
//                     ),
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 10),
//               // Row 3: Avg Time per Job + Total Hours
//               Row(
//                 children: [
//                   Expanded(
//                     child: _StatCard(
//                       label: 'Avg Time per Job',
//                       value: productivity.avgTimePerJob,
//                       icon: Icons.timer_outlined,
//                       iconColor: const Color(0xFF0284C7),
//                       bgColor: const Color(0xFFF0F9FF),
//                     ),
//                   ),
//                   const SizedBox(width: 10),
//                   Expanded(
//                     child: _StatCard(
//                       label: 'Total Hours Worked',
//                       value: productivity.totalHoursWorked,
//                       icon: Icons.schedule,
//                       iconColor: const Color(0xFFE87722),
//                       bgColor: const Color(0xFFFFF3E8),
//                     ),
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ],
//     );
//   }
// }

// class _StatCard extends StatelessWidget {
//   final String label;
//   final String value;
//   final IconData icon;
//   final Color iconColor;
//   final Color bgColor;

//   const _StatCard({
//     required this.label,
//     required this.value,
//     required this.icon,
//     required this.iconColor,
//     required this.bgColor,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: const EdgeInsets.all(14),
//       decoration: BoxDecoration(
//         color: bgColor,
//         borderRadius: BorderRadius.circular(10),
//         border: Border.all(color: const Color(0xFFE5E7EB), width: 0.5),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Icon(icon, color: iconColor, size: 18),
//           const SizedBox(height: 8),
//           Text(
//             label,
//             style: const TextStyle(
//                 fontSize: 11,
//                 color: Color(0xFF6B7280),
//                 fontWeight: FontWeight.w500),
//           ),
//           const SizedBox(height: 3),
//           Text(
//             value,
//             style: const TextStyle(
//               fontSize: 20,
//               fontWeight: FontWeight.w800,
//               color: Color(0xFF111827),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
