import 'package:flutter/material.dart';
import 'package:orientmobileapplication/features/technician/model/technician_dashboard_model.dart';

class TechnicianHeader extends StatelessWidget {
  final TechnicianProfile profile;
  final String statusLabel;
  final int statusColor;
  final int statusBg;
  final VoidCallback onLogout;

  const TechnicianHeader({
    super.key,
    required this.profile,
    required this.statusLabel,
    required this.statusColor,
    required this.statusBg,
    required this.onLogout,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 10,
        left: 16,
        right: 12,
        bottom: 12,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              // Avatar
              CircleAvatar(
                radius: 22,
                backgroundColor: const Color(0xFF2563EB),
                child: Text(
                  profile.avatarInitials,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      profile.name,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF111827),
                      ),
                    ),
                    Text(
                      '${profile.empId} • ${profile.role}',
                      style: const TextStyle(
                          fontSize: 12, color: Color(0xFF6B7280)),
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: onLogout,
                child: const Icon(Icons.logout,
                    color: Color(0xFFDC2626), size: 22),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              // Status pill
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Color(statusBg),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  statusLabel,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Color(statusColor),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              const _Dot(),
              const SizedBox(width: 6),
              Text(
                'Branch: ${profile.branch}',
                style: const TextStyle(
                    fontSize: 12, color: Color(0xFF6B7280)),
              ),
              const SizedBox(width: 6),
              const _Dot(),
              const SizedBox(width: 6),
              Text(
                'Shift: ${profile.shift}',
                style: const TextStyle(
                    fontSize: 12, color: Color(0xFF6B7280)),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Dot extends StatelessWidget {
  const _Dot();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 4,
      height: 4,
      decoration: const BoxDecoration(
        color: Color(0xFF9CA3AF),
        shape: BoxShape.circle,
      ),
    );
  }
}
