// import 'package:flutter/material.dart';
// import 'package:orientmobileapplication/features/technician/model/technician_dashboard_model.dart';
// import 'package:orientmobileapplication/features/technician/viewmodel/technician_dashboard_viewmodel.dart';


// class AttendanceSection extends StatelessWidget {
//   final TechnicianDashboardViewModel vm;

//   const AttendanceSection({super.key, required this.vm});

//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         // Section header
//         _SectionHeader(
//           label: 'Attendance',
//           icon: Icons.access_time,
//           color: const Color(0xFF2563EB),
//         ),
//         const SizedBox(height: 14),

//         // Punch In / Punch Out row
//         Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 12),
//           child: Row(
//             children: [
//               Expanded(
//                 child: _ActionButton(
//                   label: 'Punch In',
//                   icon: Icons.login,
//                   color: const Color(0xFF4ADE80),
//                   bgColor: const Color(0xFF22C55E),
//                   enabled: vm.attendanceStatus ==
//                       AttendanceStatus.notPunchedIn,
//                   onTap: vm.punchIn,
//                 ),
//               ),
//               const SizedBox(width: 10),
//               Expanded(
//                 child: _ActionButton(
//                   label: 'Punch Out',
//                   icon: Icons.logout,
//                   color: Colors.white,
//                   bgColor: const Color(0xFFDC2626),
//                   enabled: vm.attendanceStatus == AttendanceStatus.working ||
//                       vm.attendanceStatus == AttendanceStatus.onBreak,
//                   onTap: vm.punchOut,
//                 ),
//               ),
//             ],
//           ),
//         ),
//         const SizedBox(height: 10),

//         // Start Break / End Break row
//         Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 12),
//           child: Row(
//             children: [
//               Expanded(
//                 child: _OutlineButton(
//                   label: 'Start Break',
//                   icon: Icons.free_breakfast_outlined,
//                   enabled:
//                       vm.attendanceStatus == AttendanceStatus.working,
//                   onTap: vm.startBreak,
//                 ),
//               ),
//               const SizedBox(width: 10),
//               Expanded(
//                 child: _OutlineButton(
//                   label: 'End Break',
//                   icon: Icons.play_arrow_outlined,
//                   enabled:
//                       vm.attendanceStatus == AttendanceStatus.onBreak,
//                   onTap: vm.endBreak,
//                 ),
//               ),
//             ],
//           ),
//         ),
//         const SizedBox(height: 18),

//         // Today's Summary label
//         const Padding(
//           padding: EdgeInsets.symmetric(horizontal: 16),
//           child: Text(
//             "Today's Summary",
//             style: TextStyle(
//               fontSize: 14,
//               fontWeight: FontWeight.w700,
//               color: Color(0xFF111827),
//             ),
//           ),
//         ),
//         const SizedBox(height: 10),

//         // Summary grid
//         Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 12),
//           child: Column(
//             children: [
//               Row(
//                 children: [
//                   Expanded(
//                     child: _SummaryCard(
//                       label: 'Punch In',
//                       value: vm.summary.punchIn,
//                       bgColor: const Color(0xFFF0FDF4),
//                     ),
//                   ),
//                   const SizedBox(width: 10),
//                   Expanded(
//                     child: _SummaryCard(
//                       label: 'Punch Out',
//                       value: vm.summary.punchOut,
//                       bgColor: const Color(0xFFFEF2F2),
//                     ),
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 10),
//               Row(
//                 children: [
//                   Expanded(
//                     child: _SummaryCard(
//                       label: 'Break Time',
//                       value: vm.summary.breakTime,
//                       bgColor: const Color(0xFFFFFBEB),
//                     ),
//                   ),
//                   const SizedBox(width: 10),
//                   Expanded(
//                     child: _SummaryCard(
//                       label: 'Work Hours',
//                       value: vm.summary.workHours,
//                       bgColor: const Color(0xFFEFF6FF),
//                     ),
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ],
//     );
//   }
// }

// class _SectionHeader extends StatelessWidget {
//   final String label;
//   final IconData icon;
//   final Color color;

//   const _SectionHeader({
//     required this.label,
//     required this.icon,
//     required this.color,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       width: double.infinity,
//       padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
//       color: color,
//       child: Row(
//         children: [
//           Icon(icon, color: Colors.white, size: 18),
//           const SizedBox(width: 8),
//           Text(
//             label,
//             style: const TextStyle(
//               color: Colors.white,
//               fontWeight: FontWeight.w700,
//               fontSize: 15,
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// // Expose for reuse
// class TechSectionHeader extends StatelessWidget {
//   final String label;
//   final IconData icon;
//   final Color color;
//   final Widget? trailing;

//   const TechSectionHeader({
//     super.key,
//     required this.label,
//     required this.icon,
//     required this.color,
//     this.trailing,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       width: double.infinity,
//       padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
//       color: color,
//       child: Row(
//         children: [
//           Icon(icon, color: Colors.white, size: 18),
//           const SizedBox(width: 8),
//           Expanded(
//             child: Text(
//               label,
//               style: const TextStyle(
//                 color: Colors.white,
//                 fontWeight: FontWeight.w700,
//                 fontSize: 15,
//               ),
//             ),
//           ),
//           if (trailing != null) trailing!,
//         ],
//       ),
//     );
//   }
// }

// class _ActionButton extends StatelessWidget {
//   final String label;
//   final IconData icon;
//   final Color color;
//   final Color bgColor;
//   final bool enabled;
//   final VoidCallback onTap;

//   const _ActionButton({
//     required this.label,
//     required this.icon,
//     required this.color,
//     required this.bgColor,
//     required this.enabled,
//     required this.onTap,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return GestureDetector(
//       onTap: enabled ? onTap : null,
//       child: AnimatedContainer(
//         duration: const Duration(milliseconds: 200),
//         height: 52,
//         decoration: BoxDecoration(
//           color: enabled ? bgColor : bgColor.withOpacity(0.45),
//           borderRadius: BorderRadius.circular(10),
//         ),
//         child: Row(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Icon(icon, color: Colors.white, size: 18),
//             const SizedBox(width: 8),
//             Text(
//               label,
//               style: const TextStyle(
//                 color: Colors.white,
//                 fontWeight: FontWeight.w700,
//                 fontSize: 14,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// class _OutlineButton extends StatelessWidget {
//   final String label;
//   final IconData icon;
//   final bool enabled;
//   final VoidCallback onTap;

//   const _OutlineButton({
//     required this.label,
//     required this.icon,
//     required this.enabled,
//     required this.onTap,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return GestureDetector(
//       onTap: enabled ? onTap : null,
//       child: Container(
//         height: 46,
//         decoration: BoxDecoration(
//           color: Colors.white,
//           borderRadius: BorderRadius.circular(10),
//           border: Border.all(
//             color: enabled
//                 ? const Color(0xFFD1D5DB)
//                 : const Color(0xFFE5E7EB),
//           ),
//         ),
//         child: Row(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Icon(
//               icon,
//               color: enabled
//                   ? const Color(0xFF374151)
//                   : const Color(0xFF9CA3AF),
//               size: 17,
//             ),
//             const SizedBox(width: 6),
//             Text(
//               label,
//               style: TextStyle(
//                 color: enabled
//                     ? const Color(0xFF374151)
//                     : const Color(0xFF9CA3AF),
//                 fontWeight: FontWeight.w600,
//                 fontSize: 13,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// class _SummaryCard extends StatelessWidget {
//   final String label;
//   final String value;
//   final Color bgColor;

//   const _SummaryCard({
//     required this.label,
//     required this.value,
//     required this.bgColor,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: const EdgeInsets.all(14),
//       decoration: BoxDecoration(
//         color: bgColor,
//         borderRadius: BorderRadius.circular(10),
//         border: Border.all(color: const Color(0xFFE5E7EB), width: 0.5),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Text(
//             label,
//             style: const TextStyle(
//                 fontSize: 11,
//                 color: Color(0xFF6B7280),
//                 fontWeight: FontWeight.w500),
//           ),
//           const SizedBox(height: 4),
//           Text(
//             value,
//             style: const TextStyle(
//               fontSize: 16,
//               fontWeight: FontWeight.w800,
//               color: Color(0xFF111827),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
