// ─────────────────────────────────────────────────────────────────────────────
// technician_models.dart
// lib/features/technician/model/technician_models.dart
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';

// ─────────────────────────────────────────────────────────────────────────────
// PROFILE
// ─────────────────────────────────────────────────────────────────────────────

class TechnicianProfile {
  final String name;
  final String empId;
  final String role;
  final String branch;
  final String shift;
  final String avatarInitials;

  const TechnicianProfile({
    required this.name,
    required this.empId,
    required this.role,
    required this.branch,
    required this.shift,
    required this.avatarInitials,
  });

  static const mock = TechnicianProfile(
    name: 'Mohammed Hassan',
    empId: 'EMP-001',
    role: 'Technician',
    branch: 'Main Dubai',
    shift: '8:00 AM - 6:00 PM',
    avatarInitials: 'MH',
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ATTENDANCE
// ─────────────────────────────────────────────────────────────────────────────

enum AttendanceStatus { notPunchedIn, working, onBreak, punchedOut }

extension AttendanceStatusX on AttendanceStatus {
  String get label {
    switch (this) {
      case AttendanceStatus.notPunchedIn: return 'Not Punched In';
      case AttendanceStatus.working:      return 'Working';
      case AttendanceStatus.onBreak:      return 'On Break';
      case AttendanceStatus.punchedOut:   return 'Punched Out';
    }
  }

  Color get color {
    switch (this) {
      case AttendanceStatus.notPunchedIn: return const Color(0xFF6B7280);
      case AttendanceStatus.working:      return const Color(0xFF16A34A);
      case AttendanceStatus.onBreak:      return const Color(0xFFD97706);
      case AttendanceStatus.punchedOut:   return const Color(0xFFDC2626);
    }
  }

  Color get bgColor {
    switch (this) {
      case AttendanceStatus.notPunchedIn: return const Color(0xFFF3F4F6);
      case AttendanceStatus.working:      return const Color(0xFFF0FDF4);
      case AttendanceStatus.onBreak:      return const Color(0xFFFFFBEB);
      case AttendanceStatus.punchedOut:   return const Color(0xFFFEF2F2);
    }
  }
}

class AttendanceSummary {
  final String punchIn;
  final String punchOut;
  final String breakTime;
  final String workHours;

  const AttendanceSummary({
    required this.punchIn,
    required this.punchOut,
    required this.breakTime,
    required this.workHours,
  });

  static const empty = AttendanceSummary(
    punchIn: '--:--',
    punchOut: '--:--',
    breakTime: '0 min',
    workHours: '0h 0m',
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PRODUCTIVITY
// ─────────────────────────────────────────────────────────────────────────────

class ProductivitySummary {
  final int assignedJobs;
  final int inProgress;
  final int completedToday;
  final double efficiency;
  final String avgTimePerJob;
  final String totalHoursWorked;

  const ProductivitySummary({
    required this.assignedJobs,
    required this.inProgress,
    required this.completedToday,
    required this.efficiency,
    required this.avgTimePerJob,
    required this.totalHoursWorked,
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// ASSIGNED JOB  (dashboard cards)
// ─────────────────────────────────────────────────────────────────────────────

enum AssignedJobStatus { inProgress, pending, waitingParts, completed }

extension AssignedJobStatusX on AssignedJobStatus {
  String get label {
    switch (this) {
      case AssignedJobStatus.inProgress:   return 'In Progress';
      case AssignedJobStatus.pending:      return 'Pending';
      case AssignedJobStatus.waitingParts: return 'Waiting Parts';
      case AssignedJobStatus.completed:    return 'Completed';
    }
  }

  Color get color {
    switch (this) {
      case AssignedJobStatus.inProgress:   return const Color(0xFF2563EB);
      case AssignedJobStatus.pending:      return const Color(0xFF6B7280);
      case AssignedJobStatus.waitingParts: return const Color(0xFFD97706);
      case AssignedJobStatus.completed:    return const Color(0xFF16A34A);
    }
  }

  Color get bgColor {
    switch (this) {
      case AssignedJobStatus.inProgress:   return const Color(0xFFEFF6FF);
      case AssignedJobStatus.pending:      return const Color(0xFFF3F4F6);
      case AssignedJobStatus.waitingParts: return const Color(0xFFFFFBEB);
      case AssignedJobStatus.completed:    return const Color(0xFFF0FDF4);
    }
  }

  String get actionLabel {
    switch (this) {
      case AssignedJobStatus.inProgress:   return 'In Progress';
      case AssignedJobStatus.pending:      return 'Start Job';
      case AssignedJobStatus.waitingParts: return 'On Hold';
      case AssignedJobStatus.completed:    return 'Complete';
    }
  }
}

class AssignedJob {
  final String id;
  final String customerName;
  final String vehicle;
  final String service;
  final double amount;
  AssignedJobStatus status;

  AssignedJob({
    required this.id,
    required this.customerName,
    required this.vehicle,
    required this.service,
    required this.amount,
    required this.status,
  });

  static List<AssignedJob> get mockData => [
    AssignedJob(
      id: 'JC-2024-1245',
      customerName: 'Ahmed Al Mansouri',
      vehicle: 'Toyota Camry - AA-12345',
      service: 'Engine Diagnostics',
      amount: 1.2,
      status: AssignedJobStatus.inProgress,
    ),
    AssignedJob(
      id: 'JC-2024-1246',
      customerName: 'Fatima Ali',
      vehicle: 'Honda Accord - BB-67890',
      service: 'Brake Pad Replacement',
      amount: 0,
      status: AssignedJobStatus.pending,
    ),
    AssignedJob(
      id: 'JC-2024-1247',
      customerName: 'Khalid Rashid',
      vehicle: 'Nissan Patrol - CC-11223',
      service: 'AC Repair',
      amount: 0,
      status: AssignedJobStatus.waitingParts,
    ),
    AssignedJob(
      id: 'JC-2024-1248',
      customerName: 'Mariam Salem',
      vehicle: 'BMW X5 - DD-44556',
      service: 'Full Service',
      amount: 0,
      status: AssignedJobStatus.completed,
    ),
  ];
}

// ─────────────────────────────────────────────────────────────────────────────
// EFFICIENCY PORTAL — Job detail models
// ─────────────────────────────────────────────────────────────────────────────

enum TechJobStatus { inProgress, completed, delayed, pending }

extension TechJobStatusX on TechJobStatus {
  String get label {
    switch (this) {
      case TechJobStatus.inProgress: return 'In Progress';
      case TechJobStatus.completed:  return 'Completed';
      case TechJobStatus.delayed:    return 'Delayed';
      case TechJobStatus.pending:    return 'Pending';
    }
  }

  Color get color {
    switch (this) {
      case TechJobStatus.inProgress: return const Color(0xFF1565C0);
      case TechJobStatus.completed:  return const Color(0xFF2E7D32);
      case TechJobStatus.delayed:    return const Color(0xFFC62828);
      case TechJobStatus.pending:    return const Color(0xFFF57F17);
    }
  }

  Color get bgColor {
    switch (this) {
      case TechJobStatus.inProgress: return const Color(0xFFE3F2FD);
      case TechJobStatus.completed:  return const Color(0xFFE8F5E9);
      case TechJobStatus.delayed:    return const Color(0xFFFFEBEE);
      case TechJobStatus.pending:    return const Color(0xFFFFF8E1);
    }
  }
}

enum TaskStatus { pending, inProgress, completed }

extension TaskStatusX on TaskStatus {
  String get label {
    switch (this) {
      case TaskStatus.pending:    return 'Pending';
      case TaskStatus.inProgress: return 'In Progress';
      case TaskStatus.completed:  return 'Completed';
    }
  }
}

class WorkTask {
  final int id;
  final String description;
  TaskStatus status;
  String? startTime;
  String? endTime;

  WorkTask({
    required this.id,
    required this.description,
    this.status = TaskStatus.pending,
    this.startTime,
    this.endTime,
  });

  WorkTask copyWith({
    TaskStatus? status,
    String? startTime,
    String? endTime,
  }) =>
      WorkTask(
        id: id,
        description: description,
        status: status ?? this.status,
        startTime: startTime ?? this.startTime,
        endTime: endTime ?? this.endTime,
      );
}

class TechJobModel {
  final String jobCardNo;
  final String dateOfWork;
  final String startTime;
  final String vehicleBrand;
  final String vehicleModel;
  final String plateNumber;
  TechJobStatus status;
  List<WorkTask> tasks;
  String notes;

  TechJobModel({
    required this.jobCardNo,
    required this.dateOfWork,
    required this.startTime,
    required this.vehicleBrand,
    required this.vehicleModel,
    required this.plateNumber,
    this.status = TechJobStatus.pending,
    required this.tasks,
    this.notes = '',
  });

  int get completedTasks =>
      tasks.where((t) => t.status == TaskStatus.completed).length;

  double get progressPercent =>
      tasks.isEmpty ? 0.0 : completedTasks / tasks.length;
}