// ─────────────────────────────────────────────────────────────────────────────
// dashboard_models.dart
// lib/features/dashboard/model/dashboard_models.dart
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';

class OwnerKpiModel {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  final String sub;

  const OwnerKpiModel({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
    required this.sub,
  });
}

class SalesTrendPoint {
  final String month;
  final double value;
  const SalesTrendPoint(this.month, this.value);
}

class TopSalesCategory {
  final String title;
  final List<TopSalesItem> items;
  bool isExpanded;

  TopSalesCategory({
    required this.title,
    required this.items,
    this.isExpanded = false,
  });
}

class TopSalesItem {
  final int sno;
  final String description;
  final String value;

  const TopSalesItem({
    required this.sno,
    required this.description,
    required this.value,
  });
}

class MessageModel {
  final String id;
  final String recipient;
  final String message;
  final String time;

  const MessageModel({
    required this.id,
    required this.recipient,
    required this.message,
    required this.time,
  });
}

class JobCardRegisterItem {
  final String label;
  final int open;
  final int completed;
  final int total;

  const JobCardRegisterItem({
    required this.label,
    required this.open,
    required this.completed,
    required this.total,
  });
}