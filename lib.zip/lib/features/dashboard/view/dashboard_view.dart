// ─────────────────────────────────────────────────────────────────────────────
// dashboard_view.dart
// lib/features/dashboard/view/dashboard_view.dart
// ─────────────────────────────────────────────────────────────────────────────
//
// Owner Dashboard — Professional Slate & Teal theme (light mode)
// Matches supervisor_dashboard_view.dart design language exactly.
//
// FIX: KPI cards "BOTTOM OVERFLOWED BY 6.1 PIXELS" resolved by:
//   - childAspectRatio: 1.55 → 1.35  (taller grid cells)
//   - Reduced _KpiCard internal padding, icon size, font size, spacing
//
// Screens included (all in one file):
//   1. DashboardView           — entry + ChangeNotifierProvider
//   2. _DashboardBody          — scaffold with AppBar + BottomNav
//   3. _DashboardPage          — main overview (KPIs, charts, register)
//   4. _TopSalesPage           — expandable accordion performance screen
//   5. _MessagesPage           — send message + recent messages
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:orientmobileapplication/features/dashboard/model/dashboard_model.dart';
import 'package:provider/provider.dart';

import '../viewmodel/dashboard_viewmodel.dart';

// ─────────────────────────────────────────────────────────────────────────────
// DESIGN TOKENS — identical palette to supervisor dashboard
// ─────────────────────────────────────────────────────────────────────────────

abstract class DC {
  // Brand core
  static const primary = Color(0xFF0F4C75);
  static const accent = Color(0xFF1B9AAA);
  static const accentLight = Color(0xFFE0F4F6);
  static const accentMid = Color(0xFFB2E0E5);

  // Surface
  static const scaffold = Color(0xFFF5F7FA);
  static const surface = Color(0xFFFFFFFF);
  static const surfaceAlt = Color(0xFFF0F3F7);
  static const border = Color(0xFFE2E8EF);

  // Text
  static const textH = Color(0xFF0A1628);
  static const textB = Color(0xFF253347);
  static const textM = Color(0xFF5C6E85);

  // Semantic
  static const green = Color(0xFF1A8754);
  static const greenBg = Color(0xFFEAF7EF);
  static const amber = Color(0xFFD97706);
  static const amberBg = Color(0xFFFFF8EC);
  static const red = Color(0xFFB91C1C);
  static const redBg = Color(0xFFFEECEC);
  static const purple = Color(0xFF6D28D9);
  static const purpleBg = Color(0xFFF0EAFC);

  // Gradient
  static const gStart = Color(0xFF0F4C75);
  static const gEnd = Color(0xFF1B9AAA);
}

// ─────────────────────────────────────────────────────────────────────────────
// ENTRY
// ─────────────────────────────────────────────────────────────────────────────

class DashboardView extends StatelessWidget {
  const DashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => DashboardViewModel(),
      child: const _DashboardBody(),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SCAFFOLD
// ─────────────────────────────────────────────────────────────────────────────

class _DashboardBody extends StatelessWidget {
  const _DashboardBody();

  static const _pages = <Widget>[
    _DashboardPage(),
    _TopSalesPage(),
    _MessagesPage(),
  ];

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<DashboardViewModel>();

    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: DC.primary,
        statusBarIconBrightness: Brightness.light,
      ),
    );

    return Scaffold(
      backgroundColor: DC.scaffold,
      appBar: _AppBar(vm: vm),
      body: IndexedStack(index: vm.selectedIndex, children: _pages),
      bottomNavigationBar: _BottomNav(
        selectedIndex: vm.selectedIndex,
        onTap: vm.selectTab,
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// APP BAR
// ─────────────────────────────────────────────────────────────────────────────

class _AppBar extends StatelessWidget implements PreferredSizeWidget {
  final DashboardViewModel vm;
  const _AppBar({required this.vm});

  static const _titles = ['Owner Dashboard', 'Top Sales', 'Messages'];
  static const _subtitles = [
    'Bircon, Hifri',
    'Performance Breakdown by Category',
    'Internal Messaging',
  ];

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight + 1);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      flexibleSpace: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [DC.gStart, DC.gEnd],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
        ),
      ),
      backgroundColor: Colors.transparent,
      elevation: 0,
      systemOverlayStyle: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
      ),
      titleSpacing: 0,
      leading: vm.selectedIndex == 0
          ? Padding(
              padding: const EdgeInsets.all(10),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.directions_car_rounded,
                  color: Colors.white,
                  size: 22,
                ),
              ),
            )
          : IconButton(
              icon: const Icon(
                Icons.arrow_back_ios_new_rounded,
                color: Colors.white,
                size: 20,
              ),
              onPressed: () => vm.selectTab(0),
            ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            _titles[vm.selectedIndex],
            style: GoogleFonts.rajdhani(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.5,
            ),
          ),
          Text(
            _subtitles[vm.selectedIndex],
            style: GoogleFonts.rajdhani(
              color: Colors.white70,
              fontSize: 12,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.4,
            ),
          ),
        ],
      ),
      actions: [
        // period filter only on dashboard
        if (vm.selectedIndex == 0)
          Padding(
            padding: const EdgeInsets.only(right: 6),
            child: _PeriodDropdown(vm: vm),
          ),
        // Notification bell
        Stack(
          clipBehavior: Clip.none,
          children: [
            IconButton(
              icon: const Icon(
                Icons.notifications_outlined,
                color: Colors.white,
                size: 26,
              ),
              onPressed: () {},
            ),
            Positioned(
              right: 10,
              top: 10,
              child: Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: const Color(0xFFFBBF24),
                  shape: BoxShape.circle,
                  border: Border.all(color: DC.gStart, width: 1.5),
                ),
              ),
            ),
          ],
        ),
        // Avatar
        Padding(
          padding: const EdgeInsets.only(right: 14),
          child: GestureDetector(
            onTap: () => _showProfile(context),
            child: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.20),
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.white.withOpacity(0.5),
                  width: 1.5,
                ),
              ),
              child: const Center(
                child: Text(
                  'O',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(height: 1, color: Colors.white.withOpacity(0.12)),
      ),
    );
  }

  void _showProfile(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: DC.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: DC.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 24),
            Container(
              width: 68,
              height: 68,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [DC.gStart, DC.gEnd],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
              ),
              child: const Center(
                child: Text(
                  'O',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 14),
            const Text(
              'Owner',
              style: TextStyle(
                color: DC.textH,
                fontSize: 19,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.3,
              ),
            ),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: DC.accentLight,
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Text(
                'Admin • Auto Garage ERP',
                style: TextStyle(
                  color: DC.accent,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 28),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: OutlinedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.of(context).pop();
                },
                style: OutlinedButton.styleFrom(
                  foregroundColor: DC.red,
                  side: const BorderSide(color: DC.red, width: 1.5),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                icon: const Icon(Icons.logout_rounded, size: 18),
                label: const Text(
                  'Logout',
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Period Dropdown ────────────────────────────────────────────────────────

class _PeriodDropdown extends StatelessWidget {
  final DashboardViewModel vm;
  const _PeriodDropdown({required this.vm});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 32,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.3)),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: vm.period,
          dropdownColor: DC.primary,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 11,
            fontWeight: FontWeight.w600,
          ),
          icon: const Icon(
            Icons.keyboard_arrow_down_rounded,
            color: Colors.white,
            size: 16,
          ),
          isDense: true,
          onChanged: (v) => vm.setPeriod(v ?? vm.period),
          items: vm.periods
              .map(
                (p) => DropdownMenuItem(
                  value: p,
                  child: Text(
                    p,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              )
              .toList(),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// BOTTOM NAV
// ─────────────────────────────────────────────────────────────────────────────

class _BottomNav extends StatelessWidget {
  final int selectedIndex;
  final void Function(int) onTap;
  const _BottomNav({required this.selectedIndex, required this.onTap});

  @override
  Widget build(BuildContext context) {
    const items = [
      (Icons.dashboard_rounded, Icons.dashboard_outlined, 'Dashboard'),
      (Icons.leaderboard_rounded, Icons.leaderboard_outlined, 'Top Sales'),
      (
        Icons.chat_bubble_rounded,
        Icons.chat_bubble_outline_rounded,
        'Messages',
      ),
    ];

    return Container(
      decoration: BoxDecoration(
        color: DC.surface,
        border: const Border(top: BorderSide(color: DC.border)),
        boxShadow: [
          BoxShadow(
            color: DC.primary.withOpacity(0.07),
            blurRadius: 16,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 74,
          child: Row(
            children: List.generate(items.length, (i) {
              final sel = selectedIndex == i;
              return Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => onTap(i),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 220),
                        curve: Curves.easeOutCubic,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: sel ? DC.accentLight : Colors.transparent,
                          borderRadius: BorderRadius.circular(24),
                        ),
                        child: Icon(
                          sel ? items[i].$1 : items[i].$2,
                          color: sel ? DC.accent : DC.textM,
                          size: 26,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        items[i].$3,
                        style: TextStyle(
                          fontSize: 11,
                          color: sel ? DC.accent : DC.textM,
                          fontWeight: sel ? FontWeight.w800 : FontWeight.w500,
                          letterSpacing: sel ? 0.2 : 0,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE 1 — DASHBOARD
// ─────────────────────────────────────────────────────────────────────────────

class _DashboardPage extends StatelessWidget {
  const _DashboardPage();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<DashboardViewModel>();

    if (vm.isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: DC.accent, strokeWidth: 2.5),
      );
    }

    return RefreshIndicator(
      onRefresh: vm.refresh,
      color: DC.accent,
      strokeWidth: 2.5,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _HeaderBanner(vm: vm),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 22, 16, 32),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _sectionLabel('KPI Overview'),
                  const SizedBox(height: 12),
                  _KpiGrid(kpis: vm.kpis),
                  const SizedBox(height: 26),

                  _sectionLabel('Job Card Register'),
                  const SizedBox(height: 12),
                  _JobCardRegisterCard(items: vm.registerItems),
                  const SizedBox(height: 26),

                  _sectionLabel('Analytics'),
                  const SizedBox(height: 12),
                  _SalesTrendCard(
                    salesData: vm.salesTrend,
                    profitData: vm.profitTrend,
                  ),
                  const SizedBox(height: 12),
                  _SalesVsExpensesCard(
                    salesData: vm.salesTrend,
                    expenseData: vm.expensesTrend,
                  ),
                  const SizedBox(height: 26),

                  // Quick action buttons
                  _sectionLabel('Quick Actions'),
                  const SizedBox(height: 12),
                  _QuickActionsRow(vm: vm),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionLabel(String text) => Row(
    children: [
      Container(
        width: 4,
        height: 20,
        decoration: BoxDecoration(
          color: DC.accent,
          borderRadius: BorderRadius.circular(2),
        ),
      ),
      const SizedBox(width: 10),
      Text(
        text,
        style: GoogleFonts.rajdhani(
          color: DC.textH,
          fontSize: 19,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.5,
        ),
      ),
    ],
  );
}

// ── Header Banner ──────────────────────────────────────────────────────────

class _HeaderBanner extends StatelessWidget {
  final DashboardViewModel vm;
  const _HeaderBanner({required this.vm});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 22, 20, 26),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [DC.gStart, DC.gEnd],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(32)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      margin: const EdgeInsets.only(right: 6, top: 1),
                      decoration: const BoxDecoration(
                        color: Color(0xFF4ADEDF),
                        shape: BoxShape.circle,
                      ),
                    ),
                    const Text(
                      'Live',
                      style: TextStyle(
                        color: Color(0xFF4ADEDF),
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                const Text(
                  'Good Morning,',
                  style: TextStyle(color: Colors.white70, fontSize: 14),
                ),
                Text(
                  'Owner Dashboard',
                  style: GoogleFonts.orbitron(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    height: 1.2,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    _pill(
                      Icons.work_outline_rounded,
                      '145 Active',
                      const Color(0xFFFBBF24),
                    ),
                    const SizedBox(width: 8),
                    _pill(
                      Icons.check_circle_outline_rounded,
                      '23 New',
                      const Color(0xFF4ADEDF),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            width: 68,
            height: 68,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.14),
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.white.withOpacity(0.25),
                width: 1.5,
              ),
            ),
            child: const Icon(
              Icons.business_center_rounded,
              color: Colors.white,
              size: 32,
            ),
          ),
        ],
      ),
    );
  }

  Widget _pill(IconData icon, String label, Color accent) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: accent.withOpacity(0.4), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: accent, size: 14),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

// ── KPI Grid — 2-column wrap ──────────────────────────────────────────────
// FIX: childAspectRatio changed from 1.55 → 1.35 to give cards enough height
// to render icon row + value + label + padding without overflowing.

class _KpiGrid extends StatelessWidget {
  final List<OwnerKpiModel> kpis;
  const _KpiGrid({required this.kpis});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 1.35, // FIX: was 1.55 — taller cells prevent overflow
      ),
      itemCount: kpis.length,
      itemBuilder: (_, i) => _KpiCard(kpi: kpis[i]),
    );
  }
}

// FIX: Reduced padding (14→12/10), icon container (36x28→32x26), icon size
// (18→16), value font (16→15), spacing (8→6, 3→2) to fit within taller cells.
class _KpiCard extends StatelessWidget {
  final OwnerKpiModel kpi;
  const _KpiCard({required this.kpi});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(
        12,
        12,
        12,
        10,
      ), // FIX: was (14,14,14,12)
      decoration: BoxDecoration(
        color: DC.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: DC.border),
        boxShadow: [
          BoxShadow(
            color: DC.primary.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Container(
                width: 32, // FIX: was 36
                height: 26, // FIX: was 28
                decoration: BoxDecoration(
                  color: kpi.color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  kpi.icon,
                  color: kpi.color,
                  size: 16,
                ), // FIX: was 18
              ),
              const Spacer(),
              Flexible(
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 6, // FIX: was 7
                    vertical: 2, // FIX: was 3
                  ),
                  decoration: BoxDecoration(
                    color: DC.greenBg,
                    borderRadius: BorderRadius.circular(7),
                  ),
                  child: Text(
                    kpi.sub,
                    style: const TextStyle(
                      color: DC.green,
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6), // FIX: was 8
          Text(
            kpi.value,
            style: GoogleFonts.orbitron(
              color: DC.textH,
              fontSize: 15, // FIX: was 16
              fontWeight: FontWeight.w800,
              letterSpacing: -0.3,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 2), // FIX: was 3
          Text(
            kpi.label,
            style: GoogleFonts.rajdhani(
              color: DC.textM,
              fontSize: 12, // FIX: was 12.5
              fontWeight: FontWeight.w700,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

// ── Job Card Register ─────────────────────────────────────────────────────

class _JobCardRegisterCard extends StatelessWidget {
  final List<JobCardRegisterItem> items;
  const _JobCardRegisterCard({required this.items});

  @override
  Widget build(BuildContext context) {
    return _SurfaceCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _CardTitle('Job Card Register'),
          const SizedBox(height: 16),
          // Table header
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              color: DC.accentLight,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              children: [
                Expanded(
                  flex: 3,
                  child: Text(
                    'Category',
                    style: GoogleFonts.rajdhani(
                      color: DC.accent,
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: Text(
                    'Open',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.rajdhani(
                      color: DC.accent,
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: Text(
                    'Total',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.rajdhani(
                      color: DC.accent,
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          ...items.asMap().entries.map((e) {
            final i = e.key;
            final item = e.value;
            return Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              decoration: BoxDecoration(
                color: i.isEven ? DC.surfaceAlt : DC.surface,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Expanded(
                    flex: 3,
                    child: Text(
                      item.label,
                      style: const TextStyle(
                        color: DC.textB,
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      '${item.open}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: DC.accent,
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      '${item.total}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: DC.textH,
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}

// ── Sales Trend Card ──────────────────────────────────────────────────────

class _SalesTrendCard extends StatelessWidget {
  final List<SalesTrendPoint> salesData;
  final List<SalesTrendPoint> profitData;
  const _SalesTrendCard({required this.salesData, required this.profitData});

  @override
  Widget build(BuildContext context) {
    return _SurfaceCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const _CardTitle('Sales Trend'),
              const Spacer(),
              _chip(DC.accent, DC.accentLight, 'Sales'),
              const SizedBox(width: 6),
              _chip(DC.green, DC.greenBg, 'Profit'),
            ],
          ),
          const SizedBox(height: 18),
          SizedBox(
            height: 140,
            child: CustomPaint(
              size: Size.infinite,
              painter: _DualLinePainter(
                primaryData: salesData,
                secondaryData: profitData,
                primaryColor: DC.accent,
                secondaryColor: DC.green,
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: salesData
                .map(
                  (p) => Text(
                    p.month,
                    style: const TextStyle(
                      color: DC.textM,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                )
                .toList(),
          ),
        ],
      ),
    );
  }

  Widget _chip(Color color, Color bg, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 10,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _SalesVsExpensesCard extends StatelessWidget {
  final List<SalesTrendPoint> salesData;
  final List<SalesTrendPoint> expenseData;
  const _SalesVsExpensesCard({
    required this.salesData,
    required this.expenseData,
  });

  @override
  Widget build(BuildContext context) {
    return _SurfaceCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const _CardTitle('Sales vs Expenses'),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: DC.accentLight,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text(
                  'This Year',
                  style: TextStyle(
                    color: DC.accent,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          SizedBox(
            height: 160,
            child: CustomPaint(
              size: Size.infinite,
              painter: _BarChartPainter(
                salesData: salesData,
                expenseData: expenseData,
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _legend(DC.accent, 'Sales'),
              const SizedBox(width: 16),
              _legend(DC.amber, 'Expenses'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _legend(Color color, String label) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Container(
        width: 12,
        height: 12,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(3),
        ),
      ),
      const SizedBox(width: 5),
      Text(
        label,
        style: const TextStyle(
          color: DC.textM,
          fontSize: 11,
          fontWeight: FontWeight.w600,
        ),
      ),
    ],
  );
}

// ── Quick Actions Row ─────────────────────────────────────────────────────

class _QuickActionsRow extends StatelessWidget {
  final DashboardViewModel vm;
  const _QuickActionsRow({required this.vm});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _ActionButton(
            icon: Icons.leaderboard_rounded,
            label: 'View Details',
            gradient: const [DC.gStart, DC.gEnd],
            onTap: () => vm.selectTab(1),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _ActionButton(
            icon: Icons.send_rounded,
            label: 'Send Message',
            gradient: const [Color(0xFF1A8754), Color(0xFF2DD4BF)],
            onTap: () => vm.selectTab(2),
          ),
        ),
      ],
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final List<Color> gradient;
  final VoidCallback onTap;
  const _ActionButton({
    required this.icon,
    required this.label,
    required this.gradient,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: gradient),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: gradient.first.withOpacity(0.30),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 18),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE 2 — TOP SALES PERFORMANCE
// ─────────────────────────────────────────────────────────────────────────────

class _TopSalesPage extends StatelessWidget {
  const _TopSalesPage();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<DashboardViewModel>();

    return Column(
      children: [
        // Sub-header
        Container(
          color: DC.surface,
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
          child: Row(
            children: [
              const Icon(Icons.category_rounded, color: DC.accent, size: 18),
              const SizedBox(width: 8),
              Text(
                '${vm.topSalesCategories.length} Categories',
                style: const TextStyle(
                  color: DC.textB,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
        const Divider(height: 1, color: DC.border),
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
            itemCount: vm.topSalesCategories.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (_, i) {
              final cat = vm.topSalesCategories[i];
              return _SalesCategoryCard(
                category: cat,
                onToggle: () => vm.toggleCategory(i),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _SalesCategoryCard extends StatelessWidget {
  final TopSalesCategory category;
  final VoidCallback onToggle;
  const _SalesCategoryCard({required this.category, required this.onToggle});

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        color: DC.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: category.isExpanded ? DC.accent.withOpacity(0.35) : DC.border,
          width: category.isExpanded ? 1.5 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: DC.primary.withOpacity(0.06),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          // Header row
          InkWell(
            onTap: onToggle,
            borderRadius: BorderRadius.circular(16),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
              decoration: BoxDecoration(
                color: category.isExpanded ? DC.accentLight : DC.surfaceAlt,
                borderRadius: category.isExpanded
                    ? const BorderRadius.vertical(top: Radius.circular(15))
                    : BorderRadius.circular(15),
              ),
              child: Row(
                children: [
                  Text(
                    category.title.toUpperCase(),
                    style: GoogleFonts.rajdhani(
                      color: category.isExpanded ? DC.accent : DC.textH,
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.8,
                    ),
                  ),
                  const Spacer(),
                  AnimatedRotation(
                    turns: category.isExpanded ? 0.5 : 0,
                    duration: const Duration(milliseconds: 200),
                    child: Icon(
                      Icons.keyboard_arrow_down_rounded,
                      color: category.isExpanded ? DC.accent : DC.textM,
                      size: 22,
                    ),
                  ),
                ],
              ),
            ),
          ),
          // Expanded content
          if (category.isExpanded) ...[
            // Table header
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
              color: DC.surfaceAlt,
              child: Row(
                children: [
                  SizedBox(
                    width: 40,
                    child: Text(
                      'S.NO',
                      style: GoogleFonts.rajdhani(
                        color: DC.textM,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      'DESCRIPTION',
                      style: GoogleFonts.rajdhani(
                        color: DC.textM,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                  Text(
                    'VALUE',
                    style: GoogleFonts.rajdhani(
                      color: DC.textM,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
            const Divider(height: 1, color: DC.border),
            ...category.items.asMap().entries.map((e) {
              final i = e.key;
              final item = e.value;
              return Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 13,
                ),
                decoration: BoxDecoration(
                  color: i.isEven ? DC.surface : DC.surfaceAlt,
                  borderRadius: i == category.items.length - 1
                      ? const BorderRadius.vertical(bottom: Radius.circular(15))
                      : BorderRadius.zero,
                ),
                child: Row(
                  children: [
                    SizedBox(
                      width: 40,
                      child: Text(
                        '${item.sno}',
                        style: const TextStyle(
                          color: DC.textM,
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Text(
                        item.description,
                        style: const TextStyle(
                          color: DC.textB,
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Text(
                      item.value,
                      style: GoogleFonts.orbitron(
                        color: DC.green,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        letterSpacing: -0.3,
                      ),
                    ),
                  ],
                ),
              );
            }),
          ],
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE 3 — MESSAGES
// ─────────────────────────────────────────────────────────────────────────────

class _MessagesPage extends StatelessWidget {
  const _MessagesPage();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<DashboardViewModel>();
    final msgController = TextEditingController(text: vm.messageText);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Sent messages count
          Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: DC.accentLight,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    '${vm.sentMessages.length} Sent Messages',
                    style: const TextStyle(
                      color: DC.accent,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Send message card
          _SurfaceCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'SEND NEW MESSAGE',
                  style: GoogleFonts.rajdhani(
                    color: DC.textM,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.0,
                  ),
                ),
                const SizedBox(height: 14),
                // User selector
                _FormLabel('SELECT USER'),
                const SizedBox(height: 7),
                Container(
                  height: 50,
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  decoration: BoxDecoration(
                    color: DC.scaffold,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: DC.border),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: vm.selectedUser.isEmpty ? null : vm.selectedUser,
                      hint: Row(
                        children: [
                          const Icon(
                            Icons.person_outline_rounded,
                            color: DC.textM,
                            size: 18,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'Choose a user...',
                            style: const TextStyle(
                              color: DC.textM,
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                      dropdownColor: DC.surface,
                      style: const TextStyle(color: DC.textH, fontSize: 13),
                      icon: const Icon(
                        Icons.keyboard_arrow_down_rounded,
                        color: DC.textM,
                        size: 18,
                      ),
                      isExpanded: true,
                      onChanged: (v) => vm.selectUser(v ?? ''),
                      items: vm.users
                          .map(
                            (u) => DropdownMenuItem(value: u, child: Text(u)),
                          )
                          .toList(),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                // Message field
                _FormLabel('MESSAGE'),
                const SizedBox(height: 7),
                TextField(
                  controller: msgController,
                  onChanged: vm.updateMessage,
                  maxLines: 5,
                  style: const TextStyle(color: DC.textH, fontSize: 13),
                  decoration: InputDecoration(
                    hintText: 'Type your message here...',
                    hintStyle: const TextStyle(color: DC.textM, fontSize: 13),
                    filled: true,
                    fillColor: DC.scaffold,
                    contentPadding: const EdgeInsets.all(14),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: DC.border),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: DC.border),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(
                        color: DC.accent,
                        width: 1.5,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                // Gradient send button
                GestureDetector(
                  onTap: () {
                    vm.sendMessage();
                    msgController.clear();
                  },
                  child: Container(
                    width: double.infinity,
                    height: 50,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [DC.gStart, DC.gEnd],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(
                          color: DC.accent.withOpacity(0.30),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          Icons.send_rounded,
                          color: Colors.white,
                          size: 18,
                        ),
                        const SizedBox(width: 10),
                        Text(
                          'SEND MESSAGE',
                          style: GoogleFonts.rajdhani(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1.0,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Recent messages
          if (vm.sentMessages.isNotEmpty) ...[
            const SizedBox(height: 24),
            Row(
              children: [
                Container(
                  width: 4,
                  height: 20,
                  decoration: BoxDecoration(
                    color: DC.accent,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  'RECENT MESSAGES',
                  style: GoogleFonts.rajdhani(
                    color: DC.textH,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.8,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ...vm.sentMessages.map(
              (msg) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _MessageTile(message: msg),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _MessageTile extends StatelessWidget {
  final MessageModel message;
  const _MessageTile({required this.message});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: DC.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: DC.border),
        boxShadow: [
          BoxShadow(
            color: DC.primary.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [DC.gStart, DC.gEnd],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                message.recipient[0],
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      message.recipient,
                      style: const TextStyle(
                        color: DC.textH,
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      message.time,
                      style: const TextStyle(
                        color: DC.textM,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  message.message,
                  style: const TextStyle(
                    color: DC.textM,
                    fontSize: 12,
                    height: 1.4,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// CUSTOM PAINTERS
// ─────────────────────────────────────────────────────────────────────────────

class _DualLinePainter extends CustomPainter {
  final List<SalesTrendPoint> primaryData;
  final List<SalesTrendPoint> secondaryData;
  final Color primaryColor;
  final Color secondaryColor;

  const _DualLinePainter({
    required this.primaryData,
    required this.secondaryData,
    required this.primaryColor,
    required this.secondaryColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final allValues = [
      ...primaryData.map((d) => d.value),
      ...secondaryData.map((d) => d.value),
    ];
    final maxVal = allValues.reduce(math.max);
    final minVal = allValues.reduce(math.min);
    final range = maxVal - minVal == 0 ? 1.0 : maxVal - minVal;

    void drawLine(List<SalesTrendPoint> data, Color color) {
      final path = Path();
      final fill = Path();

      for (var i = 0; i < data.length; i++) {
        final x = size.width * i / (data.length - 1);
        final y = size.height * (1 - (data[i].value - minVal) / range);
        if (i == 0) {
          path.moveTo(x, y);
          fill.moveTo(x, y);
        } else {
          path.lineTo(x, y);
          fill.lineTo(x, y);
        }
      }
      fill
        ..lineTo(size.width, size.height)
        ..lineTo(0, size.height)
        ..close();

      canvas.drawPath(
        fill,
        Paint()
          ..shader = LinearGradient(
            colors: [color.withOpacity(0.18), color.withOpacity(0.0)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
          ..style = PaintingStyle.fill,
      );

      canvas.drawPath(
        path,
        Paint()
          ..color = color
          ..strokeWidth = 2.5
          ..style = PaintingStyle.stroke
          ..strokeCap = StrokeCap.round
          ..strokeJoin = StrokeJoin.round,
      );

      // Dots
      for (var i = 0; i < data.length; i++) {
        final x = size.width * i / (data.length - 1);
        final y = size.height * (1 - (data[i].value - minVal) / range);
        canvas.drawCircle(Offset(x, y), 4.5, Paint()..color = color);
        canvas.drawCircle(Offset(x, y), 2.5, Paint()..color = Colors.white);
      }
    }

    drawLine(secondaryData, secondaryColor);
    drawLine(primaryData, primaryColor);
  }

  @override
  bool shouldRepaint(_) => false;
}

class _BarChartPainter extends CustomPainter {
  final List<SalesTrendPoint> salesData;
  final List<SalesTrendPoint> expenseData;

  const _BarChartPainter({required this.salesData, required this.expenseData});

  @override
  void paint(Canvas canvas, Size size) {
    final allValues = [
      ...salesData.map((d) => d.value),
      ...expenseData.map((d) => d.value),
    ];
    final maxVal = allValues.reduce(math.max);
    final count = salesData.length;
    final groupW = size.width / count;
    final barW = groupW * 0.33;
    const gap = 4.0;
    const bottomPad = 20.0;
    final chartH = size.height - bottomPad;

    for (var i = 0; i < count; i++) {
      final gx = groupW * i + groupW / 2;

      // Sales bar
      final sh = chartH * salesData[i].value / maxVal;
      final sRect = RRect.fromRectAndRadius(
        Rect.fromLTWH(gx - barW - gap / 2, chartH - sh, barW, sh),
        const Radius.circular(5),
      );
      canvas.drawRRect(
        sRect,
        Paint()
          ..shader = const LinearGradient(
            colors: [DC.gEnd, DC.gStart],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ).createShader(Rect.fromLTWH(0, 0, barW, sh)),
      );

      // Expense bar
      final eh = chartH * expenseData[i].value / maxVal;
      final eRect = RRect.fromRectAndRadius(
        Rect.fromLTWH(gx + gap / 2, chartH - eh, barW, eh),
        const Radius.circular(5),
      );
      canvas.drawRRect(
        eRect,
        Paint()
          ..shader = LinearGradient(
            colors: [DC.amber.withOpacity(0.9), DC.amber.withOpacity(0.5)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ).createShader(Rect.fromLTWH(0, 0, barW, eh)),
      );

      // Month label
      final tp = TextPainter(
        text: TextSpan(
          text: salesData[i].month,
          style: const TextStyle(color: DC.textM, fontSize: 10),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(gx - tp.width / 2, size.height - tp.height));
    }
  }

  @override
  bool shouldRepaint(_) => false;
}

// ─────────────────────────────────────────────────────────────────────────────
// SHARED SMALL WIDGETS
// ─────────────────────────────────────────────────────────────────────────────

class _SurfaceCard extends StatelessWidget {
  final Widget child;
  const _SurfaceCard({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: DC.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: DC.border),
        boxShadow: [
          BoxShadow(
            color: DC.primary.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: child,
    );
  }
}

class _CardTitle extends StatelessWidget {
  final String text;
  const _CardTitle(this.text);

  @override
  Widget build(BuildContext context) => Text(
    text,
    style: GoogleFonts.rajdhani(
      color: DC.textH,
      fontSize: 16,
      fontWeight: FontWeight.w700,
      letterSpacing: 0.3,
    ),
  );
}

class _FormLabel extends StatelessWidget {
  final String text;
  const _FormLabel(this.text);

  @override
  Widget build(BuildContext context) => Text(
    text,
    style: GoogleFonts.rajdhani(
      color: DC.textM,
      fontSize: 11,
      fontWeight: FontWeight.w800,
      letterSpacing: 0.8,
    ),
  );
}
