// ─────────────────────────────────────────────────────────────────────────────
// dashboard_viewmodel.dart
// lib/features/dashboard/viewmodel/dashboard_viewmodel.dart
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:orientmobileapplication/features/dashboard/model/dashboard_model.dart';

class DashboardViewModel extends ChangeNotifier {
  // ── Tab state ────────────────────────────────────────────────────────────
  int _selectedIndex = 0;
  int get selectedIndex => _selectedIndex;

  void selectTab(int i) {
    _selectedIndex = i;
    notifyListeners();
  }

  // ── Period filter ────────────────────────────────────────────────────────
  String _period = 'This Week';
  String get period => _period;
  final List<String> periods = ['Today', 'This Week', 'This Month', 'This Year'];

  void setPeriod(String p) {
    _period = p;
    notifyListeners();
  }

  // ── Loading ───────────────────────────────────────────────────────────────
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  Future<void> refresh() async {
    _isLoading = true;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 900));
    _isLoading = false;
    notifyListeners();
  }

  // ── KPI Cards ─────────────────────────────────────────────────────────────
  List<OwnerKpiModel> get kpis => [
        const OwnerKpiModel(
          label: 'Active Jobs',
          value: '145',
          icon: Icons.work_outline_rounded,
          color: Color(0xFF1B9AAA),
          sub: '+12 today',
        ),
        const OwnerKpiModel(
          label: 'New Jobs',
          value: '23',
          icon: Icons.add_circle_outline_rounded,
          color: Color(0xFF1A8754),
          sub: '+5 today',
        ),
        const OwnerKpiModel(
          label: 'Cancelled Jobs',
          value: '100',
          icon: Icons.cancel_outlined,
          color: Color(0xFFB91C1C),
          sub: '-2 today',
        ),
        const OwnerKpiModel(
          label: 'Total Jobs',
          value: '2,168',
          icon: Icons.receipt_long_rounded,
          color: Color(0xFF6D28D9),
          sub: 'All time',
        ),
        const OwnerKpiModel(
          label: 'Total Sales',
          value: 'AED 50K',
          icon: Icons.trending_up_rounded,
          color: Color(0xFF1B9AAA),
          sub: '+8%',
        ),
        const OwnerKpiModel(
          label: 'Total Purchases',
          value: 'AED 30K',
          icon: Icons.shopping_cart_outlined,
          color: Color(0xFFD97706),
          sub: '+3%',
        ),
        const OwnerKpiModel(
          label: 'Receivables',
          value: 'AED 4K',
          icon: Icons.account_balance_wallet_outlined,
          color: Color(0xFF1A8754),
          sub: '12 pending',
        ),
        const OwnerKpiModel(
          label: 'Payables',
          value: 'AED 15K',
          icon: Icons.payments_outlined,
          color: Color(0xFFB91C1C),
          sub: '8 due',
        ),
        const OwnerKpiModel(
          label: 'Total Profit',
          value: 'AED 20K',
          icon: Icons.bar_chart_rounded,
          color: Color(0xFF1A8754),
          sub: '+14%',
        ),
        const OwnerKpiModel(
          label: 'Total Cash',
          value: 'AED 45K',
          icon: Icons.attach_money_rounded,
          color: Color(0xFF1B9AAA),
          sub: 'In hand',
        ),
        const OwnerKpiModel(
          label: 'Total Bank',
          value: 'AED 30K',
          icon: Icons.account_balance_outlined,
          color: Color(0xFF6D28D9),
          sub: 'Balance',
        ),
        const OwnerKpiModel(
          label: 'Inventory Value',
          value: 'AED 85K',
          icon: Icons.inventory_2_outlined,
          color: Color(0xFFD97706),
          sub: '1,240 items',
        ),
        const OwnerKpiModel(
          label: 'Commission',
          value: 'AED 1,500',
          icon: Icons.star_outline_rounded,
          color: Color(0xFF1A8754),
          sub: 'Monthly',
        ),
        const OwnerKpiModel(
          label: 'Invoice Revenue',
          value: 'AED 25K',
          icon: Icons.description_outlined,
          color: Color(0xFF1B9AAA),
          sub: '+6%',
        ),
        const OwnerKpiModel(
          label: 'Parts Revenue',
          value: 'AED 18K',
          icon: Icons.build_outlined,
          color: Color(0xFFD97706),
          sub: '+9%',
        ),
        const OwnerKpiModel(
          label: 'Labour Revenue',
          value: 'AED 7K',
          icon: Icons.engineering_outlined,
          color: Color(0xFF6D28D9),
          sub: '+4%',
        ),
      ];

  // ── Job Card Register ─────────────────────────────────────────────────────
  List<JobCardRegisterItem> get registerItems => [
        const JobCardRegisterItem(label: 'Open', open: 40, completed: 0, total: 40),
        const JobCardRegisterItem(label: 'Check-In', open: 100, completed: 0, total: 100),
        const JobCardRegisterItem(label: 'Invoice Number', open: 10, completed: 0, total: 10),
        const JobCardRegisterItem(label: 'Invoice Service', open: 2000, completed: 0, total: 2000),
        const JobCardRegisterItem(label: 'Park Fee', open: 2000, completed: 0, total: 2000),
      ];

  // ── Sales trend data ──────────────────────────────────────────────────────
  List<SalesTrendPoint> get salesTrend => [
        const SalesTrendPoint('Jan', 28000),
        const SalesTrendPoint('Feb', 35000),
        const SalesTrendPoint('Mar', 30000),
        const SalesTrendPoint('Apr', 42000),
        const SalesTrendPoint('May', 38000),
        const SalesTrendPoint('Jun', 50000),
        const SalesTrendPoint('Jul', 45000),
      ];

  List<SalesTrendPoint> get profitTrend => [
        const SalesTrendPoint('Jan', 8000),
        const SalesTrendPoint('Feb', 12000),
        const SalesTrendPoint('Mar', 10000),
        const SalesTrendPoint('Apr', 16000),
        const SalesTrendPoint('May', 14000),
        const SalesTrendPoint('Jun', 20000),
        const SalesTrendPoint('Jul', 18000),
      ];

  List<SalesTrendPoint> get expensesTrend => [
        const SalesTrendPoint('Jan', 20000),
        const SalesTrendPoint('Feb', 23000),
        const SalesTrendPoint('Mar', 20000),
        const SalesTrendPoint('Apr', 26000),
        const SalesTrendPoint('May', 24000),
        const SalesTrendPoint('Jun', 30000),
        const SalesTrendPoint('Jul', 27000),
      ];

  // ── Top Sales Categories ─────────────────────────────────────────────────
  final List<TopSalesCategory> topSalesCategories = [
    TopSalesCategory(
      title: 'Customer Wise',
      items: [
        const TopSalesItem(sno: 1, description: 'Ahmed Al Mansoori', value: 'AED 45,600'),
        const TopSalesItem(sno: 2, description: 'Mohammed Khan', value: 'AED 38,500'),
        const TopSalesItem(sno: 3, description: 'Fatima Hassan', value: 'AED 32,100'),
        const TopSalesItem(sno: 4, description: 'Ali Rashid', value: 'AED 28,900'),
        const TopSalesItem(sno: 5, description: 'Sarah Abdullah', value: 'AED 25,600'),
      ],
    ),
    TopSalesCategory(
      title: 'Brand / Model Wise',
      items: [
        const TopSalesItem(sno: 1, description: 'Toyota Land Cruiser', value: 'AED 52,000'),
        const TopSalesItem(sno: 2, description: 'Mercedes S-Class', value: 'AED 48,300'),
        const TopSalesItem(sno: 3, description: 'BMW X5', value: 'AED 41,200'),
        const TopSalesItem(sno: 4, description: 'Nissan Patrol', value: 'AED 35,800'),
        const TopSalesItem(sno: 5, description: 'Audi Q7', value: 'AED 30,500'),
      ],
    ),
    TopSalesCategory(
      title: 'Advisor Wise',
      items: [
        const TopSalesItem(sno: 1, description: 'Ahmed Service Advisor', value: 'AED 95,800'),
        const TopSalesItem(sno: 2, description: 'Mohammed Service Advisor', value: 'AED 82,400'),
        const TopSalesItem(sno: 3, description: 'Ali Service Advisor', value: 'AED 67,200'),
        const TopSalesItem(sno: 4, description: 'Hassan Service Advisor', value: 'AED 54,300'),
        const TopSalesItem(sno: 5, description: 'Omar Service Advisor', value: 'AED 48,100'),
      ],
    ),
    TopSalesCategory(
      title: 'Profit Wise',
      items: [
        const TopSalesItem(sno: 1, description: 'Q2 2025', value: 'AED 62,000'),
        const TopSalesItem(sno: 2, description: 'Q1 2025', value: 'AED 54,500'),
        const TopSalesItem(sno: 3, description: 'Q3 2024', value: 'AED 48,200'),
        const TopSalesItem(sno: 4, description: 'Q4 2024', value: 'AED 44,800'),
        const TopSalesItem(sno: 5, description: 'Q2 2024', value: 'AED 38,600'),
      ],
    ),
    TopSalesCategory(
      title: 'Sales Value Wise',
      items: [
        const TopSalesItem(sno: 1, description: 'INV-2025-143', value: 'AED 28,750'),
        const TopSalesItem(sno: 2, description: 'INV-2025-138', value: 'AED 25,200'),
        const TopSalesItem(sno: 3, description: 'INV-2025-129', value: 'AED 22,100'),
        const TopSalesItem(sno: 4, description: 'INV-2025-120', value: 'AED 19,800'),
        const TopSalesItem(sno: 5, description: 'INV-2025-112', value: 'AED 17,500'),
      ],
    ),
    TopSalesCategory(
      title: 'Spare Parts Profit Wise',
      items: [
        const TopSalesItem(sno: 1, description: 'Engine Parts', value: 'AED 15,400'),
        const TopSalesItem(sno: 2, description: 'Brake System', value: 'AED 12,200'),
        const TopSalesItem(sno: 3, description: 'Suspension Parts', value: 'AED 10,800'),
        const TopSalesItem(sno: 4, description: 'Electrical Components', value: 'AED 9,500'),
        const TopSalesItem(sno: 5, description: 'Body Parts', value: 'AED 8,300'),
      ],
    ),
    TopSalesCategory(
      title: 'Labour Profit Wise',
      items: [
        const TopSalesItem(sno: 1, description: 'Engine Overhaul', value: 'AED 8,500'),
        const TopSalesItem(sno: 2, description: 'Body Work', value: 'AED 7,200'),
        const TopSalesItem(sno: 3, description: 'Electrical Work', value: 'AED 6,400'),
        const TopSalesItem(sno: 4, description: 'AC Service', value: 'AED 5,100'),
        const TopSalesItem(sno: 5, description: 'General Maintenance', value: 'AED 4,800'),
      ],
    ),
    TopSalesCategory(
      title: 'Department Wise',
      items: [
        const TopSalesItem(sno: 1, description: 'MECHANICAL DEPARTMENT', value: 'AED 125,000'),
        const TopSalesItem(sno: 2, description: 'ELECTRICAL DEPARTMENT', value: 'AED 85,300'),
        const TopSalesItem(sno: 3, description: 'WRAPPING DEPARTMENT', value: 'AED 62,700'),
        const TopSalesItem(sno: 4, description: 'BODY SHOP', value: 'AED 45,200'),
        const TopSalesItem(sno: 5, description: 'AC SPECIALIST', value: 'AED 32,800'),
      ],
    ),
  ];

  void toggleCategory(int index) {
    topSalesCategories[index].isExpanded = !topSalesCategories[index].isExpanded;
    notifyListeners();
  }

  // ── Messages ──────────────────────────────────────────────────────────────
  String selectedUser = '';
  String messageText = '';
  final List<MessageModel> sentMessages = [];

  final List<String> users = [
    'Ahmed Service Advisor',
    'Mohammed Technician',
    'Ali Workshop Manager',
    'Hassan Accountant',
    'Omar Parts Manager',
    'Fatima Admin',
    'Sarah HR Manager',
  ];

  void selectUser(String user) {
    selectedUser = user;
    notifyListeners();
  }

  void updateMessage(String text) {
    messageText = text;
    notifyListeners();
  }

  void sendMessage() {
    if (selectedUser.isEmpty || messageText.trim().isEmpty) return;
    final now = TimeOfDay.now();
    final hour = now.hour % 12 == 0 ? 12 : now.hour % 12;
    final min = now.minute.toString().padLeft(2, '0');
    final ampm = now.hour < 12 ? 'AM' : 'PM';
    final msg = MessageModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      recipient: selectedUser,
      message: messageText.trim(),
      time: '$hour:$min $ampm',
    );
    sentMessages.insert(0, msg);
    selectedUser = '';
    messageText = '';
    notifyListeners();
  }
}