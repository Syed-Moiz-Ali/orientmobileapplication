// // ─── analytics_section.dart ───────────────────────────────────
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import 'package:fl_chart/fl_chart.dart';
// import '../model/dashboard_model.dart';
// import '../viewmodel/dashboard_viewmodel.dart';

// class AnalyticsSection extends StatelessWidget {
//   const AnalyticsSection({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Consumer<DashboardViewModel>(
//       builder: (context, vm, _) {
//         return Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             const Padding(
//               padding: EdgeInsets.fromLTRB(12, 4, 12, 8),
//               child: Text(
//                 'Analytics',
//                 style: TextStyle(
//                   fontSize: 13,
//                   fontWeight: FontWeight.w700,
//                   color: Color(0xFF111827),
//                 ),
//               ),
//             ),
//             Container(
//               margin: const EdgeInsets.symmetric(horizontal: 12),
//               decoration: BoxDecoration(
//                 color: Colors.white,
//                 borderRadius: BorderRadius.circular(8),
//                 border: Border.all(color: const Color(0xFFE5E7EB)),
//               ),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   _TabSelector(vm: vm),
//                   Padding(
//                     padding: const EdgeInsets.fromLTRB(12, 10, 12, 2),
//                     child: Text(
//                       vm.chartTitle,
//                       style: const TextStyle(
//                         fontSize: 10,
//                         color: Color(0xFF6B7280),
//                       ),
//                     ),
//                   ),
//                   SizedBox(
//                     height: 160,
//                     child: Padding(
//                       padding: const EdgeInsets.only(right: 12, bottom: 6),
//                       child: _LineChart(data: vm.chartData),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//             const SizedBox(height: 12),
//           ],
//         );
//       },
//     );
//   }
// }

// class _TabSelector extends StatelessWidget {
//   final DashboardViewModel vm;
//   const _TabSelector({required this.vm});

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       decoration: const BoxDecoration(
//         color: Color(0xFFF9FAFB),
//         borderRadius: BorderRadius.only(
//           topLeft: Radius.circular(8),
//           topRight: Radius.circular(8),
//         ),
//         border: Border(bottom: BorderSide(color: Color(0xFFE5E7EB))),
//       ),
//       child: Row(
//         children: [
//           _Tab(label: 'Sales',   tab: AnalyticsTab.sales,   vm: vm),
//           _Tab(label: 'Profit',  tab: AnalyticsTab.profit,  vm: vm),
//           _Tab(label: 'Revenue', tab: AnalyticsTab.revenue, vm: vm),
//         ],
//       ),
//     );
//   }
// }

// class _Tab extends StatelessWidget {
//   final String label;
//   final AnalyticsTab tab;
//   final DashboardViewModel vm;
//   const _Tab({required this.label, required this.tab, required this.vm});

//   @override
//   Widget build(BuildContext context) {
//     final isActive = vm.analyticsTab == tab;
//     return Expanded(
//       child: GestureDetector(
//         onTap: () => vm.setAnalyticsTab(tab),
//         child: AnimatedContainer(
//           duration: const Duration(milliseconds: 180),
//           padding: const EdgeInsets.symmetric(vertical: 8),
//           decoration: BoxDecoration(
//             color: isActive ? Colors.white : Colors.transparent,
//             border: isActive
//                 ? const Border(
//                     bottom: BorderSide(color: Color(0xFF2563EB), width: 2),
//                   )
//                 : null,
//             borderRadius: isActive
//                 ? const BorderRadius.only(
//                     topLeft: Radius.circular(8),
//                     topRight: Radius.circular(8),
//                   )
//                 : null,
//           ),
//           alignment: Alignment.center,
//           child: Text(
//             label,
//             style: TextStyle(
//               fontSize: 11,
//               fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
//               color: isActive
//                   ? const Color(0xFF2563EB)
//                   : const Color(0xFF6B7280),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }

// class _LineChart extends StatelessWidget {
//   final List<ChartPoint> data;
//   const _LineChart({required this.data});

//   @override
//   Widget build(BuildContext context) {
//     final spots = data
//         .asMap()
//         .entries
//         .map((e) => FlSpot(e.key.toDouble(), e.value.value))
//         .toList();
//     final maxY =
//         data.map((d) => d.value).reduce((a, b) => a > b ? a : b);

//     return LineChart(
//       LineChartData(
//         gridData: FlGridData(
//           show: true,
//           drawVerticalLine: false,
//           horizontalInterval: 100,
//           getDrawingHorizontalLine: (_) => const FlLine(
//             color: Color(0xFFF3F4F6),
//             strokeWidth: 1,
//           ),
//         ),
//         titlesData: FlTitlesData(
//           topTitles: const AxisTitles(
//             sideTitles: SideTitles(showTitles: false),
//           ),
//           rightTitles: const AxisTitles(
//             sideTitles: SideTitles(showTitles: false),
//           ),
//           leftTitles: AxisTitles(
//             sideTitles: SideTitles(
//               showTitles: true,
//               interval: 100,
//               reservedSize: 28,
//               getTitlesWidget: (v, _) => Text(
//                 '${v.toInt()}',
//                 style: const TextStyle(
//                   fontSize: 8,
//                   color: Color(0xFF9CA3AF),
//                 ),
//               ),
//             ),
//           ),
//           bottomTitles: AxisTitles(
//             sideTitles: SideTitles(
//               showTitles: true,
//               getTitlesWidget: (v, _) {
//                 final idx = v.toInt();
//                 if (idx < 0 || idx >= data.length) return const SizedBox();
//                 return Padding(
//                   padding: const EdgeInsets.only(top: 3),
//                   child: Text(
//                     data[idx].label,
//                     style: const TextStyle(
//                       fontSize: 8,
//                       color: Color(0xFF9CA3AF),
//                     ),
//                   ),
//                 );
//               },
//             ),
//           ),
//         ),
//         borderData: FlBorderData(show: false),
//         minY: 0,
//         maxY: (maxY * 1.2).ceilToDouble(),
//         lineBarsData: [
//           LineChartBarData(
//             spots: spots,
//             isCurved: true,
//             color: const Color(0xFF2563EB),
//             barWidth: 1.5,
//             isStrokeCapRound: true,
//             dotData: FlDotData(
//               show: true,
//               getDotPainter: (_, __, ___, ____) => FlDotCirclePainter(
//                 radius: 2.5,
//                 color: const Color(0xFF2563EB),
//                 strokeWidth: 1.5,
//                 strokeColor: Colors.white,
//               ),
//             ),
//             belowBarData: BarAreaData(
//               show: true,
//               color: const Color(0xFF2563EB).withOpacity(0.04),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }