// import 'package:flutter/material.dart';
// import 'package:orientmobileapplication/features/dashboard/model/dashboard_model.dart';
// import 'package:orientmobileapplication/features/dashboard/viewmodel/dashboard_viewmodel.dart';
// import 'package:provider/provider.dart';

// class BranchSelector extends StatelessWidget {
//   const BranchSelector({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Consumer<DashboardViewModel>(
//       builder: (context, vm, _) {
//         return Column(
//           children: [
//             GestureDetector(
//               onTap: vm.toggleBranchDropdown,
//               child: Container(
//                 padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//                   border: Border(
//                     bottom: BorderSide(color: Color(0xFFE5E7EB)),
//                   ),
//                 ),
//                 child: Row(
//                   children: [
//                     Expanded(
//                       child: Text(
//                         vm.selectedBranch.name,
//                         style: const TextStyle(
//                           fontSize: 14,
//                           fontWeight: FontWeight.w500,
//                           color: Color(0xFF111827),
//                         ),
//                       ),
//                     ),
//                     Icon(
//                       vm.isBranchDropdownOpen ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
//                       color: Color(0xFF6B7280),
//                       size: 20,
//                     ),
//                     const SizedBox(width: 8),
//                     GestureDetector(
//                       onTap: vm.refresh,
//                       child: const Icon(Icons.refresh, color: Color(0xFF6B7280), size: 20),
//                     ),
//                     const SizedBox(width: 8),
//                     const Icon(Icons.download_outlined, color: Color(0xFF6B7280), size: 20),
//                   ],
//                 ),
//               ),
//             ),
//             if (vm.isBranchDropdownOpen)
//               Container(
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.black.withOpacity(0.08),
//                       blurRadius: 12,
//                       offset: const Offset(0, 4),
//                     ),
//                   ],
//                 ),
//                 child: Column(
//                   children: vm.branches.map((b) => _BranchItem(branch: b)).toList(),
//                 ),
//               ),
//           ],
//         );
//       },
//     );
//   }
// }

// class _BranchItem extends StatelessWidget {
//   final Branch branch;
//   const _BranchItem({required this.branch});

//   @override
//   Widget build(BuildContext context) {
//     final vm = context.read<DashboardViewModel>();
//     final isSelected = vm.selectedBranch.id == branch.id;
//     return GestureDetector(
//       onTap: () => vm.selectBranch(branch),
//       child: Container(
//         padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
//         color: Colors.white,
//         child: Row(
//           children: [
//             Expanded(
//               child: Text(
//                 branch.name,
//                 style: TextStyle(
//                   fontSize: 14,
//                   color: Color(0xFF111827),
//                   fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
//                 ),
//               ),
//             ),
//             if (isSelected)
//               const Icon(Icons.check, color: Color(0xFF2563EB), size: 18),
//           ],
//         ),
//       ),
//     );
//   }
// }
