// ─── financial_summary_section.dart ──────────────────────────
import 'package:flutter/material.dart';

class FinancialSummarySection extends StatelessWidget {
  final void Function(Widget screen) onNavigate;

  const FinancialSummarySection({super.key, required this.onNavigate});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(bottom: 8),
            child: Text(
              'Financial Summary',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: Color(0xFF111827),
              ),
            ),
          ),

          // ── Gross Profit ──────────────────────────────────
          _FinancialCard(
            label: 'GROSS PROFIT',
            value: 'AED 13,740',
            accentColor: const Color(0xFF16A34A),
            bgColor: const Color(0xFFF0FDF4),
            icon: Icons.trending_up,
            iconBg: const Color(0xFF16A34A),
            fullWidth: true,
          ),
          const SizedBox(height: 8),

          // ── Cash + Bank ───────────────────────────────────
          Row(
            children: [
              Expanded(
                child: _FinancialCard(
                  label: 'CASH',
                  value: '12K',
                  subtitle: 'AED 12,400',
                  accentColor: const Color(0xFF16A34A),
                  bgColor: const Color(0xFFF0FDF4),
                  icon: Icons.account_balance_wallet_outlined,
                  iconBg: const Color(0xFF16A34A),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _FinancialCard(
                  label: 'BANK',
                  value: '33K',
                  subtitle: 'AED 33,400',
                  accentColor: const Color(0xFF2563EB),
                  bgColor: const Color(0xFFEFF6FF),
                  icon: Icons.credit_card_outlined,
                  iconBg: const Color(0xFF2563EB),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),

          // ── Service + Parts ───────────────────────────────
          Row(
            children: [
              Expanded(
                child: _FinancialCard(
                  label: 'SERVICE',
                  value: '27K',
                  subtitle: 'AED 27,480',
                  accentColor: const Color(0xFF7C3AED),
                  bgColor: const Color(0xFFF5F3FF),
                  icon: Icons.build_outlined,
                  iconBg: const Color(0xFF7C3AED),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _FinancialCard(
                  label: 'PARTS',
                  value: '18K',
                  subtitle: 'AED 18,320',
                  accentColor: const Color(0xFFF97316),
                  bgColor: const Color(0xFFFFF7ED),
                  icon: Icons.inventory_2_outlined,
                  iconBg: const Color(0xFFF97316),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}

class _FinancialCard extends StatelessWidget {
  final String label;
  final String value;
  final String? subtitle;
  final Color accentColor;
  final Color bgColor;
  final IconData icon;
  final Color iconBg;
  final bool fullWidth;

  const _FinancialCard({
    required this.label,
    required this.value,
    this.subtitle,
    required this.accentColor,
    required this.bgColor,
    required this.icon,
    required this.iconBg,
    this.fullWidth = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: fullWidth ? double.infinity : null,
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(8),
        border: Border(top: BorderSide(color: accentColor, width: 2.5)),
      ),
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    fontSize: 9,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF6B7280),
                    letterSpacing: 0.4,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF111827),
                  ),
                ),
                if (subtitle != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    subtitle!,
                    style: const TextStyle(
                      fontSize: 10,
                      color: Color(0xFF6B7280),
                    ),
                  ),
                ],
              ],
            ),
          ),
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              color: iconBg,
              borderRadius: BorderRadius.circular(7),
            ),
            alignment: Alignment.center,
            child: Icon(icon, color: Colors.white, size: 15),
          ),
        ],
      ),
    );
  }
}