// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import '../viewmodel/dashboard_viewmodel.dart';
// import '../widgets/app_theme.dart';

// import '../../dashboardmenu/activejobcardsview.dart';
// import '../../dashboardmenu/accountsreceivableview.dart';
// import '../../dashboardmenu/documentexpiryview.dart';
// import '../../dashboardmenu/pendingapprovalsview.dart';
// import '../../dashboardmenu/salesinvoicesview.dart';

// class AppSidebar extends StatelessWidget {
//   final void Function(Widget screen) onNavigate;

//   const AppSidebar({super.key, required this.onNavigate});

//   @override
//   Widget build(BuildContext context) {
//     final vm = context.watch<DashboardViewModel>();

//     return GestureDetector(
//       onTap: vm.closeSidebar,
//       child: Stack(
//         children: [
//           // Scrim
//           AnimatedOpacity(
//             opacity: vm.isSidebarOpen ? 1 : 0,
//             duration: const Duration(milliseconds: 250),
//             child: Container(color: Colors.black45),
//           ),
//           // Drawer
//           AnimatedSlide(
//             offset:
//                 vm.isSidebarOpen ? Offset.zero : const Offset(-1, 0),
//             duration: const Duration(milliseconds: 280),
//             curve: Curves.easeOutCubic,
//             child: GestureDetector(
//               onTap: () {}, // prevent scrim tap bleeding through
//               child: Container(
//                 width: 240,
//                 height: double.infinity,
//                 color: Colors.white,
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     _buildHeader(context, vm),
//                     const SizedBox(height: 8),

//                     _NavItem(
//                       icon: Icons.dashboard_outlined,
//                       label: 'Dashboard',
//                       active: true,
//                       onTap: vm.closeSidebar,
//                     ),
//                     _NavItem(
//                       icon: Icons.assignment_outlined,
//                       label: 'Job Cards',
//                       onTap: () {
//                         vm.closeSidebar();
//                         onNavigate(const ActiveJobCardsView());
//                       },
//                     ),
//                     _NavItem(
//                       icon: Icons.attach_money,
//                       label: 'Sales',
//                       onTap: () {
//                         vm.closeSidebar();
//                         //onNavigate(const SalesInvoicesView());
//                       },
//                     ),
//                     _NavItem(
//                       icon: Icons.account_balance_wallet_outlined,
//                       label: 'Receivables',
//                       onTap: () {
//                         vm.closeSidebar();
//                         onNavigate(const AccountsReceivableView());
//                       },
//                     ),
//                     _NavItem(
//                       icon: Icons.badge_outlined,
//                       label: 'Employee Docs',
//                       onTap: () {
//                         vm.closeSidebar();
//                         onNavigate(const DocumentExpiryView());
//                       },
//                     ),
//                     _NavItem(
//                       icon: Icons.check_circle_outline,
//                       label: 'Approvals',
//                       onTap: () {
//                         vm.closeSidebar();
//                         onNavigate(const PendingApprovalsView());
//                       },
//                     ),

//                     const Spacer(),
//                     const Divider(height: 1),

//                     _NavItem(
//                       icon: Icons.dark_mode_outlined,
//                       label: 'Dark Mode',
//                       onTap: () {},
//                     ),
//                     _NavItem(
//                       icon: Icons.settings_outlined,
//                       label: 'Settings',
//                       onTap: () {},
//                     ),
//                     _NavItem(
//                       icon: Icons.logout,
//                       label: 'Logout',
//                       isLogout: true,
//                       onTap: () {
//                         vm.closeSidebar();
//                         Navigator.of(context)
//                             .popUntil((r) => r.isFirst);
//                       },
//                     ),
//                     const SizedBox(height: 24),
//                   ],
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildHeader(BuildContext context, DashboardViewModel vm) {
//     return Container(
//       color: const Color(0xFF2563EB),
//       padding: EdgeInsets.only(
//         top: MediaQuery.of(context).padding.top + 12,
//         bottom: 16,
//         left: 16,
//         right: 8,
//       ),
//       child: Row(
//         children: [
//           const CircleAvatar(
//             backgroundColor: Colors.white30,
//             radius: 20,
//             child: Text(
//               'OA',
//               style: TextStyle(
//                 color: Colors.white,
//                 fontWeight: FontWeight.bold,
//                 fontSize: 13,
//               ),
//             ),
//           ),
//           const SizedBox(width: 12),
//           Expanded(
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 const Text(
//                   'Owner Account',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontWeight: FontWeight.w700,
//                     fontSize: 14,
//                   ),
//                 ),
//                 const Text(
//                   'owner@autogarage.ae',
//                   style: TextStyle(color: Colors.white70, fontSize: 11),
//                 ),
//                 const SizedBox(height: 6),
//                 Container(
//                   padding: const EdgeInsets.symmetric(
//                       horizontal: 10, vertical: 3),
//                   decoration: BoxDecoration(
//                     color: Colors.white24,
//                     borderRadius: BorderRadius.circular(20),
//                   ),
//                   child: Row(
//                     mainAxisSize: MainAxisSize.min,
//                     children: [
//                       const Icon(Icons.account_tree_outlined,
//                           color: Colors.white, size: 12),
//                       const SizedBox(width: 4),
//                       Text(
//                         vm.selectedBranch.name,
//                         style: const TextStyle(
//                             color: Colors.white, fontSize: 11),
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           IconButton(
//             icon: const Icon(Icons.close, color: Colors.white, size: 18),
//             onPressed: vm.closeSidebar,
//           ),
//         ],
//       ),
//     );
//   }
// }

// // ── Reusable nav row ──────────────────────────────────────────
// class _NavItem extends StatelessWidget {
//   final IconData icon;
//   final String label;
//   final bool active;
//   final bool isLogout;
//   final VoidCallback onTap;

//   const _NavItem({
//     required this.icon,
//     required this.label,
//     this.active = false,
//     this.isLogout = false,
//     required this.onTap,
//   });

//   @override
//   Widget build(BuildContext context) {
//     final Color iconColor = isLogout
//         ? const Color(0xFFDC2626)
//         : active
//             ? const Color(0xFF2563EB)
//             : const Color(0xFF6B7280);

//     final Color labelColor = isLogout
//         ? const Color(0xFFDC2626)
//         : active
//             ? const Color(0xFF2563EB)
//             : const Color(0xFF111827);

//     return Container(
//       margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 1),
//       decoration: BoxDecoration(
//         color: active
//             ? const Color(0xFF2563EB).withOpacity(0.1)
//             : Colors.transparent,
//         borderRadius: BorderRadius.circular(8),
//       ),
//       child: ListTile(
//         dense: true,
//         leading: Icon(icon, color: iconColor, size: 20),
//         title: Text(
//           label,
//           style: TextStyle(
//             color: labelColor,
//             fontWeight:
//                 active ? FontWeight.w600 : FontWeight.normal,
//             fontSize: 14,
//           ),
//         ),
//         onTap: onTap,
//       ),
//     );
//   }
// }
