// ─── performance_section.dart ─────────────────────────────────
import 'package:flutter/material.dart';

class PerformanceSection extends StatefulWidget {
  const PerformanceSection({super.key});

  @override
  State<PerformanceSection> createState() => _PerformanceSectionState();
}

class _PerformanceSectionState extends State<PerformanceSection> {
  int _selectedTab = 0;
  final List<String> _tabs = ['Today', 'This Month', 'This Year'];

  final List<Map<String, dynamic>> _data = [
    {'activeJobs': 18,   'newJobs': 7,    'totalSales': 45800},
    {'activeJobs': 312,  'newJobs': 98,   'totalSales': 820000},
    {'activeJobs': 3840, 'newJobs': 1120, 'totalSales': 9600000},
  ];

  @override
  Widget build(BuildContext context) {
    final d = _data[_selectedTab];
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Section Title ─────────────────────────────────
          const Text(
            'Performance',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: Color(0xFF111827),
            ),
          ),
          const SizedBox(height: 8),

          // ── Tab Selector ──────────────────────────────────
          Container(
            height: 32,
            decoration: BoxDecoration(
              color: const Color(0xFFF3F4F6),
              borderRadius: BorderRadius.circular(7),
            ),
            child: Row(
              children: List.generate(_tabs.length, (i) {
                final selected = i == _selectedTab;
                return Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _selectedTab = i),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      margin: const EdgeInsets.all(2.5),
                      decoration: BoxDecoration(
                        color: selected ? Colors.white : Colors.transparent,
                        borderRadius: BorderRadius.circular(5),
                        boxShadow: selected
                            ? [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.05),
                                  blurRadius: 3,
                                  offset: const Offset(0, 1),
                                )
                              ]
                            : null,
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        _tabs[i],
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
                          color: selected
                              ? const Color(0xFF111827)
                              : const Color(0xFF6B7280),
                        ),
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
          const SizedBox(height: 8),

          // ── Active Jobs + New Jobs ─────────────────────────
          Row(
            children: [
              Expanded(
                child: _MetricCard(
                  label: 'ACTIVE JOBS',
                  value: '${d['activeJobs']}',
                  accentColor: const Color(0xFFF97316),
                  bgColor: const Color(0xFFFFF7ED),
                  icon: Icons.work_outline,
                  iconBg: const Color(0xFFF97316),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _MetricCard(
                  label: 'NEW JOBS',
                  value: '${d['newJobs']}',
                  accentColor: const Color(0xFF2563EB),
                  bgColor: const Color(0xFFEFF6FF),
                  icon: Icons.description_outlined,
                  iconBg: const Color(0xFF2563EB),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),

          // ── Total Sales ───────────────────────────────────
          _MetricCard(
            label: 'TOTAL SALES',
            value: 'AED ${_formatAmount(d['totalSales'].toDouble())}',
            accentColor: const Color(0xFF16A34A),
            bgColor: const Color(0xFFF0FDF4),
            icon: Icons.attach_money,
            iconBg: const Color(0xFF16A34A),
            fullWidth: true,
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  String _formatAmount(double v) {
    return v
        .toStringAsFixed(0)
        .replaceAllMapped(
          RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
          (m) => '${m[1]},',
        );
  }
}

class _MetricCard extends StatelessWidget {
  final String label;
  final String value;
  final Color accentColor;
  final Color bgColor;
  final IconData icon;
  final Color iconBg;
  final bool fullWidth;

  const _MetricCard({
    required this.label,
    required this.value,
    required this.accentColor,
    required this.bgColor,
    required this.icon,
    required this.iconBg,
    this.fullWidth = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: fullWidth ? double.infinity : null,
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(8),
        border: Border(top: BorderSide(color: accentColor, width: 2.5)),
      ),
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    fontSize: 9,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF6B7280),
                    letterSpacing: 0.4,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF111827),
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              color: iconBg,
              borderRadius: BorderRadius.circular(7),
            ),
            alignment: Alignment.center,
            child: Icon(icon, color: Colors.white, size: 15),
          ),
        ],
      ),
    );
  }
}