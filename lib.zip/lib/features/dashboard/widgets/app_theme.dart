// This file exists so that imports like:
//   import 'package:orientmobileapplication/features/dashboard/widgets/app_theme.dart';
// continue to work alongside:
//   import '../../../../core/theme/app_theme.dart';
//
// Both paths now resolve to the same classes.

