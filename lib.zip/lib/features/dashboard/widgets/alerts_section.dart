// // ─── alerts_section.dart ──────────────────────────────────────
// import 'package:flutter/material.dart';
// import 'package:orientmobileapplication/features/dashboardmenu/job_status_view.dart';
// import 'package:orientmobileapplication/features/dashboardmenu/pendingjobcardsview.dart';
// import 'package:provider/provider.dart';
// import '../viewmodel/dashboard_viewmodel.dart';
// import '../model/dashboard_model.dart';
// import '../../dashboardmenu/documentexpiryview.dart';
// import '../../dashboardmenu/pendingapprovalsview.dart';

// class AlertsSection extends StatelessWidget {
//   final void Function(Widget screen) onNavigate;

//   const AlertsSection({super.key, required this.onNavigate});

//   @override
//   Widget build(BuildContext context) {
//     final vm = context.watch<DashboardViewModel>();

//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         const Padding(
//           padding: EdgeInsets.fromLTRB(12, 4, 12, 8),
//           child: Text(
//             'Alerts & Actions',
//             style: TextStyle(
//               fontSize: 13,
//               fontWeight: FontWeight.w700,
//               color: Color(0xFF111827),
//             ),
//           ),
//         ),
//         ...vm.alerts.map(
//           (alert) => Padding(
//             padding: const EdgeInsets.fromLTRB(12, 0, 12, 6),
//             child: _AlertCard(
//               alert: alert,
//               onTap: () => _handleTap(alert),
//             ),
//           ),
//         ),
//         const SizedBox(height: 4),
//       ],
//     );
//   }

//   void _handleTap(AlertItem alert) {
//   switch (alert.iconType) {
//     case 'doc':
//       onNavigate(const DocumentExpiryView());
//       break;
//     case 'alert':
//       onNavigate(const PendingApprovalsView());
//       break;
//     case 'pendingjobcards':          // ← unique key
//       onNavigate(const PendingJobCardsView());
//       break;
//     case 'jobcardstatus':            // ← unique key
//       onNavigate(const JobStatusView());
//       break;
//   }
// }
// }

// class _AlertCard extends StatelessWidget {
//   final AlertItem alert;
//   final VoidCallback onTap;

//   const _AlertCard({required this.alert, required this.onTap});

//   IconData get _icon {
//   switch (alert.iconType) {
//     case 'doc':
//       return Icons.assignment_outlined;
//     case 'alert':
//       return Icons.warning_amber_outlined;
//     case 'pendingjobcards':
//       return Icons.pending_actions_outlined;
//     case 'jobcardstatus':
//       return Icons.build_circle_outlined;
//     default:
//       return Icons.notifications_outlined;
//   }
// }

//   @override
//   Widget build(BuildContext context) {
//     final color = Color(alert.colorValue);

//     return GestureDetector(
//       onTap: onTap,
//       child: Container(
//         decoration: BoxDecoration(
//           color: color.withOpacity(0.05),
//           borderRadius: BorderRadius.circular(8),
//           border: Border.all(color: color.withOpacity(0.15)),
//         ),
//         child: ListTile(
//           dense: true,
//           minVerticalPadding: 0,
//           contentPadding:
//               const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
//           leading: Container(
//             width: 30,
//             height: 30,
//             decoration: BoxDecoration(
//               color: color,
//               borderRadius: BorderRadius.circular(7),
//             ),
//             alignment: Alignment.center,
//             child: Icon(_icon, color: Colors.white, size: 15),
//           ),
//           title: Row(
//             crossAxisAlignment: CrossAxisAlignment.center,
//             children: [
//               Flexible(
//                 child: Text(
//                   alert.title,
//                   style: const TextStyle(
//                     fontWeight: FontWeight.w600,
//                     fontSize: 12,
//                     color: Color(0xFF111827),
//                   ),
//                   overflow: TextOverflow.ellipsis,
//                 ),
//               ),
//               const SizedBox(width: 5),
//               Container(
//                 padding:
//                     const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
//                 decoration: BoxDecoration(
//                   color: const Color(0xFFDC2626),
//                   borderRadius: BorderRadius.circular(20),
//                 ),
//                 child: Text(
//                   '${alert.count}',
//                   style: const TextStyle(
//                     color: Colors.white,
//                     fontSize: 9,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 ),
//               ),
//             ],
//           ),
//           subtitle: Text(
//             alert.subtitle,
//             style: const TextStyle(
//               fontSize: 10,
//               color: Color(0xFF6B7280),
//             ),
//           ),
//           trailing: const Icon(
//             Icons.chevron_right,
//             color: Color(0xFF9CA3AF),
//             size: 16,
//           ),
//         ),
//       ),
//     );
//   }
// }