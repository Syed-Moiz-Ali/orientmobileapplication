// lib/features/customer/view/customer_vehicles_view.dart
import 'package:flutter/material.dart';
import 'package:orientmobileapplication/core/app_widgets.dart';
import 'package:orientmobileapplication/core/constants/app_colors.dart';
import 'package:orientmobileapplication/core/widgets/app_card.dart';
import 'package:orientmobileapplication/features/customer/view/add_vehicle_dialogue.dart';
import 'package:orientmobileapplication/features/customer/view/customer_book_service_view.dart';
import 'package:orientmobileapplication/features/customer/viewmodel/customer_dashboard_viewmodel.dart';
import 'package:provider/provider.dart';

import '../model/customer_models.dart';

class CustomerVehiclesView extends StatelessWidget {
  const CustomerVehiclesView({super.key});

  @override
  Widget build(BuildContext context) {
   // final vehicles = CustomerVehicle.mock;
  // ✅ CORRECT (mutable copy)
final vehicles = context.watch<CustomerDashboardViewModel>().vehicles;
    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            InnerTopBar(
              title: 'My Vehicles',
              trailing: GestureDetector(
           onTap: () async {
  final newVehicle = await showDialog<CustomerVehicle?>(
    context: context,
    builder: (_) => const AddVehicleDialog(),
  );

  if (newVehicle != null) {
    context.read<CustomerDashboardViewModel>().addVehicle(newVehicle);
  }
},
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                  decoration: BoxDecoration(color: kBlueBg, borderRadius: BorderRadius.circular(10)),
                  child: const Row(children: [
                    Icon(Icons.add, color: kBlue, size: 16),
                    SizedBox(width: 4),
                    Text('Add', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: kBlue)),
                  ]),
                ),
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(18, 18, 18, 32),
                child: Column(
                  children: [
                    ...vehicles.map((v) => Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: _VehicleCard(vehicle: v),
                    )),
                    // Add vehicle placeholder
                    GestureDetector(
                      onTap: () {},
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 20),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: kBorderMd, style: BorderStyle.solid, width: 1.5),
                        ),
                        child: const Column(children: [
                          Icon(Icons.add_circle_outline_rounded, color: kText4, size: 28),
                          SizedBox(height: 8),
                          Text('Add new vehicle',
                            style: TextStyle(fontSize: 13, color: kText3, fontWeight: FontWeight.w500)),
                        ]),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _VehicleCard extends StatelessWidget {
  final CustomerVehicle vehicle;
  const _VehicleCard({required this.vehicle});

  Color get _scoreColor => vehicle.healthScore >= 80 ? kGreen : vehicle.healthScore >= 60 ? kAmber : kRed;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: EdgeInsets.zero,
      child: Column(
        children: [
          // Header row
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 48, height: 48,
                  decoration: BoxDecoration(color: kBlueBg, borderRadius: BorderRadius.circular(12)),
                  child: const Icon(Icons.directions_car_rounded, color: kBlue, size: 24),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(vehicle.displayName,
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: kText)),
                      const SizedBox(height: 4),
                      Row(children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: kText.withOpacity(.08),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(vehicle.plateNumber,
                            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: kText2)),
                        ),
                        const SizedBox(width: 8),
                        Text('${vehicle.year}', style: const TextStyle(fontSize: 12, color: kText3)),
                      ]),
                    ],
                  ),
                ),
                // Health ring
                SizedBox(
                  width: 46, height: 46,
                  child: Stack(alignment: Alignment.center, children: [
                    CircularProgressIndicator(
                      value: vehicle.healthScore / 100,
                      strokeWidth: 4,
                      backgroundColor: kBorder,
                      valueColor: AlwaysStoppedAnimation(_scoreColor),
                      strokeCap: StrokeCap.round,
                    ),
                    Text('${vehicle.healthScore}',
                      style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: _scoreColor)),
                  ]),
                ),
              ],
            ),
          ),
          const Divider(height: 1, indent: 16, endIndent: 16),

          // Info tiles grid
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(children: [
              Row(children: [
                _InfoTile(icon: Icons.speed_rounded,         label: 'Mileage',      value: vehicle.mileage,      color: kBlue),
                const SizedBox(width: 10),
                _InfoTile(icon: Icons.palette_outlined,      label: 'Color',        value: vehicle.color,        color: kPurple),
              ]),
              const SizedBox(height: 10),
              Row(children: [
                _InfoTile(icon: Icons.history_rounded,       label: 'Last service', value: vehicle.lastService,  color: kGreen),
                const SizedBox(width: 10),
                _InfoTile(icon: Icons.event_outlined,        label: 'Next due',     value: vehicle.nextDue,      color: vehicle.healthScore < 70 ? kRed : kAmber),
              ]),
            ]),
          ),

          // Action buttons
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
            child: Row(children: [
              Expanded(child: ElevatedButton.icon(
onPressed: () => Navigator.push(
  context,
  MaterialPageRoute(
    builder: (context) => const CustomerBookServiceView(),
  ),
),                icon: const Icon(Icons.calendar_month_rounded, size: 15),
                label: const Text('Book Service'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: kBlue, foregroundColor: Colors.white, elevation: 0,
                  padding: const EdgeInsets.symmetric(vertical: 11),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  textStyle: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w600, fontSize: 12),
                ),
              )),
              const SizedBox(width: 10),
              Expanded(child: OutlinedButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.history_rounded, size: 15),
                label: const Text('History'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: kBlue,
                  side: const BorderSide(color: kBlueBorder),
                  padding: const EdgeInsets.symmetric(vertical: 11),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  textStyle: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w600, fontSize: 12),
                ),
              )),
            ]),
          ),
        ],
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  const _InfoTile({required this.icon, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) => Expanded(
    child: Container(
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: color.withOpacity(.06),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(.15)),
      ),
      child: Row(children: [
        Icon(icon, color: color, size: 15),
        const SizedBox(width: 8),
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(fontSize: 10, color: kText3)),
            const SizedBox(height: 2),
            Text(value,
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: kText2),
              overflow: TextOverflow.ellipsis),
          ],
        )),
      ]),
    ),
  );
}
