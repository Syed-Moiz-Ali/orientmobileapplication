// lib/features/customer/view/customer_service_status_view.dart
import 'package:flutter/material.dart';
import 'package:orientmobileapplication/core/app_widgets.dart';
import 'package:orientmobileapplication/core/constants/app_colors.dart';
import 'package:orientmobileapplication/core/widgets/app_card.dart';
import 'package:orientmobileapplication/main.dart' hide kBlue, kText, kText3, kBlueBg, kText4;

import '../model/customer_models.dart';

class CustomerServiceStatusView extends StatelessWidget {
  const CustomerServiceStatusView({super.key});

  @override
  Widget build(BuildContext context) {
    final svc = ActiveService.mock;

    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            InnerTopBar(
              title: 'Job Tracker',
              trailing: StatusPill(label: '● Live', bg: kGreenBg, fg: kGreen),
            ),
            const Divider(height: 1),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(18, 18, 18, 32),
                child: Column(children: [

                  // ── Job header card ────────────────────────────
                  AppCard(
                    color: kBlue,
                    borderColor: kBlue,
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Container(
                          width: 44, height: 44,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.build_rounded, color: Colors.white, size: 22),
                        ),
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(svc.jobCardId,
                            style: const TextStyle(fontSize: 11, color: Colors.white60, letterSpacing: .3)),
                          Text(svc.service,
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Colors.white)),
                        ])),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(.18),
                            borderRadius: BorderRadius.circular(99),
                          ),
                          child: const Text('In Service',
                            style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: Colors.white)),
                        ),
                      ]),
                      const SizedBox(height: 14),
                      const Divider(color: Colors.white24, height: 1),
                      const SizedBox(height: 14),
                      Row(children: [
                        _MetaItem(label: 'Vehicle',    value: svc.vehicleName),
                        _MetaItem(label: 'Plate',      value: svc.plateNumber),
                        _MetaItem(label: 'Started',    value: svc.started),
                        _MetaItem(label: 'Est. Ready', value: svc.estCompletion),
                      ]),
                    ]),
                  ),
                  const SizedBox(height: 14),

                  // ── Progress card ──────────────────────────────
                  AppCard(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        const Text('Overall Progress',
                          style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: kText)),
                        const Spacer(),
                        Text('${svc.progressPercent}%',
                          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: kBlue)),
                      ]),
                      const SizedBox(height: 12),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(99),
                        child: LinearProgressIndicator(
                          value: svc.progressPercent / 100,
                          minHeight: 9,
                          backgroundColor: kBg,
                          valueColor: const AlwaysStoppedAnimation(kBlue),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(children: [
                        const Icon(Icons.radio_button_checked, size: 12, color: kBlue),
                        const SizedBox(width: 6),
                        Text('Current: ${svc.currentStage}',
                          style: const TextStyle(fontSize: 12, color: kText3)),
                      ]),
                    ]),
                  ),
                  const SizedBox(height: 14),

                  // ── Technician card ────────────────────────────
                  AppCard(
                    child: Row(children: [
                      Container(
                        width: 44, height: 44,
                        decoration: BoxDecoration(color: kPurpleBg, shape: BoxShape.circle),
                        child: const Icon(Icons.person_rounded, color: kPurple, size: 22),
                      ),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('Your Technician',
                          style: TextStyle(fontSize: 11, color: kText3)),
                        const SizedBox(height: 2),
                        Text(svc.technicianName,
                          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: kText)),
                      ])),
                      _IconBtn(icon: Icons.call_rounded, color: kGreen, bg: kGreenBg, onTap: () {}),
                      const SizedBox(width: 8),
                      _IconBtn(icon: Icons.chat_bubble_outline_rounded, color: kBlue, bg: kBlueBg, onTap: () {}),
                    ]),
                  ),
                  const SizedBox(height: 14),

                  // ── Stages card ────────────────────────────────
                  AppCard(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('Service Stages',
                        style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: kText)),
                      const SizedBox(height: 16),
                      ...svc.stages.asMap().entries.map((e) =>
                        _StageItem(stage: e.value, isLast: e.key == svc.stages.length - 1)),
                    ]),
                  ),
                  const SizedBox(height: 14),

                  // ── Live updates strip ─────────────────────────
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: kGreenBg,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: kGreenBorder),
                    ),
                    child: const Row(children: [
                      Icon(Icons.sync_rounded, color: kGreen, size: 17),
                      SizedBox(width: 10),
                      Expanded(child: Text(
                        'Auto-refreshes every 2 minutes. SMS alerts for major milestones.',
                        style: TextStyle(fontSize: 12, color: kGreen, height: 1.4),
                      )),
                    ]),
                  ),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MetaItem extends StatelessWidget {
  final String label; final String value;
  const _MetaItem({required this.label, required this.value});

  @override
  Widget build(BuildContext context) => Expanded(child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(label, style: const TextStyle(fontSize: 9, color: Colors.white54)),
      const SizedBox(height: 2),
      Text(value, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: Colors.white),
          overflow: TextOverflow.ellipsis),
    ],
  ));
}

class _IconBtn extends StatelessWidget {
  final IconData icon; final Color color, bg; final VoidCallback onTap;
  const _IconBtn({required this.icon, required this.color, required this.bg, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: 36, height: 36,
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(10)),
      child: Icon(icon, color: color, size: 18),
    ),
  );
}

class _StageItem extends StatelessWidget {
  final ServiceStage stage; final bool isLast;
  const _StageItem({required this.stage, required this.isLast});

  (Color, Color, IconData) get _props {
    switch (stage.status) {
      case StageStatus.done:       return (kGreen,  kGreenBg,  Icons.check_rounded);
      case StageStatus.inProgress: return (kBlue,   kBlueBg,   Icons.arrow_forward_rounded);
      case StageStatus.pending:    return (kText4,  kBg,       Icons.circle_outlined);
    }
  }

  @override
  Widget build(BuildContext context) {
    final (color, bg, icon) = _props;
    return IntrinsicHeight(
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Column(children: [
          Container(
            width: 26, height: 26,
            decoration: BoxDecoration(color: bg, shape: BoxShape.circle,
                border: Border.all(color: color.withOpacity(.3))),
            child: Icon(icon, color: color, size: 13),
          ),
          if (!isLast)
            Expanded(child: Container(width: 1.5,
                color: stage.status == StageStatus.done ? kGreenBorder : kBorder)),
        ]),
        const SizedBox(width: 12),
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(bottom: isLast ? 0 : 14),
            child: Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(stage.name, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600,
                    color: stage.status == StageStatus.pending ? kText3 : kText)),
                if (stage.time != null)
                  Text(stage.time!, style: const TextStyle(fontSize: 11, color: kText3)),
              ])),
              if (stage.status == StageStatus.inProgress)
                StatusPill(label: 'Active', bg: kBlueBg, fg: kBlue)
              else if (stage.status == StageStatus.done)
                StatusPill(label: 'Done', bg: kGreenBg, fg: kGreen),
            ]),
          ),
        ),
      ]),
    );
  }
}
