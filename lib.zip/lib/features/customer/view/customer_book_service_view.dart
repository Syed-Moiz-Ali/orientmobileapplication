// lib/features/customer/view/customer_book_service_view.dart
import 'package:flutter/material.dart';
import 'package:orientmobileapplication/core/constants/app_colors.dart';
import 'package:orientmobileapplication/core/widgets/app_card.dart';

import '../model/customer_models.dart' hide kTimeSlots;

class CustomerBookServiceView extends StatefulWidget {
  const CustomerBookServiceView({super.key});
  @override
  State<CustomerBookServiceView> createState() => _CustomerBookServiceViewState();
}

class _CustomerBookServiceViewState extends State<CustomerBookServiceView> {
  int _step = 0;
  ServiceType?        _selectedService;
  DateTime _focusedMonth = DateTime(2026, 4);
  DateTime?           _selectedDate;
  String?             _selectedTime;
  CustomerVehicle?    _selectedVehicle;
  final _notesCtrl  = TextEditingController();

  static const _months = ['','January','February','March','April','May','June','July','August','September','October','November','December'];
  static const _wd     = ['Su','Mo','Tu','We','Th','Fr','Sa'];

  @override
  void dispose() { _notesCtrl.dispose(); super.dispose(); }

  List<DateTime?> _calDays() {
    final first = DateTime(_focusedMonth.year, _focusedMonth.month, 1);
    final last  = DateTime(_focusedMonth.year, _focusedMonth.month + 1, 0);
    final days  = <DateTime?>[];
    for (int i = 0; i < first.weekday % 7; i++) days.add(null);
    for (int d = 1; d <= last.day; d++) days.add(DateTime(_focusedMonth.year, _focusedMonth.month, d));
    while (days.length % 7 != 0) days.add(null);
    return days;
  }

  String get _summaryDate => _selectedDate == null ? '—'
      : '${_selectedDate!.day.toString().padLeft(2,'0')}/${_selectedDate!.month.toString().padLeft(2,'0')}/${_selectedDate!.year}';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            _TopBar(step: _step, onBack: () { if (_step == 0) Navigator.pop(context); else setState(() => _step--); }),
            const Divider(height: 1),
            _StepBar(step: _step),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(18, 20, 18, 20),
                child: [_buildStep0, _buildStep1, _buildStep2][_step](context),
              ),
            ),
            _BottomBar(
              label: _step == 2 ? 'Confirm Booking' : 'Continue',
              onTap: () {
                if (_step < 2) setState(() => _step++);
                else _showConfirmSheet(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  // ── Step 0: Select Service ─────────────────────────────────────
  Widget _buildStep0(BuildContext ctx) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Text('What do you need?',
        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: kText)),
      const SizedBox(height: 4),
      const Text('Choose a service to continue',
        style: TextStyle(fontSize: 13, color: kText3)),
      const SizedBox(height: 18),
      ...ServiceType.list.map((s) {
        final sel = _selectedService?.id == s.id;
        return GestureDetector(
          onTap: () => setState(() => _selectedService = s),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: sel ? kBlueBg : kSurface,
              borderRadius: BorderRadius.circular(13),
              border: Border.all(color: sel ? kBlue : kBorder, width: sel ? 1.5 : 0.8),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 6, offset: const Offset(0, 2))],
            ),
            child: Row(children: [
              Container(
                width: 42, height: 42,
                decoration: BoxDecoration(
                  color: sel ? kBlue.withOpacity(.12) : kBlueBg,
                  borderRadius: BorderRadius.circular(11),
                ),
                child: Icon(_serviceIcon(s.id), color: kBlue, size: 20),
              ),
              const SizedBox(width: 14),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(s.name,
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700,
                        color: sel ? kBlueText : kText)),
                  const SizedBox(height: 2),
                  Text(s.duration,
                    style: const TextStyle(fontSize: 12, color: kText3)),
                ],
              )),
              Text(s.price,
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700,
                    color: sel ? kBlue : kText3)),
              if (sel) ...[
                const SizedBox(width: 8),
                const Icon(Icons.check_circle_rounded, color: kBlue, size: 20),
              ],
            ]),
          ),
        );
      }),
      const SizedBox(height: 20),
    ],
  );

  // ── Step 1: Date & Time ────────────────────────────────────────
  Widget _buildStep1(BuildContext ctx) {
    final today   = DateTime.now();
    final calDays = _calDays();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Pick a date & time',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: kText)),
        const SizedBox(height: 18),
        AppCard(
          child: Column(children: [
            // Month nav
            Row(children: [
              _NavBtn(icon: Icons.chevron_left,
                  onTap: () => setState(() => _focusedMonth = DateTime(_focusedMonth.year, _focusedMonth.month - 1))),
              Expanded(
                child: Text('${_months[_focusedMonth.month]} ${_focusedMonth.year}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: kText)),
              ),
              _NavBtn(icon: Icons.chevron_right,
                  onTap: () => setState(() => _focusedMonth = DateTime(_focusedMonth.year, _focusedMonth.month + 1))),
            ]),
            const SizedBox(height: 14),
            Row(children: _wd.map((d) => Expanded(
              child: Text(d, textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: kText3)),
            )).toList()),
            const SizedBox(height: 8),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 7, childAspectRatio: 1.1),
              itemCount: calDays.length,
              itemBuilder: (_, i) {
                final d = calDays[i];
                if (d == null) return const SizedBox();
                final isToday    = d.year==today.year && d.month==today.month && d.day==today.day;
                final isSel      = _selectedDate != null && d.year==_selectedDate!.year && d.month==_selectedDate!.month && d.day==_selectedDate!.day;
                final isPast     = d.isBefore(DateTime(today.year, today.month, today.day));
                return GestureDetector(
                  onTap: isPast ? null : () => setState(() => _selectedDate = d),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 120),
                    margin: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: isSel ? kBlue : isToday ? kBlueBg : Colors.transparent,
                      borderRadius: BorderRadius.circular(8),
                      border: isToday && !isSel ? Border.all(color: kBlue) : null,
                    ),
                    child: Center(child: Text('${d.day}',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: isSel || isToday ? FontWeight.w700 : FontWeight.normal,
                        color: isSel ? Colors.white : isPast ? kText4 : kText,
                      ))),
                  ),
                );
              },
            ),
          ]),
        ),
        const SizedBox(height: 20),
        const Text('Available times',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: kText)),
        const SizedBox(height: 12),
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 4,
          crossAxisSpacing: 9,
          mainAxisSpacing: 9,
          childAspectRatio: 2.2,
          children: kTimeSlots.map((t) {
            final isSel = _selectedTime == t;
            return GestureDetector(
              onTap: () => setState(() => _selectedTime = t),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 120),
                decoration: BoxDecoration(
                  color: isSel ? kBlue : kSurface,
                  borderRadius: BorderRadius.circular(9),
                  border: Border.all(color: isSel ? kBlue : kBorder),
                ),
                child: Center(child: Text(t,
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600,
                      color: isSel ? Colors.white : kText2))),
              ),
            );
          }).toList(),
        ),
        const SizedBox(height: 20),
      ],
    );
  }

  // ── Step 2: Vehicle + Confirm ──────────────────────────────────
  Widget _buildStep2(BuildContext ctx) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Text('Almost done!',
        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: kText)),
      const SizedBox(height: 4),
      const Text('Choose your vehicle and review',
        style: TextStyle(fontSize: 13, color: kText3)),
      const SizedBox(height: 18),

      ...CustomerVehicle.mock.map((v) {
        final isSel = _selectedVehicle?.id == v.id;
        return GestureDetector(
          onTap: () => setState(() => _selectedVehicle = v),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 130),
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: isSel ? kBlueBg : kSurface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: isSel ? kBlue : kBorder, width: isSel ? 1.5 : 0.8),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 6, offset: const Offset(0, 2))],
            ),
            child: Row(children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  color: isSel ? kBlueBg : kBg,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(Icons.directions_car_rounded, color: isSel ? kBlue : kText3, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(v.displayName,
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700,
                        color: isSel ? kBlue : kText)),
                  const SizedBox(height: 2),
                  Text('${v.plateNumber}  ·  ${v.year}',
                    style: const TextStyle(fontSize: 12, color: kText3)),
                ],
              )),
              if (isSel) const Icon(Icons.check_circle_rounded, color: kBlue, size: 22),
            ]),
          ),
        );
      }),
      const SizedBox(height: 8),

      // Notes
      AppCard(
        padding: EdgeInsets.zero,
        child: TextField(
          controller: _notesCtrl,
          maxLines: 3,
          style: const TextStyle(fontSize: 13, color: kText),
          decoration: const InputDecoration(
            hintText: 'Additional notes (optional)…',
            hintStyle: TextStyle(color: kText4, fontSize: 13),
            border: InputBorder.none,
            contentPadding: EdgeInsets.all(14),
          ),
        ),
      ),
      const SizedBox(height: 18),

      // Summary card
      AppCard(
        color: kBlueBg,
        borderColor: kBlueBorder,
        child: Column(children: [
          _SumRow(icon: Icons.build_rounded,          label: 'Service',  value: _selectedService?.name ?? '—'),
          const Divider(height: 18, color: kBlueBorder),
          _SumRow(icon: Icons.calendar_month_rounded, label: 'Date',     value: _summaryDate),
          const Divider(height: 18, color: kBlueBorder),
          _SumRow(icon: Icons.access_time_rounded,    label: 'Time',     value: _selectedTime ?? '—'),
          const Divider(height: 18, color: kBlueBorder),
          _SumRow(icon: Icons.directions_car_rounded, label: 'Vehicle',  value: _selectedVehicle?.displayName ?? '—'),
          if (_selectedService != null) ...[
            const Divider(height: 18, color: kBlueBorder),
            _SumRow(icon: Icons.attach_money_rounded, label: 'Est. cost', value: _selectedService!.price, valueColor: kBlue),
          ],
        ]),
      ),
      const SizedBox(height: 20),
    ],
  );

  void _showConfirmSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: kSurface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(28),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 64, height: 64,
            decoration: BoxDecoration(color: kGreenBg, shape: BoxShape.circle),
            child: const Icon(Icons.check_rounded, color: kGreen, size: 32),
          ),
          const SizedBox(height: 16),
          const Text('Booking Confirmed!',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: kText)),
          const SizedBox(height: 8),
          Text('$_summaryDate · ${_selectedTime ?? '--'}',
            style: const TextStyle(fontSize: 14, color: kText3)),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(color: kBlueBg, borderRadius: BorderRadius.circular(10)),
            child: const Text('Ref: BK-2026-0047',
              style: TextStyle(fontWeight: FontWeight.w700, color: kBlue, fontSize: 13)),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () { Navigator.pop(context); Navigator.pop(context); },
              style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
              child: const Text('Back to Home'),
            ),
          ),
        ]),
      ),
    );
  }

  IconData _serviceIcon(String id) => const {
    '1': Icons.oil_barrel_outlined, '2': Icons.tire_repair_outlined,
    '3': Icons.search_rounded,      '4': Icons.build_outlined,
    '5': Icons.verified_outlined,   '6': Icons.settings_rounded,
  }[id] ?? Icons.build_outlined;
}

class _NavBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _NavBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: 32, height: 32,
      decoration: BoxDecoration(color: kBg, borderRadius: BorderRadius.circular(8), border: Border.all(color: kBorder)),
      child: Icon(icon, size: 20, color: kText2),
    ),
  );
}

class _SumRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color? valueColor;
  const _SumRow({required this.icon, required this.label, required this.value, this.valueColor});

  @override
  Widget build(BuildContext context) => Row(children: [
    Icon(icon, size: 16, color: kText3),
    const SizedBox(width: 10),
    Text(label, style: const TextStyle(fontSize: 13, color: kText3)),
    const Spacer(),
    Text(value, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: valueColor ?? kText)),
  ]);
}

class _StepBar extends StatelessWidget {
  final int step;
  const _StepBar({required this.step});

  @override
  Widget build(BuildContext context) => Container(
    color: kSurface,
    padding: const EdgeInsets.fromLTRB(18, 10, 18, 12),
    child: Row(children: [
      _Node(n: 0, step: step, label: 'Service'),
      _Line(done: step > 0),
      _Node(n: 1, step: step, label: 'Schedule'),
      _Line(done: step > 1),
      _Node(n: 2, step: step, label: 'Confirm'),
    ]),
  );
}

class _Node extends StatelessWidget {
  final int n; final int step; final String label;
  const _Node({required this.n, required this.step, required this.label});

  @override
  Widget build(BuildContext context) {
    final done   = step > n;
    final active = step == n;
    return Column(children: [
      Container(
        width: 26, height: 26,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: done ? kGreen : active ? kBlue : kBg,
          border: Border.all(color: done ? kGreen : active ? kBlue : kBorderMd, width: 1.5),
        ),
        child: Center(child: done
            ? const Icon(Icons.check, size: 13, color: Colors.white)
            : Text('${n+1}', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800,
                color: active ? Colors.white : kText3))),
      ),
      const SizedBox(height: 4),
      Text(label, style: TextStyle(fontSize: 9, fontWeight: FontWeight.w600,
          color: done ? kGreen : active ? kBlue : kText4)),
    ]);
  }
}

class _Line extends StatelessWidget {
  final bool done;
  const _Line({required this.done});

  @override
  Widget build(BuildContext context) => Expanded(
    child: Container(height: 1.5, margin: const EdgeInsets.only(bottom: 16),
        color: done ? kGreen : kBorder),
  );
}

class _TopBar extends StatelessWidget {
  final int step; final VoidCallback onBack;
  const _TopBar({required this.step, required this.onBack});

  @override
  Widget build(BuildContext context) => Container(
    color: kSurface, height: 60,
    padding: const EdgeInsets.symmetric(horizontal: 18),
    child: Row(children: [
      GestureDetector(
        onTap: onBack,
        child: Container(
          width: 34, height: 34,
          decoration: BoxDecoration(shape: BoxShape.circle, color: kBg, border: Border.all(color: kBorder)),
          child: const Icon(Icons.arrow_back_ios_new_rounded, size: 14, color: kText3),
        ),
      ),
      const SizedBox(width: 12),
      Text(['Select Service','Date & Time','Review & Confirm'][step],
        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: kText)),
    ]),
  );
}

class _BottomBar extends StatelessWidget {
  final String label; final VoidCallback onTap;
  const _BottomBar({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) => Container(
    padding: EdgeInsets.fromLTRB(18, 12, 18, MediaQuery.of(context).padding.bottom + 12),
    decoration: const BoxDecoration(
      color: kSurface,
      border: Border(top: BorderSide(color: kBorder)),
    ),
    child: SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15)),
        child: Text(label),
      ),
    ),
  );
}
