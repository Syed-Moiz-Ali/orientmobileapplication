// lib/features/customer/view/customer_notifications_view.dart
import 'package:flutter/material.dart';
import 'package:orientmobileapplication/core/constants/app_colors.dart';
import 'package:orientmobileapplication/main.dart' hide kSurface, kText3, kText, kBlue, kBlueBg, kText4;
import 'package:provider/provider.dart';

import '../model/customer_models.dart';
import '../viewmodel/customer_dashboard_viewmodel.dart';

class CustomerNotificationsView extends StatelessWidget {
  final CustomerDashboardViewModel vm;
  const CustomerNotificationsView({super.key, required this.vm});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: vm,
      child: const _NotifBody(),
    );
  }
}

class _NotifBody extends StatelessWidget {
  const _NotifBody();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<CustomerDashboardViewModel>();
    final unread = vm.unreadCount;

    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            // Top bar
            Container(
              color: kSurface,
              height: 60,
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: 34, height: 34,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: kBg, border: Border.all(color: kBorder)),
                      child: const Icon(Icons.arrow_back_ios_new_rounded, size: 14, color: kText3),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Notifications',
                          style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: kText)),
                        if (unread > 0)
                          Text('$unread unread',
                            style: const TextStyle(fontSize: 11, color: kBlue)),
                      ],
                    ),
                  ),
                  if (unread > 0)
                    GestureDetector(
                      onTap: vm.markAllRead,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(color: kBlueBg, borderRadius: BorderRadius.circular(8)),
                        child: const Text('Mark all read',
                          style: TextStyle(fontSize: 12, color: kBlue, fontWeight: FontWeight.w600)),
                      ),
                    ),
                ],
              ),
            ),
            const Divider(height: 1),

            Expanded(
              child: vm.notifications.isEmpty
                  ? const Center(child: Text('No notifications', style: TextStyle(color: kText3)))
                  : ListView.builder(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      itemCount: vm.notifications.length,
                      itemBuilder: (_, i) => _NotifCard(
                        notif: vm.notifications[i],
                        onTap: () => vm.markRead(vm.notifications[i].id),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NotifCard extends StatelessWidget {
  final CustomerNotification notif;
  final VoidCallback onTap;
  const _NotifCard({required this.notif, required this.onTap});

  (Color, Color, IconData) get _style {
    switch (notif.type) {
      case NotifType.carReady:         return (kGreen,  kGreenBg,  Icons.check_circle_rounded);
      case NotifType.bookingConfirmed: return (kBlue,   kBlueBg,   Icons.calendar_month_rounded);
      case NotifType.invoiceReady:     return (kAmber,  kAmberBg,  Icons.receipt_long_rounded);
      case NotifType.approvalNeeded:   return (kAmber,  kAmberBg,  Icons.warning_rounded);
      case NotifType.workInProgress:   return (kBlue,   kBlueBg,   Icons.build_rounded);
      case NotifType.reminder:         return (kPurple, kPurpleBg, Icons.notifications_rounded);
    }
  }

  @override
  Widget build(BuildContext context) {
    final (color, bg, icon) = _style;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: notif.isRead ? kSurface : color.withOpacity(.05),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: notif.isRead ? kBorder : color.withOpacity(.3),
            width: notif.isRead ? 0.8 : 1.5,
          ),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 8, offset: const Offset(0, 2))],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 40, height: 40,
              decoration: BoxDecoration(color: bg, shape: BoxShape.circle),
              child: Icon(icon, color: color, size: 19),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(notif.title,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: notif.isRead ? FontWeight.w500 : FontWeight.w700,
                      color: kText,
                    )),
                  const SizedBox(height: 4),
                  Text(notif.body,
                    style: const TextStyle(fontSize: 12, color: kText3, height: 1.45)),
                  const SizedBox(height: 6),
                  Text(notif.time,
                    style: const TextStyle(fontSize: 11, color: kText4)),
                ],
              ),
            ),
            if (!notif.isRead) ...[
              const SizedBox(width: 8),
              Container(width: 8, height: 8,
                decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
            ],
          ],
        ),
      ),
    );
  }
}
