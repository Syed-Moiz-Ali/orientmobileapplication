// lib/features/customer/view/customer_breakdown_help_view.dart
import 'package:flutter/material.dart';
import 'package:orientmobileapplication/core/app_widgets.dart';
import 'package:orientmobileapplication/core/constants/app_colors.dart' hide kBlueBg;
import 'package:orientmobileapplication/core/widgets/app_card.dart';
import 'package:orientmobileapplication/main.dart' hide kSurface, kText, kText3, kText4, kBlue;

import '../model/customer_models.dart';

class CustomerBreakdownHelpView extends StatefulWidget {
  const CustomerBreakdownHelpView({super.key});
  @override
  State<CustomerBreakdownHelpView> createState() => _CustomerBreakdownHelpViewState();
}

class _CustomerBreakdownHelpViewState extends State<CustomerBreakdownHelpView> {
  CustomerVehicle? _selectedVehicle;
  String?          _selectedIssue;
  final _locationCtrl = TextEditingController();
  bool _requestSent = false;

  static const _issues = [
    ('🔋', 'Battery Dead'),
    ('🔴', 'Flat Tyre'),
    ('🌡️', 'Overheating'),
    ('⛽', 'Fuel Empty'),
    ('🔑', 'Key Locked'),
    ('💥', 'Accident'),
  ];

  static const _tips = [
    'Turn on hazard lights and move to a safe location.',
    'Stay inside your vehicle in high-traffic areas.',
    'Share your live location with emergency contacts.',
    'Don\'t accept help from strangers.',
    'Keep your phone charged for emergencies.',
  ];

  @override
  void dispose() { _locationCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            InnerTopBar(
              title: 'Breakdown Help',
              trailing: StatusPill(label: 'SOS', bg: kRedBg, fg: kRed),
            ),
            const Divider(height: 1),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(18, 18, 18, 32),
                child: Column(children: [

                  // ── Emergency banner ───────────────────────────
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: kRedBg,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: kRedBorder),
                    ),
                    child: Column(children: [
                      Container(
                        width: 56, height: 56,
                        decoration: BoxDecoration(color: kRed.withOpacity(.12), shape: BoxShape.circle),
                        child: const Icon(Icons.sos_rounded, color: kRed, size: 28),
                      ),
                      const SizedBox(height: 10),
                      const Text('Emergency Support',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: kText)),
                      const SizedBox(height: 4),
                      const Text("We're here to help 24/7",
                        style: TextStyle(fontSize: 13, color: kText3)),
                      const SizedBox(height: 16),
                      Row(children: [
                        Expanded(child: _CallBtn(icon: Icons.call_rounded,          label: 'Call Now',  color: kGreen, onTap: () {})),
                        const SizedBox(width: 12),
                        Expanded(child: _CallBtn(icon: Icons.chat_bubble_rounded,   label: 'WhatsApp',  color: kGreen, onTap: () {})),
                      ]),
                    ]),
                  ),
                  const SizedBox(height: 18),

                  // ── What happened? ─────────────────────────────
                  const SectionHeader(title: 'What happened?'),
                  GridView.count(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 3,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                    childAspectRatio: 1.4,
                    children: _issues.map((pair) {
                      final (emoji, label) = pair;
                      final isSel = _selectedIssue == label;
                      return GestureDetector(
                        onTap: () => setState(() => _selectedIssue = label),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 130),
                          decoration: BoxDecoration(
                            color: isSel ? kRedBg : kSurface,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: isSel ? kRed : kBorder,
                              width: isSel ? 1.5 : 0.8,
                            ),
                          ),
                          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                            Text(emoji, style: const TextStyle(fontSize: 22)),
                            const SizedBox(height: 6),
                            Text(label,
                              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600,
                                  color: isSel ? kRed : kText2),
                              textAlign: TextAlign.center),
                          ]),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 18),

                  // ── Breakdown form ─────────────────────────────
                  AppCard(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('Breakdown details',
                        style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: kText)),
                      const SizedBox(height: 14),

                      const Text('Select vehicle',
                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: kText2)),
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: kBg, borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: kBorder),
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<CustomerVehicle>(
                            value: _selectedVehicle,
                            isExpanded: true,
                            hint: const Text('Choose vehicle',
                              style: TextStyle(color: kText4, fontSize: 13)),
                            icon: const Icon(Icons.keyboard_arrow_down_rounded, color: kText4),
                            items: CustomerVehicle.mock.map((v) => DropdownMenuItem(
                              value: v,
                              child: Text(v.shortLabel,
                                style: const TextStyle(fontSize: 13, color: kText)),
                            )).toList(),
                            onChanged: (v) => setState(() => _selectedVehicle = v),
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),

                      const Text('Your location',
                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: kText2)),
                      const SizedBox(height: 6),
                      Row(children: [
                        Expanded(
                          child: TextField(
                            controller: _locationCtrl,
                            style: const TextStyle(fontSize: 13, color: kText),
                            decoration: InputDecoration(
                              filled: true, fillColor: kBg,
                              hintText: 'Enter your location',
                              hintStyle: const TextStyle(color: kText4, fontSize: 13),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: const BorderSide(color: kBorder),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: const BorderSide(color: kBorder),
                              ),
                              prefixIcon: const Icon(Icons.location_on_outlined, color: kText3, size: 18),
                              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: () {},
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: kBlueBg, borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: kBlueBorder),
                            ),
                            child: const Icon(Icons.my_location_rounded, color: kBlue, size: 18),
                          ),
                        ),
                      ]),
                      const SizedBox(height: 16),

                      SizedBox(
                        width: double.infinity,
                        child: _requestSent
                            ? Container(
                                padding: const EdgeInsets.symmetric(vertical: 14),
                                decoration: BoxDecoration(
                                  color: kGreenBg,
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: kGreenBorder),
                                ),
                                child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                  Icon(Icons.check_circle_rounded, color: kGreen, size: 18),
                                  SizedBox(width: 8),
                                  Text('Help is on the way!',
                                    style: TextStyle(color: kGreen, fontWeight: FontWeight.w700, fontSize: 14)),
                                ]),
                              )
                            : ElevatedButton.icon(
                                onPressed: () => setState(() => _requestSent = true),
                                icon: const Icon(Icons.warning_amber_outlined, size: 18),
                                label: const Text('Request Emergency Support'),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: kRed, foregroundColor: Colors.white, elevation: 0,
                                  padding: const EdgeInsets.symmetric(vertical: 14),
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                  textStyle: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w700, fontSize: 14),
                                ),
                              ),
                      ),
                    ]),
                  ),
                  const SizedBox(height: 18),

                  // ── Info cards ─────────────────────────────────
                  Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Expanded(child: _InfoCard(
                      icon: Icons.local_shipping_rounded, color: kBlue,
                      title: 'Towing', sub: 'Free within 40km',
                    )),
                    const SizedBox(width: 10),
                    Expanded(child: _InfoCard(
                      icon: Icons.bolt_rounded, color: kAmber,
                      title: '30 min', sub: 'Avg response Dubai',
                    )),
                    const SizedBox(width: 10),
                    Expanded(child: _InfoCard(
                      icon: Icons.access_time_filled_rounded, color: kGreen,
                      title: '24 / 7', sub: 'Always available',
                    )),
                  ]),
                  const SizedBox(height: 18),

                  // ── Safety tips ────────────────────────────────
                  AppCard(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Row(children: [
                        Icon(Icons.shield_outlined, color: kAmber, size: 17),
                        SizedBox(width: 8),
                        Text('Safety tips',
                          style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: kText)),
                      ]),
                      const SizedBox(height: 12),
                      ..._tips.map((tip) => Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          const Padding(
                            padding: EdgeInsets.only(top: 2),
                            child: Icon(Icons.check_circle_outline_rounded, size: 14, color: kAmber),
                          ),
                          const SizedBox(width: 8),
                          Expanded(child: Text(tip,
                            style: const TextStyle(fontSize: 12, color: kText2, height: 1.45))),
                        ]),
                      )),
                    ]),
                  ),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CallBtn extends StatelessWidget {
  final IconData icon; final String label; final Color color; final VoidCallback onTap;
  const _CallBtn({required this.icon, required this.label, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 13),
      decoration: BoxDecoration(
        color: kGreenBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: kGreenBorder),
      ),
      child: Column(children: [
        Icon(icon, color: color, size: 22),
        const SizedBox(height: 6),
        Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: color)),
      ]),
    ),
  );
}

class _InfoCard extends StatelessWidget {
  final IconData icon; final Color color; final String title, sub;
  const _InfoCard({required this.icon, required this.color, required this.title, required this.sub});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(13),
    decoration: BoxDecoration(
      color: color.withOpacity(.06),
      borderRadius: BorderRadius.circular(13),
      border: Border.all(color: color.withOpacity(.2)),
    ),
    child: Column(children: [
      Icon(icon, color: color, size: 22),
      const SizedBox(height: 8),
      Text(title, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: color), textAlign: TextAlign.center),
      const SizedBox(height: 3),
      Text(sub, style: const TextStyle(fontSize: 10, color: kText3, height: 1.3), textAlign: TextAlign.center),
    ]),
  );
}
