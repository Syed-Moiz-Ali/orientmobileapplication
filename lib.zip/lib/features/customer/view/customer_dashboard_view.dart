// ─────────────────────────────────────────────────────────────────────────────
// customer_dashboard_view.dart
// lib/features/customer/view/customer_dashboard_view.dart
// ─────────────────────────────────────────────────────────────────────────────
//
// Customer Dashboard — Professional Slate & Teal theme (light mode)
// Matches dashboard_view.dart design language exactly.
//
// Font stack  : GoogleFonts.orbitron (values/hero), GoogleFonts.rajdhani (labels/nav)
// Color system: DC design tokens — identical to owner dashboard
//
// Screens included (all in one file):
//   1. CustomerDashboardView     — entry + ChangeNotifierProvider
//   2. _DashboardBody            — scaffold with AppBar + BottomNav
//   3. _HomePage                 — main overview (banner, stats, quick actions, vehicles, bookings)
//   4. _ServiceStatusPage        — live job tracker
//   5. _BookServicePage          — appointment booking form
//   6. _VehiclesPage             — vehicle list
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

import '../model/customer_models.dart';
import '../viewmodel/customer_dashboard_viewmodel.dart';

// ─────────────────────────────────────────────────────────────────────────────
// DESIGN TOKENS — identical palette to owner/supervisor dashboard
// ─────────────────────────────────────────────────────────────────────────────

abstract class DC {
  // Brand core
  static const primary = Color(0xFF0F4C75);
  static const accent = Color(0xFF1B9AAA);
  static const accentLight = Color(0xFFE0F4F6);
  static const accentMid = Color(0xFFB2E0E5);

  // Surface
  static const scaffold = Color(0xFFF5F7FA);
  static const surface = Color(0xFFFFFFFF);
  static const surfaceAlt = Color(0xFFF0F3F7);
  static const border = Color(0xFFE2E8EF);

  // Text
  static const textH = Color(0xFF0A1628);
  static const textB = Color(0xFF253347);
  static const textM = Color(0xFF5C6E85);

  // Semantic
  static const green = Color(0xFF1A8754);
  static const greenBg = Color(0xFFEAF7EF);
  static const amber = Color(0xFFD97706);
  static const amberBg = Color(0xFFFFF8EC);
  static const red = Color(0xFFB91C1C);
  static const redBg = Color(0xFFFEECEC);
  static const purple = Color(0xFF6D28D9);
  static const purpleBg = Color(0xFFF0EAFC);

  // Gradient
  static const gStart = Color(0xFF0F4C75);
  static const gEnd = Color(0xFF1B9AAA);
}

// ─────────────────────────────────────────────────────────────────────────────
// ENTRY
// ─────────────────────────────────────────────────────────────────────────────

class CustomerDashboardView extends StatelessWidget {
  const CustomerDashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => CustomerDashboardViewModel(),
      child: const _DashboardBody(),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SCAFFOLD
// ─────────────────────────────────────────────────────────────────────────────

class _DashboardBody extends StatelessWidget {
  const _DashboardBody();

  static const _pages = <Widget>[
    _HomePage(),
    _ServiceStatusPage(),
    _BookServicePage(),
    _VehiclesPage(),
  ];

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<CustomerDashboardViewModel>();

    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: DC.primary,
        statusBarIconBrightness: Brightness.light,
      ),
    );

    return Scaffold(
      backgroundColor: DC.scaffold,
      appBar: _AppBar(vm: vm),
      body: IndexedStack(index: vm.selectedIndex, children: _pages),
      bottomNavigationBar: _BottomNav(
        selectedIndex: vm.selectedIndex,
        onTap: vm.selectTab,
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// APP BAR
// ─────────────────────────────────────────────────────────────────────────────

class _AppBar extends StatelessWidget implements PreferredSizeWidget {
  final CustomerDashboardViewModel vm;
  const _AppBar({required this.vm});

  static const _titles = [
    'Customer Portal',
    'Service Status',
    'Book a Service',
    'My Vehicles',
  ];
  static const _subtitles = [
    'Welcome back',
    'Live Job Tracker',
    'Schedule an Appointment',
    'Registered Vehicles',
  ];

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight + 1);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      flexibleSpace: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [DC.gStart, DC.gEnd],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
        ),
      ),
      backgroundColor: Colors.transparent,
      elevation: 0,
      systemOverlayStyle: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
      ),
      titleSpacing: 0,
      leading: vm.selectedIndex == 0
          ? Padding(
              padding: const EdgeInsets.all(10),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.directions_car_rounded,
                  color: Colors.white,
                  size: 22,
                ),
              ),
            )
          : IconButton(
              icon: const Icon(
                Icons.arrow_back_ios_new_rounded,
                color: Colors.white,
                size: 20,
              ),
              onPressed: () => vm.selectTab(0),
            ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            _titles[vm.selectedIndex],
            style: GoogleFonts.rajdhani(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.5,
            ),
          ),
          Text(
            _subtitles[vm.selectedIndex],
            style: GoogleFonts.rajdhani(
              color: Colors.white70,
              fontSize: 12,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.4,
            ),
          ),
        ],
      ),
      actions: [
        // Notification bell
        Stack(
          clipBehavior: Clip.none,
          children: [
            IconButton(
              icon: const Icon(
                Icons.notifications_outlined,
                color: Colors.white,
                size: 26,
              ),
              onPressed: () {},
            ),
            if ((context.watch<CustomerDashboardViewModel>().unreadCount) > 0)
              Positioned(
                right: 10,
                top: 10,
                child: Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: const Color(0xFFFBBF24),
                    shape: BoxShape.circle,
                    border: Border.all(color: DC.gStart, width: 1.5),
                  ),
                ),
              ),
          ],
        ),
        // Avatar
        Padding(
          padding: const EdgeInsets.only(right: 14),
          child: GestureDetector(
            onTap: () => _showProfile(context),
            child: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.20),
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.white.withOpacity(0.5),
                  width: 1.5,
                ),
              ),
              child: Center(
                child: Text(
                  context
                      .watch<CustomerDashboardViewModel>()
                      .profile
                      .avatarInitials,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(height: 1, color: Colors.white.withOpacity(0.12)),
      ),
    );
  }

  void _showProfile(BuildContext context) {
    final vm = context.read<CustomerDashboardViewModel>();
    showModalBottomSheet(
      context: context,
      backgroundColor: DC.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: DC.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 24),
            Container(
              width: 68,
              height: 68,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [DC.gStart, DC.gEnd],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  vm.profile.avatarInitials,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Text(
              vm.profile.name,
              style: const TextStyle(
                color: DC.textH,
                fontSize: 19,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.3,
              ),
            ),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: DC.accentLight,
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Text(
                'Customer • Auto Garage ERP',
                style: TextStyle(
                  color: DC.accent,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 28),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: OutlinedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.of(context).pop();
                },
                style: OutlinedButton.styleFrom(
                  foregroundColor: DC.red,
                  side: const BorderSide(color: DC.red, width: 1.5),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                icon: const Icon(Icons.logout_rounded, size: 18),
                label: const Text(
                  'Logout',
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// BOTTOM NAV
// ─────────────────────────────────────────────────────────────────────────────

class _BottomNav extends StatelessWidget {
  final int selectedIndex;
  final void Function(int) onTap;
  const _BottomNav({required this.selectedIndex, required this.onTap});

  @override
  Widget build(BuildContext context) {
    const items = [
      (Icons.home_rounded, Icons.home_outlined, 'Home'),
      (Icons.track_changes_rounded, Icons.track_changes_outlined, 'Status'),
      (Icons.calendar_month_rounded, Icons.calendar_month_outlined, 'Book'),
      (Icons.directions_car_rounded, Icons.directions_car_outlined, 'Vehicles'),
    ];

    return Container(
      decoration: BoxDecoration(
        color: DC.surface,
        border: const Border(top: BorderSide(color: DC.border)),
        boxShadow: [
          BoxShadow(
            color: DC.primary.withOpacity(0.07),
            blurRadius: 16,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 74,
          child: Row(
            children: List.generate(items.length, (i) {
              final sel = selectedIndex == i;
              return Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => onTap(i),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 220),
                        curve: Curves.easeOutCubic,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 18,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: sel ? DC.accentLight : Colors.transparent,
                          borderRadius: BorderRadius.circular(24),
                        ),
                        child: Icon(
                          sel ? items[i].$1 : items[i].$2,
                          color: sel ? DC.accent : DC.textM,
                          size: 26,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        items[i].$3,
                        style: TextStyle(
                          fontSize: 11,
                          color: sel ? DC.accent : DC.textM,
                          fontWeight: sel ? FontWeight.w800 : FontWeight.w500,
                          letterSpacing: sel ? 0.2 : 0,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE 1 — HOME
// ─────────────────────────────────────────────────────────────────────────────

class _HomePage extends StatelessWidget {
  const _HomePage();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<CustomerDashboardViewModel>();

    if (vm.isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: DC.accent, strokeWidth: 2.5),
      );
    }

    return RefreshIndicator(
      onRefresh: vm.refresh,
      color: DC.accent,
      strokeWidth: 2.5,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _HeaderBanner(vm: vm),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 22, 16, 32),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Active Service Banner
                  _ActiveServiceCard(
                    svc: vm.activeService,
                    onTap: () => vm.selectTab(1),
                  ),
                  const SizedBox(height: 22),

                  _sectionLabel('Overview'),
                  const SizedBox(height: 12),
                  _StatGrid(vm: vm),
                  const SizedBox(height: 26),

                  _sectionLabel('Quick Actions'),
                  const SizedBox(height: 12),
                  _QuickActionsGrid(vm: vm),
                  const SizedBox(height: 26),

                  _sectionLabel('My Vehicles'),
                  const SizedBox(height: 12),
                  _VehicleScrollRow(vehicles: vm.vehicles),
                  const SizedBox(height: 26),

                  _sectionLabel('Recent Bookings'),
                  const SizedBox(height: 12),
                  _RecentBookingsList(bookings: vm.recentBookings),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionLabel(String text) => Row(
    children: [
      Container(
        width: 4,
        height: 20,
        decoration: BoxDecoration(
          color: DC.accent,
          borderRadius: BorderRadius.circular(2),
        ),
      ),
      const SizedBox(width: 10),
      Text(
        text,
        style: GoogleFonts.rajdhani(
          color: DC.textH,
          fontSize: 19,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.5,
        ),
      ),
    ],
  );
}

// ── Header Banner ──────────────────────────────────────────────────────────

class _HeaderBanner extends StatelessWidget {
  final CustomerDashboardViewModel vm;
  const _HeaderBanner({required this.vm});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 22, 20, 26),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [DC.gStart, DC.gEnd],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(32)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      margin: const EdgeInsets.only(right: 6, top: 1),
                      decoration: const BoxDecoration(
                        color: Color(0xFF4ADEDF),
                        shape: BoxShape.circle,
                      ),
                    ),
                    const Text(
                      'Live',
                      style: TextStyle(
                        color: Color(0xFF4ADEDF),
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                const Text(
                  'Good Morning,',
                  style: TextStyle(color: Colors.white70, fontSize: 14),
                ),
                Text(
                  vm.profile.name,
                  style: GoogleFonts.orbitron(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    height: 1.2,
                    letterSpacing: 0.5,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    _pill(
                      Icons.build_circle_outlined,
                      '${vm.activeService.progressPercent}% Done',
                      const Color(0xFFFBBF24),
                    ),
                    const SizedBox(width: 8),
                    _pill(
                      Icons.directions_car_rounded,
                      '${vm.vehicles.length} Vehicles',
                      const Color(0xFF4ADEDF),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            width: 68,
            height: 68,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.14),
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.white.withOpacity(0.25),
                width: 1.5,
              ),
            ),
            child: const Icon(
              Icons.person_outline_rounded,
              color: Colors.white,
              size: 32,
            ),
          ),
        ],
      ),
    );
  }

  Widget _pill(IconData icon, String label, Color accent) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: accent.withOpacity(0.4), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: accent, size: 14),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

// ── Active Service Card ────────────────────────────────────────────────────

class _ActiveServiceCard extends StatelessWidget {
  final ActiveService svc;
  final VoidCallback onTap;
  const _ActiveServiceCard({required this.svc, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [DC.gStart, DC.gEnd],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: DC.primary.withOpacity(0.30),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 9,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.18),
                    borderRadius: BorderRadius.circular(99),
                  ),
                  child: const Text(
                    'LIVE',
                    style: TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                      letterSpacing: 1.2,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                const Text(
                  'Current Service',
                  style: TextStyle(fontSize: 12, color: Colors.white70),
                ),
                const Spacer(),
                const Icon(
                  Icons.chevron_right_rounded,
                  color: Colors.white70,
                  size: 20,
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              svc.service,
              style: GoogleFonts.rajdhani(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: Colors.white,
                letterSpacing: 0.3,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              '${svc.vehicleName}  ·  ${svc.plateNumber}',
              style: const TextStyle(fontSize: 12, color: Colors.white70),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Progress',
                        style: TextStyle(fontSize: 10, color: Colors.white60),
                      ),
                      const SizedBox(height: 7),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(99),
                        child: LinearProgressIndicator(
                          value: svc.progressPercent / 100,
                          minHeight: 7,
                          backgroundColor: Colors.white24,
                          valueColor: const AlwaysStoppedAnimation(
                            Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                Text(
                  '${svc.progressPercent}%',
                  style: GoogleFonts.orbitron(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              '⏱  Est. ready by ${svc.estCompletion}',
              style: const TextStyle(fontSize: 11, color: Colors.white70),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Stat Grid — 3 KPI chips ────────────────────────────────────────────────

class _StatGrid extends StatelessWidget {
  final CustomerDashboardViewModel vm;
  const _StatGrid({required this.vm});

  @override
  Widget build(BuildContext context) {
    final chips = [
      _StatItem(
        '${vm.servicesThisYear}',
        'Services\nthis year',
        DC.accent,
        DC.accentLight,
      ),
      _StatItem(
        '${vm.vehicles.length}',
        'Vehicles\nregistered',
        DC.purple,
        DC.purpleBg,
      ),
      _StatItem(
        '${vm.unpaidInvoices}',
        'Unpaid\ninvoice',
        DC.amber,
        DC.amberBg,
      ),
    ];

    return Row(
      children: chips.asMap().entries.map((e) {
        final chip = e.value;
        final isLast = e.key == chips.length - 1;
        return Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: isLast ? 0 : 10),
            child: _SurfaceCard(
              child: Column(
                children: [
                  Text(
                    chip.value,
                    style: GoogleFonts.orbitron(
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                      color: chip.color,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    chip.label,
                    style: GoogleFonts.rajdhani(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: DC.textM,
                      height: 1.3,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _StatItem {
  final String value, label;
  final Color color, bg;
  const _StatItem(this.value, this.label, this.color, this.bg);
}

// ── Quick Actions Grid ─────────────────────────────────────────────────────

class _QuickActionsGrid extends StatelessWidget {
  final CustomerDashboardViewModel vm;
  const _QuickActionsGrid({required this.vm});

  @override
  Widget build(BuildContext context) {
    final actions = [
      _QAction(
        Icons.calendar_month_rounded,
        'Book\nAppointment',
        DC.accent,
        DC.accentLight,
        () => vm.selectTab(2),
      ),
      _QAction(
        Icons.directions_car_rounded,
        'My\nVehicles',
        DC.green,
        DC.greenBg,
        () => vm.selectTab(3),
      ),
      _QAction(
        Icons.track_changes_rounded,
        'Service\nStatus',
        DC.purple,
        DC.purpleBg,
        () => vm.selectTab(1),
      ),
      _QAction(
        Icons.emergency_rounded,
        'Breakdown\nHelp',
        DC.red,
        DC.redBg,
        () {},
      ),
    ];

    return Row(
      children: actions.asMap().entries.map((e) {
        final a = e.value;
        final isLast = e.key == actions.length - 1;
        return Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: isLast ? 0 : 10),
            child: GestureDetector(
              onTap: a.onTap,
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: BoxDecoration(
                  color: a.bg,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: a.color.withOpacity(0.20)),
                ),
                child: Column(
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: a.color.withOpacity(0.15),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(a.icon, size: 20, color: a.color),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      a.label,
                      style: GoogleFonts.rajdhani(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: a.color,
                        height: 1.2,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _QAction {
  final IconData icon;
  final String label;
  final Color color, bg;
  final VoidCallback onTap;
  const _QAction(this.icon, this.label, this.color, this.bg, this.onTap);
}

// ── Vehicle Horizontal Scroll ──────────────────────────────────────────────

class _VehicleScrollRow extends StatelessWidget {
  final List<CustomerVehicle> vehicles;
  const _VehicleScrollRow({required this.vehicles});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 128,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: vehicles.length,
        itemBuilder: (_, i) {
          final v = vehicles[i];
          final scoreColor = v.healthScore >= 80
              ? DC.green
              : v.healthScore >= 60
              ? DC.amber
              : DC.red;
          final scoreBg = v.healthScore >= 80
              ? DC.greenBg
              : v.healthScore >= 60
              ? DC.amberBg
              : DC.redBg;

          return Container(
            width: 200,
            margin: EdgeInsets.only(right: i < vehicles.length - 1 ? 12 : 0),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: DC.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: DC.border),
              boxShadow: [
                BoxShadow(
                  color: DC.primary.withOpacity(0.05),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        color: DC.accentLight,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(
                        Icons.directions_car_rounded,
                        color: DC.accent,
                        size: 16,
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: scoreBg,
                        borderRadius: BorderRadius.circular(99),
                      ),
                      child: Text(
                        '${v.healthScore}%',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: scoreColor,
                        ),
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                Text(
                  v.displayName,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: DC.textH,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  v.plateNumber,
                  style: const TextStyle(fontSize: 11, color: DC.textM),
                ),
                const SizedBox(height: 2),
                Text(
                  v.mileage,
                  style: const TextStyle(fontSize: 10, color: DC.textM),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// ── Recent Bookings List ───────────────────────────────────────────────────

class _RecentBookingsList extends StatelessWidget {
  final List<RecentBooking> bookings;
  const _RecentBookingsList({required this.bookings});

  (Color, Color) _statusColors(BookingStatus s) {
    switch (s) {
      case BookingStatus.confirmed:
        return (DC.accentLight, DC.accent);
      case BookingStatus.completed:
        return (DC.greenBg, DC.green);
      case BookingStatus.pending:
        return (DC.amberBg, DC.amber);
      case BookingStatus.cancelled:
        return (DC.redBg, DC.red);
    }
  }

  @override
  Widget build(BuildContext context) {
    return _SurfaceCard(
      child: Column(
        children: bookings.asMap().entries.map((e) {
          final b = e.value;
          final isLast = e.key == bookings.length - 1;
          final (bg, fg) = _statusColors(b.status);

          return Container(
            padding: EdgeInsets.fromLTRB(
              0,
              e.key == 0 ? 0 : 12,
              0,
              isLast ? 0 : 12,
            ),
            decoration: BoxDecoration(
              border: isLast
                  ? null
                  : const Border(
                      bottom: BorderSide(color: DC.border, width: 0.8),
                    ),
            ),
            child: Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: DC.accentLight,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(
                    Icons.build_circle_outlined,
                    color: DC.accent,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        b.service,
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: DC.textH,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        '${b.vehicleName}  ·  ${b.date}',
                        style: const TextStyle(fontSize: 11, color: DC.textM),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: bg,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    b.statusLabel,
                    style: TextStyle(
                      color: fg,
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE 2 — SERVICE STATUS
// ─────────────────────────────────────────────────────────────────────────────

class _ServiceStatusPage extends StatelessWidget {
  const _ServiceStatusPage();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<CustomerDashboardViewModel>();
    final svc = vm.activeService;
    final steps = vm.serviceSteps;

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 22, 16, 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Progress hero card
          _SurfaceCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            svc.service,
                            style: GoogleFonts.rajdhani(
                              color: DC.textH,
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.3,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            '${svc.vehicleName}  ·  ${svc.plateNumber}',
                            style: const TextStyle(
                              fontSize: 12,
                              color: DC.textM,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: DC.accentLight,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        'In Progress',
                        style: const TextStyle(
                          color: DC.accent,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Text(
                      '${svc.progressPercent}%',
                      style: GoogleFonts.orbitron(
                        color: DC.accent,
                        fontSize: 36,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.5,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Completion',
                            style: TextStyle(
                              color: DC.textM,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 7),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(99),
                            child: LinearProgressIndicator(
                              value: svc.progressPercent / 100,
                              minHeight: 10,
                              backgroundColor: DC.accentLight,
                              valueColor: const AlwaysStoppedAnimation(
                                DC.accent,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: DC.surfaceAlt,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.schedule_rounded,
                        color: DC.textM,
                        size: 16,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Est. ready by ${svc.estCompletion}',
                        style: const TextStyle(
                          color: DC.textM,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),

          _sectionLabel('Job Progress'),
          const SizedBox(height: 12),

          // Step timeline
          _SurfaceCard(
            child: Column(
              children: steps.asMap().entries.map((e) {
                final i = e.key;
                final step = e.value;
                final isLast = i == steps.length - 1;

                return Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Timeline line + dot
                    SizedBox(
                      width: 32,
                      child: Column(
                        children: [
                          Container(
                            width: 28,
                            height: 28,
                            decoration: BoxDecoration(
                              color: step.isCompleted
                                  ? DC.green
                                  : step.isCurrent
                                  ? DC.accent
                                  : DC.surfaceAlt,
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: step.isCompleted
                                    ? DC.green
                                    : step.isCurrent
                                    ? DC.accent
                                    : DC.border,
                                width: 2,
                              ),
                            ),
                            child: Icon(
                              step.isCompleted
                                  ? Icons.check_rounded
                                  : step.isCurrent
                                  ? Icons.autorenew_rounded
                                  : Icons.circle_outlined,
                              size: 14,
                              color: step.isCompleted || step.isCurrent
                                  ? Colors.white
                                  : DC.textM,
                            ),
                          ),
                          if (!isLast)
                            Container(
                              width: 2,
                              height: 36,
                              color: step.isCompleted ? DC.green : DC.border,
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.only(bottom: isLast ? 0 : 18),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              step.title,
                              style: TextStyle(
                                color: step.isCurrent ? DC.accent : DC.textH,
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              step.time,
                              style: const TextStyle(
                                color: DC.textM,
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionLabel(String text) => Row(
    children: [
      Container(
        width: 4,
        height: 20,
        decoration: BoxDecoration(
          color: DC.accent,
          borderRadius: BorderRadius.circular(2),
        ),
      ),
      const SizedBox(width: 10),
      Text(
        text,
        style: GoogleFonts.rajdhani(
          color: DC.textH,
          fontSize: 19,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.5,
        ),
      ),
    ],
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE 3 — BOOK SERVICE
// ─────────────────────────────────────────────────────────────────────────────

class _BookServicePage extends StatelessWidget {
  const _BookServicePage();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<CustomerDashboardViewModel>();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SurfaceCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'BOOK AN APPOINTMENT',
                  style: GoogleFonts.rajdhani(
                    color: DC.textM,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.0,
                  ),
                ),
                const SizedBox(height: 18),

                // Select vehicle
                _FormLabel('SELECT VEHICLE'),
                const SizedBox(height: 7),
                _DropdownField(
                  value: vm.selectedVehicle.isEmpty ? null : vm.selectedVehicle,
                  hint: 'Choose your vehicle...',
                  icon: Icons.directions_car_outlined,
                  items: vm.vehicles.map((v) => v.displayName).toList(),
                  onChanged: vm.setSelectedVehicle,
                ),
                const SizedBox(height: 16),

                // Select service type
                _FormLabel('SERVICE TYPE'),
                const SizedBox(height: 7),
                _DropdownField(
                  value: vm.selectedServiceType.isEmpty
                      ? null
                      : vm.selectedServiceType,
                  hint: 'Choose service type...',
                  icon: Icons.build_outlined,
                  items: vm.serviceTypes,
                  onChanged: vm.setSelectedServiceType,
                ),
                const SizedBox(height: 16),

                // Date picker
                _FormLabel('PREFERRED DATE'),
                const SizedBox(height: 7),
                GestureDetector(
                  onTap: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now().add(const Duration(days: 1)),
                      firstDate: DateTime.now(),
                      lastDate: DateTime.now().add(const Duration(days: 90)),
                      builder: (ctx, child) => Theme(
                        data: Theme.of(ctx).copyWith(
                          colorScheme: const ColorScheme.light(
                            primary: DC.accent,
                            onPrimary: Colors.white,
                          ),
                        ),
                        child: child!,
                      ),
                    );
                    if (picked != null) vm.setBookingDate(picked);
                  },
                  child: Container(
                    height: 50,
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    decoration: BoxDecoration(
                      color: DC.scaffold,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: DC.border),
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.calendar_today_outlined,
                          color: DC.textM,
                          size: 18,
                        ),
                        const SizedBox(width: 10),
                        Text(
                          vm.bookingDate == null
                              ? 'Select a date...'
                              : '${vm.bookingDate!.day}/${vm.bookingDate!.month}/${vm.bookingDate!.year}',
                          style: TextStyle(
                            color: vm.bookingDate == null ? DC.textM : DC.textH,
                            fontSize: 13,
                          ),
                        ),
                        const Spacer(),
                        const Icon(
                          Icons.keyboard_arrow_down_rounded,
                          color: DC.textM,
                          size: 18,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // Notes
                _FormLabel('ADDITIONAL NOTES'),
                const SizedBox(height: 7),
                TextField(
                  onChanged: vm.setBookingNotes,
                  maxLines: 4,
                  style: const TextStyle(color: DC.textH, fontSize: 13),
                  decoration: InputDecoration(
                    hintText: 'Describe the issue or service needed...',
                    hintStyle: const TextStyle(color: DC.textM, fontSize: 13),
                    filled: true,
                    fillColor: DC.scaffold,
                    contentPadding: const EdgeInsets.all(14),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: DC.border),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: DC.border),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(
                        color: DC.accent,
                        width: 1.5,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 22),

                // Submit button
                GestureDetector(
                  onTap: vm.submitBooking,
                  child: Container(
                    width: double.infinity,
                    height: 52,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [DC.gStart, DC.gEnd],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(
                          color: DC.accent.withOpacity(0.30),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          Icons.calendar_month_rounded,
                          color: Colors.white,
                          size: 18,
                        ),
                        const SizedBox(width: 10),
                        Text(
                          'CONFIRM BOOKING',
                          style: GoogleFonts.rajdhani(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1.0,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE 4 — MY VEHICLES
// ─────────────────────────────────────────────────────────────────────────────

class _VehiclesPage extends StatelessWidget {
  const _VehiclesPage();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<CustomerDashboardViewModel>();

    return Column(
      children: [
        // Sub-header
        Container(
          color: DC.surface,
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
          child: Row(
            children: [
              const Icon(
                Icons.directions_car_rounded,
                color: DC.accent,
                size: 18,
              ),
              const SizedBox(width: 8),
              Text(
                '${vm.vehicles.length} Registered Vehicles',
                style: const TextStyle(
                  color: DC.textB,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
        const Divider(height: 1, color: DC.border),
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
            itemCount: vm.vehicles.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (_, i) => _VehicleDetailCard(vehicle: vm.vehicles[i]),
          ),
        ),
      ],
    );
  }
}

class _VehicleDetailCard extends StatelessWidget {
  final CustomerVehicle vehicle;
  const _VehicleDetailCard({required this.vehicle});

  @override
  Widget build(BuildContext context) {
    final scoreColor = vehicle.healthScore >= 80
        ? DC.green
        : vehicle.healthScore >= 60
        ? DC.amber
        : DC.red;
    final scoreBg = vehicle.healthScore >= 80
        ? DC.greenBg
        : vehicle.healthScore >= 60
        ? DC.amberBg
        : DC.redBg;

    return _SurfaceCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [DC.gStart, DC.gEnd],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.directions_car_rounded,
                  color: Colors.white,
                  size: 22,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      vehicle.displayName,
                      style: GoogleFonts.rajdhani(
                        color: DC.textH,
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.3,
                      ),
                    ),
                    Text(
                      vehicle.plateNumber,
                      style: const TextStyle(
                        color: DC.textM,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: scoreBg,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.favorite_rounded, size: 11, color: scoreColor),
                    const SizedBox(width: 4),
                    Text(
                      '${vehicle.healthScore}%',
                      style: TextStyle(
                        color: scoreColor,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // Health bar
          Row(
            children: [
              const Text(
                'Health Score',
                style: TextStyle(
                  color: DC.textM,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const Spacer(),
              Text(
                vehicle.mileage,
                style: const TextStyle(color: DC.textM, fontSize: 11),
              ),
            ],
          ),
          const SizedBox(height: 7),
          ClipRRect(
            borderRadius: BorderRadius.circular(99),
            child: LinearProgressIndicator(
              value: vehicle.healthScore / 100,
              minHeight: 8,
              backgroundColor: DC.surfaceAlt,
              valueColor: AlwaysStoppedAnimation(scoreColor),
            ),
          ),
          const SizedBox(height: 14),
          // Divider + quick actions
          const Divider(color: DC.border),
          const SizedBox(height: 10),
          Row(
            children: [
              _VehicleAction(
                icon: Icons.build_rounded,
                label: 'Service History',
                color: DC.accent,
                bg: DC.accentLight,
              ),
              const SizedBox(width: 10),
              _VehicleAction(
                icon: Icons.calendar_month_rounded,
                label: 'Book Service',
                color: DC.green,
                bg: DC.greenBg,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _VehicleAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color, bg;
  const _VehicleAction({
    required this.icon,
    required this.label,
    required this.color,
    required this.bg,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 15, color: color),
            const SizedBox(width: 6),
            Text(
              label,
              style: GoogleFonts.rajdhani(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SHARED WIDGETS
// ─────────────────────────────────────────────────────────────────────────────

class _SurfaceCard extends StatelessWidget {
  final Widget child;
  const _SurfaceCard({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: DC.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: DC.border),
        boxShadow: [
          BoxShadow(
            color: DC.primary.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: child,
    );
  }
}

class _FormLabel extends StatelessWidget {
  final String text;
  const _FormLabel(this.text);

  @override
  Widget build(BuildContext context) => Text(
    text,
    style: GoogleFonts.rajdhani(
      color: DC.textM,
      fontSize: 11,
      fontWeight: FontWeight.w800,
      letterSpacing: 0.8,
    ),
  );
}

class _DropdownField extends StatelessWidget {
  final String? value;
  final String hint;
  final IconData icon;
  final List<String> items;
  final void Function(String) onChanged;
  const _DropdownField({
    required this.value,
    required this.hint,
    required this.icon,
    required this.items,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: DC.scaffold,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: DC.border),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          hint: Row(
            children: [
              Icon(icon, color: DC.textM, size: 18),
              const SizedBox(width: 8),
              Text(hint, style: const TextStyle(color: DC.textM, fontSize: 13)),
            ],
          ),
          dropdownColor: DC.surface,
          style: const TextStyle(color: DC.textH, fontSize: 13),
          icon: const Icon(
            Icons.keyboard_arrow_down_rounded,
            color: DC.textM,
            size: 18,
          ),
          isExpanded: true,
          onChanged: (v) => onChanged(v ?? ''),
          items: items
              .map((s) => DropdownMenuItem(value: s, child: Text(s)))
              .toList(),
        ),
      ),
    );
  }
}
