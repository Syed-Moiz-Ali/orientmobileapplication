// lib/features/customer/viewmodel/customer_dashboard_viewmodel.dart
import 'package:flutter/foundation.dart';
import '../model/customer_models.dart';

class CustomerDashboardViewModel extends ChangeNotifier {
  // ── Existing fields (unchanged) ──────────────────────────────────────────

  final CustomerProfile profile = CustomerProfile.mock;
  final List<RecentBooking> recentBookings = RecentBooking.mock;
  final ActiveService activeService = ActiveService.mock;
  final List<CustomerVehicle> _vehicles = List.from(CustomerVehicle.mock);

  List<CustomerVehicle> get vehicles => _vehicles;

  List<CustomerNotification> _notifications = CustomerNotification.mock;
  List<CustomerNotification> get notifications => _notifications;

  int get unreadCount => _notifications.where((n) => !n.isRead).length;

  void markAllRead() {
    for (final n in _notifications) {
      n.isRead = true;
    }
    notifyListeners();
  }

  void markRead(String id) {
    final n = _notifications.firstWhere(
      (n) => n.id == id,
      orElse: () => _notifications.first,
    );
    n.isRead = true;
    notifyListeners();
  }

  String formatAmount(double amount) =>
      '£${amount.toStringAsFixed(0).replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}';

  void addVehicle(CustomerVehicle vehicle) {
    _vehicles.add(vehicle);
    notifyListeners();
  }

  // ── Navigation ────────────────────────────────────────────────────────────

  int _selectedIndex = 0;
  int get selectedIndex => _selectedIndex;

  void selectTab(int index) {
    if (_selectedIndex == index) return;
    _selectedIndex = index;
    notifyListeners();
  }

  // ── Loading state ─────────────────────────────────────────────────────────

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  Future<void> refresh() async {
    _isLoading = true;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 800));
    _isLoading = false;
    notifyListeners();
  }

  // ── Dashboard stats ───────────────────────────────────────────────────────

  int get servicesThisYear => recentBookings
      .where((b) => b.status == BookingStatus.completed)
      .length;

  int get unpaidInvoices => 1; // stub — replace with real data source

  // ── Service steps (live job tracker) ─────────────────────────────────────

  final List<ServiceStep> serviceSteps = [
    ServiceStep(
      title: 'Job Card Created',
      time: 'Today, 08:30 AM',
      isCompleted: true,
      isCurrent: false,
    ),
    ServiceStep(
      title: 'Vehicle Inspection',
      time: 'Today, 09:15 AM',
      isCompleted: true,
      isCurrent: false,
    ),
    ServiceStep(
      title: 'Parts Ordered',
      time: 'Today, 10:00 AM',
      isCompleted: true,
      isCurrent: false,
    ),
    ServiceStep(
      title: 'Repair In Progress',
      time: 'In progress...',
      isCompleted: false,
      isCurrent: true,
    ),
    ServiceStep(
      title: 'Quality Check',
      time: 'Pending',
      isCompleted: false,
      isCurrent: false,
    ),
    ServiceStep(
      title: 'Ready for Collection',
      time: 'Pending',
      isCompleted: false,
      isCurrent: false,
    ),
  ];

  // ── Book Service form state ───────────────────────────────────────────────

  String _selectedVehicle = '';
  String get selectedVehicle => _selectedVehicle;

  void setSelectedVehicle(String value) {
    _selectedVehicle = value;
    notifyListeners();
  }

  String _selectedServiceType = '';
  String get selectedServiceType => _selectedServiceType;

  void setSelectedServiceType(String value) {
    _selectedServiceType = value;
    notifyListeners();
  }

  final List<String> serviceTypes = [
    'Full Service',
    'Oil & Filter Change',
    'Brake Inspection',
    'Tyre Replacement',
    'MOT Check',
    'Air Conditioning Service',
    'Battery Replacement',
    'Diagnostic Check',
    'Wheel Alignment',
    'Clutch Repair',
  ];

  DateTime? _bookingDate;
  DateTime? get bookingDate => _bookingDate;

  void setBookingDate(DateTime date) {
    _bookingDate = date;
    notifyListeners();
  }

  String _bookingNotes = '';
  String get bookingNotes => _bookingNotes;

  void setBookingNotes(String value) {
    _bookingNotes = value;
    // No notifyListeners needed for every keystroke —TextField manages its own state
  }

  bool _bookingSubmitted = false;
  bool get bookingSubmitted => _bookingSubmitted;

  void submitBooking() {
    if (_selectedVehicle.isEmpty || _selectedServiceType.isEmpty || _bookingDate == null) return;
    _bookingSubmitted = true;
    // Reset form
    _selectedVehicle = '';
    _selectedServiceType = '';
    _bookingDate = null;
    _bookingNotes = '';
    notifyListeners();
  }
}

// ── ServiceStep model (local to viewmodel) ────────────────────────────────

class ServiceStep {
  final String title;
  final String time;
  final bool isCompleted;
  final bool isCurrent;

  const ServiceStep({
    required this.title,
    required this.time,
    required this.isCompleted,
    required this.isCurrent,
  });
}