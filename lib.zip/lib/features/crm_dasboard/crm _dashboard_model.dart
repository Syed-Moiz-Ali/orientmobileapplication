// ─────────────────────────────────────────────────────────────────────────────
// crm_dashboard_model.dart
// lib/features/crm/model/crm_dashboard_model.dart
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';

// ── KPI Card ────────────────────────────────────────────────────────────────

class CrmKpiModel {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  final Color bgColor;
  final String trend;
  final bool trendUp;

  const CrmKpiModel({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
    required this.bgColor,
    required this.trend,
    required this.trendUp,
  });
}

// ── Channel Breakdown ────────────────────────────────────────────────────────

class CrmChannelModel {
  final String label;
  final IconData icon;
  final Color color;
  final String value;
  final String trend;
  final bool trendUp;

  const CrmChannelModel({
    required this.label,
    required this.icon,
    required this.color,
    required this.value,
    required this.trend,
    required this.trendUp,
  });
}

// ── Lead ─────────────────────────────────────────────────────────────────────

class CrmLeadModel {
  final int sno;
  final String leadNumber;
  final String customerName;
  final String phone;
  final String email;
  final String source;
  final Color sourceColor;
  final String assignedTo;
  final String status;
  final Color statusColor;
  final String lastActivity;

  const CrmLeadModel({
    required this.sno,
    required this.leadNumber,
    required this.customerName,
    required this.phone,
    required this.email,
    required this.source,
    required this.sourceColor,
    required this.assignedTo,
    required this.status,
    required this.statusColor,
    required this.lastActivity,
  });
}

// ── Conversion Trend ─────────────────────────────────────────────────────────

class CrmTrendPoint {
  final String month;
  final double won;
  final double lost;
  final double active;

  const CrmTrendPoint(this.month, this.won, this.lost, this.active);
}

// ── Salesperson Performance ───────────────────────────────────────────────────

class SalespersonPerf {
  final String name;
  final double leads;
  final double won;

  const SalespersonPerf(this.name, this.leads, this.won);
}

// ── Response Time Bucket ─────────────────────────────────────────────────────

class ResponseTimeBucket {
  final String label;
  final double count;

  const ResponseTimeBucket(this.label, this.count);
}

// ── Lead Source Distribution ─────────────────────────────────────────────────

class LeadSourceSlice {
  final String label;
  final double percent;
  final Color color;

  const LeadSourceSlice(this.label, this.percent, this.color);
}

// ── Key Metric ───────────────────────────────────────────────────────────────

class CrmKeyMetric {
  final String label;
  final String value;
  final String sub;
  final bool up;
  final Color color;

  const CrmKeyMetric({
    required this.label,
    required this.value,
    required this.sub,
    required this.up,
    required this.color,
  });
}

// ── Integration ──────────────────────────────────────────────────────────────

class IntegrationModel {
  final String name;
  final IconData icon;
  final Color color;
  final bool connected;

  const IntegrationModel({
    required this.name,
    required this.icon,
    required this.color,
    required this.connected,
  });
}

// ── Task ─────────────────────────────────────────────────────────────────────

class CrmTaskModel {
  final String id;
  final String title;
  final String assignedTo;
  final String dueDate;
  final String priority;
  final Color priorityColor;
  bool isDone;

  CrmTaskModel({
    required this.id,
    required this.title,
    required this.assignedTo,
    required this.dueDate,
    required this.priority,
    required this.priorityColor,
    this.isDone = false,
  });
}

// ── Sales Team Member ─────────────────────────────────────────────────────────

class SalesTeamMember {
  final String name;
  final String role;
  final int leadsHandled;
  final int wonDeals;
  final String revenue;
  final double winRate;

  const SalesTeamMember({
    required this.name,
    required this.role,
    required this.leadsHandled,
    required this.wonDeals,
    required this.revenue,
    required this.winRate,
  });
}

// ── Conversation ──────────────────────────────────────────────────────────────

class ConversationModel {
  final String id;
  final String customerName;
  final String lastMessage;
  final String time;
  final String channel;
  final Color channelColor;
  final int unread;
  final String status;

  const ConversationModel({
    required this.id,
    required this.customerName,
    required this.lastMessage,
    required this.time,
    required this.channel,
    required this.channelColor,
    required this.unread,
    required this.status,
  });
}