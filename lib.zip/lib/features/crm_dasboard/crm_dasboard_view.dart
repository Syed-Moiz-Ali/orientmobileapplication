// ─────────────────────────────────────────────────────────────────────────────
// crm_dashboard_view.dart
// lib/features/crm/view/crm_dashboard_view.dart
// ─────────────────────────────────────────────────────────────────────────────
//
// CRM Dashboard — Professional Slate & Teal theme (light mode)
// Matches the owner dashboard_view.dart design language exactly.
//
// FIX: KPI cards "BOTTOM OVERFLOWED BY 6.3 PIXELS" resolved by:
//   - childAspectRatio: 1.6 → 1.35  (taller grid cells)
//   - Reduced _KpiCard internal padding, icon size, font sizes, spacing
//
// Screens (all in one file):
//   1. CrmDashboardView         — entry + ChangeNotifierProvider
//   2. _CrmBody                 — scaffold with AppBar + Drawer
//   3. _DashboardPage           — KPI grid + channels + recent leads
//   4. _LeadsPage               — full leads list with search & filter
//   5. _ConversationsPage       — conversation thread list
//   6. _SalesTeamPage           — team member cards
//   7. _TasksPage               — task checklist
//   8. _ReportsPage             — charts: trend, pie, bar, key metrics
//   9. _IntegrationsPage        — integration status cards
//  10. _SettingsPage            — toggle settings
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:orientmobileapplication/features/crm_dasboard/crm%20_dashboard_model.dart';
import 'package:orientmobileapplication/features/crm_dasboard/crm_dasboard_view_model.dart';
import 'package:provider/provider.dart';

// ─────────────────────────────────────────────────────────────────────────────
// DESIGN TOKENS — identical palette to dashboard_view.dart
// ─────────────────────────────────────────────────────────────────────────────

abstract class CC {
  // Brand core
  static const primary = Color(0xFF0F4C75);
  static const accent = Color(0xFF1B9AAA);
  static const accentLight = Color(0xFFE0F4F6);
  static const accentMid = Color(0xFFB2E0E5);

  // Surface
  static const scaffold = Color(0xFFF5F7FA);
  static const surface = Color(0xFFFFFFFF);
  static const surfaceAlt = Color(0xFFF0F3F7);
  static const border = Color(0xFFE2E8EF);

  // Text
  static const textH = Color(0xFF0A1628);
  static const textB = Color(0xFF253347);
  static const textM = Color(0xFF5C6E85);

  // Semantic
  static const green = Color(0xFF1A8754);
  static const greenBg = Color(0xFFEAF7EF);
  static const amber = Color(0xFFD97706);
  static const amberBg = Color(0xFFFFF8EC);
  static const red = Color(0xFFB91C1C);
  static const redBg = Color(0xFFFEECEC);
  static const purple = Color(0xFF6D28D9);
  static const purpleBg = Color(0xFFF0EAFC);

  // Gradient
  static const gStart = Color(0xFF0F4C75);
  static const gEnd = Color(0xFF1B9AAA);

  // Aliases kept for painter / channel compatibility
  static const cyan = accent;
  static const cyanBg = accentLight;
  static const bg = scaffold;
}

// ─────────────────────────────────────────────────────────────────────────────
// ENTRY
// ─────────────────────────────────────────────────────────────────────────────

class CrmDashboardView extends StatelessWidget {
  const CrmDashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => CrmDashboardViewModel(),
      child: const _CrmBody(),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SCAFFOLD
// ─────────────────────────────────────────────────────────────────────────────

class _CrmBody extends StatelessWidget {
  const _CrmBody();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<CrmDashboardViewModel>();

    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: CC.primary,
        statusBarIconBrightness: Brightness.light,
      ),
    );

    final pages = <Widget>[
      const _DashboardPage(),
      const _LeadsPage(),
      const _ConversationsPage(),
      const _SalesTeamPage(),
      const _TasksPage(),
      const _ReportsPage(),
      const _IntegrationsPage(),
      const _SettingsPage(),
    ];

    return Scaffold(
      backgroundColor: CC.scaffold,
      appBar: _CrmAppBar(vm: vm),
      drawer: _CrmDrawer(vm: vm),
      body: IndexedStack(index: vm.selectedIndex, children: pages),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// APP BAR
// ─────────────────────────────────────────────────────────────────────────────

class _CrmAppBar extends StatelessWidget implements PreferredSizeWidget {
  final CrmDashboardViewModel vm;
  const _CrmAppBar({required this.vm});

  static const _titles = [
    'CRM Dashboard',
    'Leads',
    'Conversations',
    'Sales Team',
    'Tasks',
    'Reports & Analytics',
    'Integrations',
    'Settings',
  ];

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight + 1);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      flexibleSpace: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [CC.gStart, CC.gEnd],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
        ),
      ),
      backgroundColor: Colors.transparent,
      elevation: 0,
      systemOverlayStyle: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
      ),
      leading: Builder(
        builder: (ctx) => InkWell(
          onTap: () => Scaffold.of(ctx).openDrawer(),
          borderRadius: BorderRadius.circular(8),
          child: SizedBox(
            width: 56,
            height: 56,
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 2,
                    width: 20,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(1),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Container(
                    height: 2,
                    width: 14,
                    decoration: BoxDecoration(
                      color: Colors.white70,
                      borderRadius: BorderRadius.circular(1),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Container(
                    height: 2,
                    width: 18,
                    decoration: BoxDecoration(
                      color: Colors.white70,
                      borderRadius: BorderRadius.circular(1),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            _titles[vm.selectedIndex],
            style: GoogleFonts.rajdhani(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.5,
            ),
          ),
          Text(
            'CRM — Bircon, Hifri',
            style: GoogleFonts.rajdhani(
              color: Colors.white70,
              fontSize: 12,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.4,
            ),
          ),
        ],
      ),
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 4),
          child: _PeriodDropdown(vm: vm),
        ),
        Padding(
          padding: const EdgeInsets.only(right: 4),
          child: _SalespersonDropdown(vm: vm),
        ),
        Stack(
          clipBehavior: Clip.none,
          children: [
            IconButton(
              icon: const Icon(
                Icons.notifications_outlined,
                color: Colors.white,
                size: 26,
              ),
              onPressed: () {},
            ),
            Positioned(
              right: 10,
              top: 10,
              child: Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: const Color(0xFFFBBF24),
                  shape: BoxShape.circle,
                  border: Border.all(color: CC.gStart, width: 1.5),
                ),
              ),
            ),
          ],
        ),
        Padding(
          padding: const EdgeInsets.only(right: 14),
          child: GestureDetector(
            onTap: () => _showProfile(context),
            child: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.20),
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.white.withOpacity(0.5),
                  width: 1.5,
                ),
              ),
              child: const Center(
                child: Text(
                  'A',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(height: 1, color: Colors.white.withOpacity(0.12)),
      ),
    );
  }

  void _showProfile(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: CC.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: CC.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 24),
            Container(
              width: 68,
              height: 68,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [CC.gStart, CC.gEnd],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
              ),
              child: const Center(
                child: Text(
                  'A',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 14),
            const Text(
              'Admin',
              style: TextStyle(
                color: CC.textH,
                fontSize: 19,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.3,
              ),
            ),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: CC.accentLight,
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Text(
                'Super Admin • CRM',
                style: TextStyle(
                  color: CC.accent,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 28),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: OutlinedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.of(context).pop();
                },
                style: OutlinedButton.styleFrom(
                  foregroundColor: CC.red,
                  side: const BorderSide(color: CC.red, width: 1.5),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                icon: const Icon(Icons.logout_rounded, size: 18),
                label: const Text(
                  'Logout',
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Period Dropdown ───────────────────────────────────────────────────────────

class _PeriodDropdown extends StatelessWidget {
  final CrmDashboardViewModel vm;
  const _PeriodDropdown({required this.vm});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 32,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.3)),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: vm.period,
          dropdownColor: CC.primary,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 11,
            fontWeight: FontWeight.w600,
          ),
          icon: const Icon(
            Icons.keyboard_arrow_down_rounded,
            color: Colors.white,
            size: 16,
          ),
          isDense: true,
          onChanged: (v) => vm.setPeriod(v ?? vm.period),
          items: vm.periods
              .map(
                (p) => DropdownMenuItem(
                  value: p,
                  child: Text(
                    p,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              )
              .toList(),
        ),
      ),
    );
  }
}

// ── Salesperson Dropdown ──────────────────────────────────────────────────────

class _SalespersonDropdown extends StatelessWidget {
  final CrmDashboardViewModel vm;
  const _SalespersonDropdown({required this.vm});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 32,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.3)),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: vm.salesperson,
          dropdownColor: CC.primary,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 11,
            fontWeight: FontWeight.w600,
          ),
          icon: const Icon(
            Icons.keyboard_arrow_down_rounded,
            color: Colors.white,
            size: 16,
          ),
          isDense: true,
          onChanged: (v) => vm.setSalesperson(v ?? vm.salesperson),
          items: vm.salespeople
              .map(
                (s) => DropdownMenuItem(
                  value: s,
                  child: Text(
                    s,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              )
              .toList(),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SIDE DRAWER
// ─────────────────────────────────────────────────────────────────────────────

class _CrmDrawer extends StatelessWidget {
  final CrmDashboardViewModel vm;
  const _CrmDrawer({required this.vm});

  static const _items = [
    (Icons.dashboard_rounded, Icons.dashboard_outlined, 'Dashboard'),
    (Icons.person_search_rounded, Icons.person_search_outlined, 'Leads'),
    (
      Icons.chat_bubble_rounded,
      Icons.chat_bubble_outline_rounded,
      'Conversations',
    ),
    (Icons.groups_rounded, Icons.groups_outlined, 'Sales Team'),
    (Icons.task_alt_rounded, Icons.task_outlined, 'Tasks'),
    (Icons.bar_chart_rounded, Icons.bar_chart_outlined, 'Reports & Analytics'),
    (Icons.power_rounded, Icons.power_outlined, 'Integrations'),
    (Icons.settings_rounded, Icons.settings_outlined, 'Settings'),
  ];

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: CC.surface,
      child: Column(
        children: [
          Container(  
            padding: const EdgeInsets.fromLTRB(20, 56, 20, 24),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [CC.gStart, CC.gEnd],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.20),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.white.withOpacity(0.35)),
                  ),
                  child: const Icon(
                    Icons.hub_rounded,
                    color: Colors.white,
                    size: 26,
                  ),
                ),
                const SizedBox(width: 14),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'CRM',
                      style: GoogleFonts.orbitron(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                      ),
                    ),
                    Text(
                      'DASHBOARD',
                      style: GoogleFonts.orbitron(
                        color: Colors.white70,
                        fontSize: 9,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
              itemCount: _items.length,
              itemBuilder: (_, i) {
                final sel = vm.selectedIndex == i;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: GestureDetector(
                    onTap: () {
                      vm.selectTab(i);
                      Navigator.pop(context);
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 13,
                      ),
                      decoration: BoxDecoration(
                        color: sel ? CC.accentLight : Colors.transparent,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: sel
                              ? CC.accent.withOpacity(0.3)
                              : Colors.transparent,
                        ),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            sel ? _items[i].$1 : _items[i].$2,
                            color: sel ? CC.accent : CC.textM,
                            size: 20,
                          ),
                          const SizedBox(width: 12),
                          Text(
                            _items[i].$3,
                            style: TextStyle(
                              color: sel ? CC.accent : CC.textB,
                              fontSize: 14,
                              fontWeight: sel
                                  ? FontWeight.w700
                                  : FontWeight.w500,
                            ),
                          ),
                          if (i == 1) ...[
                            const Spacer(),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                color: CC.accentLight,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                '${vm.leads.length}',
                                style: const TextStyle(
                                  color: CC.accent,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(
              border: Border(top: BorderSide(color: CC.border)),
            ),
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [CC.gStart, CC.gEnd],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                  ),
                  child: const Center(
                    child: Text(
                      'A',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Admin',
                      style: TextStyle(
                        color: CC.textH,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      'Super Admin',
                      style: TextStyle(color: CC.textM, fontSize: 11),
                    ),
                  ],
                ),
                const Spacer(),
                Icon(
                  Icons.logout_rounded,
                  color: CC.red.withOpacity(0.7),
                  size: 18,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE 1 — DASHBOARD
// ─────────────────────────────────────────────────────────────────────────────

class _DashboardPage extends StatelessWidget {
  const _DashboardPage();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<CrmDashboardViewModel>();

    if (vm.isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: CC.accent, strokeWidth: 2.5),
      );
    }

    return RefreshIndicator(
      onRefresh: vm.refresh,
      color: CC.accent,
      strokeWidth: 2.5,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _CrmHeaderBanner(vm: vm),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _sectionLabel('KPI Overview'),
                  const SizedBox(height: 12),

                  // ─────────────────────────────────────────────────────────
                  // FIX: childAspectRatio changed from 1.6 → 1.35
                  // This gives each cell enough height to fit:
                  //   icon row (26px) + spacing (6px) + value text (~20px)
                  //   + spacing (2px) + label text (~16px) + vertical padding (22px)
                  //   = ~92px needed; 1.35 ratio on ~165px half-width ≈ 122px available
                  // ─────────────────────────────────────────────────────────
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          mainAxisSpacing: 12,
                          crossAxisSpacing: 12,
                          childAspectRatio: 1.35, // FIX: was 1.6
                        ),
                    itemCount: vm.kpis.length,
                    itemBuilder: (_, i) => _KpiCard(kpi: vm.kpis[i]),
                  ),
                  const SizedBox(height: 2),

                  _sectionLabel('Incoming Messages Breakdown'),
                  const SizedBox(height: 12),
                  _ChannelGrid(channels: vm.channels),
                  const SizedBox(height: 2),

                  _sectionLabel('Recent Leads'),
                  const SizedBox(height: 12),
                  _RecentLeadsCard(leads: vm.leads.take(5).toList()),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionLabel(String text) => Row(
    children: [
      Container(
        width: 4,
        height:
            20, // FIX: was 50 — oversized accent bar trimmed to match label height
        decoration: BoxDecoration(
          color: CC.accent,
          borderRadius: BorderRadius.circular(2),
        ),
      ),
      const SizedBox(width: 10),
      Text(
        text,
        style: GoogleFonts.rajdhani(
          color: CC.textH,
          fontSize: 19,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.5,
        ),
      ),
    ],
  );
}

// ── CRM Header Banner ─────────────────────────────────────────────────────────

class _CrmHeaderBanner extends StatelessWidget {
  final CrmDashboardViewModel vm;
  const _CrmHeaderBanner({required this.vm});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 22, 20, 26),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [CC.gStart, CC.gEnd],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(32)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      margin: const EdgeInsets.only(right: 6, top: 1),
                      decoration: const BoxDecoration(
                        color: Color(0xFF4ADEDF),
                        shape: BoxShape.circle,
                      ),
                    ),
                    const Text(
                      'Live',
                      style: TextStyle(
                        color: Color(0xFF4ADEDF),
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                const Text(
                  'Good Morning,',
                  style: TextStyle(color: Colors.white70, fontSize: 14),
                ),
                Text(
                  'CRM Dashboard',
                  style: GoogleFonts.orbitron(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    height: 1.2,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    _pill(
                      Icons.person_search_rounded,
                      '${vm.leads.length} Leads',
                      const Color(0xFFFBBF24),
                    ),
                    const SizedBox(width: 8),
                    _pill(
                      Icons.chat_bubble_outline_rounded,
                      '1,247 Messages',
                      const Color(0xFF4ADEDF),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            width: 68,
            height: 68,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.14),
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.white.withOpacity(0.25),
                width: 1.5,
              ),
            ),
            child: const Icon(Icons.hub_rounded, color: Colors.white, size: 32),
          ),
        ],
      ),
    );
  }

  Widget _pill(IconData icon, String label, Color accent) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: accent.withOpacity(0.4), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: accent, size: 14),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

// ── KPI Card ──────────────────────────────────────────────────────────────────
// FIX: Reduced padding (14→12/10), icon container (32x22→30x22→height kept,
// width→28), icon size (17→15), value font (18→15), spacing (8→6, 3→2),
// label font (12.5→12) to fit within the taller 1.35-ratio cells.

class _KpiCard extends StatelessWidget {
  final CrmKpiModel kpi;
  const _KpiCard({required this.kpi});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(
        12,
        12,
        12,
        10,
      ), // FIX: was (14,14,14,12)
      decoration: BoxDecoration(
        color: CC.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: CC.border),
        boxShadow: [
          BoxShadow(
            color: CC.primary.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Container(
                width: 28, // FIX: was 32
                height: 22, // unchanged
                decoration: BoxDecoration(
                  color: kpi.color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  kpi.icon,
                  color: kpi.color,
                  size: 15,
                ), // FIX: was 17
              ),
              const Spacer(),
              Flexible(
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 6, // FIX: was 7
                    vertical: 2, // FIX: was 3
                  ),
                  decoration: BoxDecoration(
                    color: kpi.trendUp ? CC.greenBg : CC.redBg,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    '${kpi.trendUp ? '↑' : '↓'} ${kpi.trend}',
                    style: TextStyle(
                      color: kpi.trendUp ? CC.green : CC.red,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6), // FIX: was 8
          Text(
            kpi.value,
            style: GoogleFonts.orbitron(
              color: CC.textH,
              fontSize: 15, // FIX: was 18
              fontWeight: FontWeight.w800,
              letterSpacing: -0.3,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 2), // FIX: was 3
          Text(
            kpi.label,
            style: GoogleFonts.rajdhani(
              color: CC.textM,
              fontSize: 14, // FIX: was 12.5
              fontWeight: FontWeight.w700,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

// ── Channel Grid ──────────────────────────────────────────────────────────────

class _ChannelGrid extends StatelessWidget {
  final List<CrmChannelModel> channels;
  const _ChannelGrid({required this.channels});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 2.2,
      ),
      itemCount: channels.length,
      itemBuilder: (_, i) => _ChannelCard(channel: channels[i]),
    );
  }
}

class _ChannelCard extends StatelessWidget {
  final CrmChannelModel channel;
  const _ChannelCard({required this.channel});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: CC.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: CC.border),
        boxShadow: [
          BoxShadow(
            color: CC.primary.withOpacity(0.04),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: channel.color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(channel.icon, color: channel.color, size: 17),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  channel.value,
                  style: GoogleFonts.orbitron(
                    color: CC.textH,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                Text(
                  channel.label,
                  style: const TextStyle(
                    color: CC.textM,
                    fontSize: 10,
                    fontWeight: FontWeight.w500,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          Text(
            '↑ ${channel.trend}',
            style: TextStyle(
              color: channel.trendUp ? CC.green : CC.red,
              fontSize: 9,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

// ── Recent Leads Card ─────────────────────────────────────────────────────────

class _RecentLeadsCard extends StatelessWidget {
  final List<CrmLeadModel> leads;
  const _RecentLeadsCard({required this.leads});

  @override
  Widget build(BuildContext context) {
    return _SurfaceCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              color: CC.accentLight,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              children: [
                _th('S.No', flex: 1),
                _th('Lead Number', flex: 3),
                _th('Customer Name', flex: 3),
                _th('Source', flex: 2),
                _th('Status', flex: 2),
              ],
            ),
          ),
          const SizedBox(height: 8),
          ...leads.asMap().entries.map(
            (e) => _LeadRow(lead: e.value, index: e.key),
          ),
        ],
      ),
    );
  }

  Widget _th(String text, {int flex = 2}) => Expanded(
    flex: flex,
    child: Text(
      text,
      style: GoogleFonts.rajdhani(
        color: CC.accent,
        fontSize: 11,
        fontWeight: FontWeight.w800,
        letterSpacing: 0.4,
      ),
    ),
  );
}

class _LeadRow extends StatelessWidget {
  final CrmLeadModel lead;
  final int index;
  const _LeadRow({required this.lead, required this.index});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      decoration: BoxDecoration(
        color: index.isEven ? CC.surfaceAlt : CC.surface,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 1,
            child: Text(
              '${lead.sno}',
              style: const TextStyle(color: CC.textM, fontSize: 12),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(
              lead.leadNumber,
              style: const TextStyle(
                color: CC.accent,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(
              lead.customerName,
              style: const TextStyle(color: CC.textB, fontSize: 12),
            ),
          ),
          Expanded(
            flex: 2,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: lead.sourceColor.withOpacity(0.12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                lead.source,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: lead.sourceColor,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: lead.statusColor.withOpacity(0.12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                lead.status,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: lead.statusColor,
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE 2 — LEADS
// ─────────────────────────────────────────────────────────────────────────────

class _LeadsPage extends StatelessWidget {
  const _LeadsPage();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<CrmDashboardViewModel>();
    final leads = vm.filteredLeads;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
          child: TextField(
            style: const TextStyle(color: CC.textH, fontSize: 13),
            decoration: InputDecoration(
              hintText: 'Search leads...',
              hintStyle: const TextStyle(color: CC.textM, fontSize: 13),
              prefixIcon: const Icon(
                Icons.search_rounded,
                color: CC.textM,
                size: 20,
              ),
              filled: true,
              fillColor: CC.surface,
              contentPadding: const EdgeInsets.symmetric(vertical: 12),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: CC.border),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: CC.border),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: CC.accent, width: 1.5),
              ),
            ),
            onChanged: vm.updateSearch,
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: CC.accentLight,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: CC.accent.withOpacity(0.3)),
                ),
                child: Text(
                  '${leads.length} Leads',
                  style: const TextStyle(
                    color: CC.accent,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: leads.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (_, i) => _LeadDetailCard(lead: leads[i]),
          ),
        ),
      ],
    );
  }
}

class _LeadDetailCard extends StatelessWidget {
  final CrmLeadModel lead;
  const _LeadDetailCard({required this.lead});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: CC.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: CC.border),
        boxShadow: [
          BoxShadow(
            color: CC.primary.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                lead.leadNumber,
                style: const TextStyle(
                  color: CC.accent,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: lead.statusColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  lead.status,
                  style: TextStyle(
                    color: lead.statusColor,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            lead.customerName,
            style: const TextStyle(
              color: CC.textH,
              fontSize: 15,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              const Icon(Icons.phone_outlined, color: CC.textM, size: 13),
              const SizedBox(width: 5),
              Text(
                lead.phone,
                style: const TextStyle(color: CC.textB, fontSize: 12),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              const Icon(Icons.email_outlined, color: CC.textM, size: 13),
              const SizedBox(width: 5),
              Text(
                lead.email,
                style: const TextStyle(color: CC.textB, fontSize: 12),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                decoration: BoxDecoration(
                  color: lead.sourceColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  lead.source,
                  style: TextStyle(
                    color: lead.sourceColor,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              const Icon(
                Icons.person_outline_rounded,
                color: CC.textM,
                size: 13,
              ),
              const SizedBox(width: 4),
              Text(
                lead.assignedTo,
                style: const TextStyle(color: CC.textM, fontSize: 11),
              ),
              const Spacer(),
              const Icon(Icons.access_time_rounded, color: CC.textM, size: 11),
              const SizedBox(width: 4),
              Text(
                lead.lastActivity,
                style: const TextStyle(color: CC.textM, fontSize: 10),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE 3 — CONVERSATIONS
// ─────────────────────────────────────────────────────────────────────────────

class _ConversationsPage extends StatelessWidget {
  const _ConversationsPage();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<CrmDashboardViewModel>();
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: vm.conversations.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (_, i) => _ConversationCard(conv: vm.conversations[i]),
    );
  }
}

class _ConversationCard extends StatelessWidget {
  final ConversationModel conv;
  const _ConversationCard({required this.conv});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: CC.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: conv.unread > 0 ? CC.accent.withOpacity(0.3) : CC.border,
          width: conv.unread > 0 ? 1.5 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: CC.primary.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [conv.channelColor.withOpacity(0.8), conv.channelColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                conv.customerName[0],
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      conv.customerName,
                      style: const TextStyle(
                        color: CC.textH,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      conv.time,
                      style: const TextStyle(color: CC.textM, fontSize: 11),
                    ),
                  ],
                ),
                const SizedBox(height: 5),
                Text(
                  conv.lastMessage,
                  style: const TextStyle(
                    color: CC.textM,
                    fontSize: 12,
                    height: 1.4,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: conv.channelColor.withOpacity(0.10),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        conv.channel,
                        style: TextStyle(
                          color: conv.channelColor,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    const Spacer(),
                    if (conv.unread > 0)
                      Container(
                        width: 20,
                        height: 20,
                        decoration: const BoxDecoration(
                          color: CC.accent,
                          shape: BoxShape.circle,
                        ),
                        child: Center(
                          child: Text(
                            '${conv.unread}',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE 4 — SALES TEAM
// ─────────────────────────────────────────────────────────────────────────────

class _SalesTeamPage extends StatelessWidget {
  const _SalesTeamPage();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<CrmDashboardViewModel>();
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: vm.salesTeam.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (_, i) {
        final m = vm.salesTeam[i];
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: CC.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: CC.border),
            boxShadow: [
              BoxShadow(
                color: CC.primary.withOpacity(0.05),
                blurRadius: 10,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 46,
                    height: 46,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [CC.gStart, CC.gEnd],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Text(
                        m.name[0],
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        m.name,
                        style: const TextStyle(
                          color: CC.textH,
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        m.role,
                        style: const TextStyle(color: CC.textM, fontSize: 12),
                      ),
                    ],
                  ),
                  const Spacer(),
                  Text(
                    m.revenue,
                    style: GoogleFonts.orbitron(
                      color: CC.green,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  _statPill('Leads', '${m.leadsHandled}', CC.accent),
                  const SizedBox(width: 8),
                  _statPill('Won', '${m.wonDeals}', CC.green),
                  const SizedBox(width: 8),
                  _statPill(
                    'Win Rate',
                    '${(m.winRate * 100).round()}%',
                    CC.purple,
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: m.winRate,
                  backgroundColor: CC.border,
                  valueColor: const AlwaysStoppedAnimation<Color>(CC.accent),
                  minHeight: 6,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _statPill(String label, String value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.10),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          children: [
            Text(
              value,
              style: TextStyle(
                color: color,
                fontSize: 15,
                fontWeight: FontWeight.w800,
              ),
            ),
            Text(label, style: const TextStyle(color: CC.textM, fontSize: 10)),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE 5 — TASKS
// ─────────────────────────────────────────────────────────────────────────────

class _TasksPage extends StatelessWidget {
  const _TasksPage();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<CrmDashboardViewModel>();
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: vm.tasks.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (_, i) {
        final t = vm.tasks[i];
        return GestureDetector(
          onTap: () => vm.toggleTask(i),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: t.isDone ? CC.surfaceAlt : CC.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: t.isDone ? CC.border : t.priorityColor.withOpacity(0.25),
              ),
              boxShadow: [
                BoxShadow(
                  color: CC.primary.withOpacity(0.04),
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 22,
                  height: 22,
                  decoration: BoxDecoration(
                    color: t.isDone ? CC.green : Colors.transparent,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: t.isDone ? CC.green : CC.textM,
                      width: 1.5,
                    ),
                  ),
                  child: t.isDone
                      ? const Icon(
                          Icons.check_rounded,
                          color: Colors.white,
                          size: 13,
                        )
                      : null,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        t.title,
                        style: TextStyle(
                          color: t.isDone ? CC.textM : CC.textH,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          decoration: t.isDone
                              ? TextDecoration.lineThrough
                              : null,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          const Icon(
                            Icons.person_outline,
                            color: CC.textM,
                            size: 12,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            t.assignedTo,
                            style: const TextStyle(
                              color: CC.textM,
                              fontSize: 11,
                            ),
                          ),
                          const SizedBox(width: 10),
                          const Icon(
                            Icons.calendar_today_outlined,
                            color: CC.textM,
                            size: 11,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            t.dueDate,
                            style: const TextStyle(
                              color: CC.textM,
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: t.priorityColor.withOpacity(0.10),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    t.priority,
                    style: TextStyle(
                      color: t.priorityColor,
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE 6 — REPORTS & ANALYTICS
// ─────────────────────────────────────────────────────────────────────────────

class _ReportsPage extends StatelessWidget {
  const _ReportsPage();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<CrmDashboardViewModel>();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _SurfaceCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const _CardTitle('Conversion Trends'),
                const SizedBox(height: 16),
                SizedBox(
                  height: 130,
                  child: CustomPaint(
                    size: Size.infinite,
                    painter: _ConversionTrendPainter(data: vm.conversionTrend),
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: vm.conversionTrend
                      .map(
                        (p) => Text(
                          p.month,
                          style: const TextStyle(color: CC.textM, fontSize: 10),
                        ),
                      )
                      .toList(),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    _legendDot(CC.green, 'Won'),
                    const SizedBox(width: 12),
                    _legendDot(CC.red, 'Lost'),
                    const SizedBox(width: 12),
                    _legendDot(CC.accent, 'Active'),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _SurfaceCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const _CardTitle('Lead Sources'),
                      const SizedBox(height: 12),
                      SizedBox(
                        height: 140,
                        child: CustomPaint(
                          size: Size.infinite,
                          painter: _PieChartPainter(slices: vm.leadSources),
                        ),
                      ),
                      const SizedBox(height: 10),
                      ...vm.leadSources
                          .take(4)
                          .map(
                            (s) => Padding(
                              padding: const EdgeInsets.only(bottom: 4),
                              child: Row(
                                children: [
                                  Container(
                                    width: 8,
                                    height: 8,
                                    decoration: BoxDecoration(
                                      color: s.color,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  Expanded(
                                    child: Text(
                                      s.label,
                                      style: const TextStyle(
                                        color: CC.textM,
                                        fontSize: 10,
                                      ),
                                    ),
                                  ),
                                  Text(
                                    '${s.percent.round()}%',
                                    style: TextStyle(
                                      color: s.color,
                                      fontSize: 10,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _SurfaceCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const _CardTitle('Salesperson\nPerformance'),
                      const SizedBox(height: 12),
                      SizedBox(
                        height: 140,
                        child: CustomPaint(
                          size: Size.infinite,
                          painter: _SalespersonBarPainter(
                            data: vm.salespersonPerf,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          _legendRect(CC.accent, 'Leads'),
                          const SizedBox(width: 8),
                          _legendRect(CC.green, 'Won'),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _SurfaceCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const _CardTitle('Response Time Analysis'),
                const SizedBox(height: 16),
                SizedBox(
                  height: 120,
                  child: CustomPaint(
                    size: Size.infinite,
                    painter: _ResponseTimePainter(data: vm.responseTimeBuckets),
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: vm.responseTimeBuckets
                      .map(
                        (b) => Text(
                          b.label,
                          style: const TextStyle(color: CC.textM, fontSize: 9),
                        ),
                      )
                      .toList(),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _SurfaceCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const _CardTitle('Key Metrics'),
                const SizedBox(height: 12),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 10,
                    crossAxisSpacing: 10,
                    childAspectRatio: 2.2,
                  ),
                  itemCount: vm.keyMetrics.length,
                  itemBuilder: (_, i) =>
                      _KeyMetricCard(metric: vm.keyMetrics[i]),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _legendDot(Color color, String label) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Container(
        width: 8,
        height: 8,
        decoration: BoxDecoration(color: color, shape: BoxShape.circle),
      ),
      const SizedBox(width: 4),
      Text(label, style: const TextStyle(color: CC.textM, fontSize: 10)),
    ],
  );

  Widget _legendRect(Color color, String label) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Container(
        width: 10,
        height: 8,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(2),
        ),
      ),
      const SizedBox(width: 4),
      Text(label, style: const TextStyle(color: CC.textM, fontSize: 10)),
    ],
  );
}

class _KeyMetricCard extends StatelessWidget {
  final CrmKeyMetric metric;
  const _KeyMetricCard({required this.metric});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: metric.color.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: metric.color.withOpacity(0.15)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            metric.label,
            style: const TextStyle(color: CC.textM, fontSize: 10),
          ),
          const SizedBox(height: 4),
          Text(
            metric.value,
            style: GoogleFonts.orbitron(
              color: metric.color,
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            metric.sub,
            style: TextStyle(color: metric.up ? CC.green : CC.red, fontSize: 9),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE 7 — INTEGRATIONS
// ─────────────────────────────────────────────────────────────────────────────

class _IntegrationsPage extends StatelessWidget {
  const _IntegrationsPage();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<CrmDashboardViewModel>();
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 4,
                height: 20,
                decoration: BoxDecoration(
                  color: CC.accent,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 10),
              Text(
                'Integrations',
                style: GoogleFonts.rajdhani(
                  color: CC.textH,
                  fontSize: 19,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.8,
            ),
            itemCount: vm.integrations.length,
            itemBuilder: (_, i) =>
                _IntegrationCard(integration: vm.integrations[i]),
          ),
        ],
      ),
    );
  }
}

class _IntegrationCard extends StatelessWidget {
  final IntegrationModel integration;
  const _IntegrationCard({required this.integration});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: CC.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: integration.connected
              ? integration.color.withOpacity(0.25)
              : CC.border,
        ),
        boxShadow: [
          BoxShadow(
            color: CC.primary.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Icon(integration.icon, color: integration.color, size: 24),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                integration.name,
                style: const TextStyle(
                  color: CC.textH,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              Row(
                children: [
                  const Text(
                    'Status: ',
                    style: TextStyle(color: CC.textM, fontSize: 10),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 7,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: integration.connected ? CC.greenBg : CC.redBg,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      integration.connected ? 'Connected' : 'Cancelled',
                      style: TextStyle(
                        color: integration.connected ? CC.green : CC.red,
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE 8 — SETTINGS
// ─────────────────────────────────────────────────────────────────────────────

class _SettingsPage extends StatelessWidget {
  const _SettingsPage();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<CrmDashboardViewModel>();

    final items = [
      (
        'Push Notifications',
        'Receive alerts for new leads and messages',
        Icons.notifications_outlined,
        vm.notificationsEnabled,
        vm.toggleNotifications,
      ),
      (
        'Dark Mode',
        'Use dark theme across the application',
        Icons.dark_mode_outlined,
        vm.darkMode,
        vm.toggleDarkMode,
      ),
      (
        'Auto Assign Leads',
        'Automatically assign incoming leads to team',
        Icons.auto_awesome_outlined,
        vm.autoAssign,
        vm.toggleAutoAssign,
      ),
    ];

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 4,
                height: 20,
                decoration: BoxDecoration(
                  color: CC.accent,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 10),
              Text(
                'Settings',
                style: GoogleFonts.rajdhani(
                  color: CC.textH,
                  fontSize: 19,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...items.map(
            (item) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 14,
                ),
                decoration: BoxDecoration(
                  color: CC.surface,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: CC.border),
                  boxShadow: [
                    BoxShadow(
                      color: CC.primary.withOpacity(0.04),
                      blurRadius: 6,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        color: CC.accentLight,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(item.$3, color: CC.accent, size: 20),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item.$1,
                            style: const TextStyle(
                              color: CC.textH,
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Text(
                            item.$2,
                            style: const TextStyle(
                              color: CC.textM,
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Switch(
                      value: item.$4,
                      onChanged: (_) => item.$5(),
                      activeColor: CC.accent,
                      activeTrackColor: CC.accentLight,
                      inactiveThumbColor: CC.textM,
                      inactiveTrackColor: CC.border,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// CUSTOM PAINTERS
// ─────────────────────────────────────────────────────────────────────────────

class _ConversionTrendPainter extends CustomPainter {
  final List<CrmTrendPoint> data;
  const _ConversionTrendPainter({required this.data});

  @override
  void paint(Canvas canvas, Size size) {
    final wonVals = data.map((d) => d.won).toList();
    final lostVals = data.map((d) => d.lost).toList();
    final activeVals = data.map((d) => d.active).toList();
    final allVals = [...wonVals, ...lostVals, ...activeVals];
    final maxVal = allVals.reduce(math.max);

    void drawLine(List<double> values, Color color) {
      final path = Path();
      final fill = Path();
      for (var i = 0; i < values.length; i++) {
        final x = size.width * i / (values.length - 1);
        final y = size.height * (1 - values[i] / maxVal);
        if (i == 0) {
          path.moveTo(x, y);
          fill.moveTo(x, y);
        } else {
          path.lineTo(x, y);
          fill.lineTo(x, y);
        }
      }
      fill
        ..lineTo(size.width, size.height)
        ..lineTo(0, size.height)
        ..close();

      canvas.drawPath(
        fill,
        Paint()
          ..shader = LinearGradient(
            colors: [color.withOpacity(0.15), color.withOpacity(0.0)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
          ..style = PaintingStyle.fill,
      );

      canvas.drawPath(
        path,
        Paint()
          ..color = color
          ..strokeWidth = 2
          ..style = PaintingStyle.stroke
          ..strokeCap = StrokeCap.round,
      );

      for (var i = 0; i < values.length; i++) {
        final x = size.width * i / (values.length - 1);
        final y = size.height * (1 - values[i] / maxVal);
        canvas.drawCircle(Offset(x, y), 3.5, Paint()..color = color);
        canvas.drawCircle(Offset(x, y), 1.5, Paint()..color = Colors.white);
      }
    }

    drawLine(activeVals, CC.accent);
    drawLine(wonVals, CC.green);
    drawLine(lostVals, CC.red);
  }

  @override
  bool shouldRepaint(_) => false;
}

class _PieChartPainter extends CustomPainter {
  final List<LeadSourceSlice> slices;
  const _PieChartPainter({required this.slices});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = math.min(size.width, size.height) / 2 - 10;
    double startAngle = -math.pi / 2;

    for (final slice in slices) {
      final sweep = 2 * math.pi * (slice.percent / 100);
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweep,
        false,
        Paint()
          ..color = slice.color
          ..strokeWidth = 18
          ..style = PaintingStyle.stroke,
      );
      startAngle += sweep;
    }

    final tp = TextPainter(
      text: TextSpan(
        children: [
          TextSpan(
            text: '1,247\n',
            style: GoogleFonts.orbitron(
              color: CC.textH,
              fontSize: 12,
              fontWeight: FontWeight.w900,
            ),
          ),
          const TextSpan(
            text: 'Total',
            style: TextStyle(color: CC.textM, fontSize: 9),
          ),
        ],
      ),
      textAlign: TextAlign.center,
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(
      canvas,
      Offset(center.dx - tp.width / 2, center.dy - tp.height / 2),
    );
  }

  @override
  bool shouldRepaint(_) => false;
}

class _SalespersonBarPainter extends CustomPainter {
  final List<SalespersonPerf> data;
  const _SalespersonBarPainter({required this.data});

  @override
  void paint(Canvas canvas, Size size) {
    final maxVal = data.map((d) => d.leads).reduce(math.max);
    const bottomPad = 16.0;
    final chartH = size.height - bottomPad;
    final groupW = size.width / data.length;
    final barW = groupW * 0.3;
    const gap = 3.0;

    for (var i = 0; i < data.length; i++) {
      final gx = groupW * i + groupW / 2;
      final lh = chartH * data[i].leads / maxVal;
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(gx - barW - gap, chartH - lh, barW, lh),
          const Radius.circular(4),
        ),
        Paint()
          ..shader = const LinearGradient(
            colors: [CC.gEnd, CC.gStart],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ).createShader(Rect.fromLTWH(0, 0, barW, 200)),
      );

      final wh = chartH * data[i].won / maxVal;
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(gx + gap, chartH - wh, barW, wh),
          const Radius.circular(4),
        ),
        Paint()..color = CC.green.withOpacity(0.8),
      );

      final nameShort = data[i].name.split(' ').first;
      final tp = TextPainter(
        text: TextSpan(
          text: nameShort,
          style: const TextStyle(color: CC.textM, fontSize: 9),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(gx - tp.width / 2, size.height - tp.height));
    }
  }

  @override
  bool shouldRepaint(_) => false;
}

class _ResponseTimePainter extends CustomPainter {
  final List<ResponseTimeBucket> data;
  const _ResponseTimePainter({required this.data});

  @override
  void paint(Canvas canvas, Size size) {
    final maxVal = data.map((d) => d.count).reduce(math.max);
    const bottomPad = 14.0;
    final chartH = size.height - bottomPad;
    final barW = size.width / data.length * 0.55;
    final spacing = size.width / data.length;

    for (var i = 0; i < data.length; i++) {
      final x = spacing * i + spacing / 2 - barW / 2;
      final h = chartH * data[i].count / maxVal;
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x, chartH - h, barW, h),
          const Radius.circular(4),
        ),
        Paint()
          ..shader = const LinearGradient(
            colors: [CC.gEnd, CC.accentMid],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ).createShader(Rect.fromLTWH(x, 0, barW, h)),
      );
    }
  }

  @override
  bool shouldRepaint(_) => false;
}

// ─────────────────────────────────────────────────────────────────────────────
// SHARED WIDGETS
// ─────────────────────────────────────────────────────────────────────────────

class _SurfaceCard extends StatelessWidget {
  final Widget child;
  const _SurfaceCard({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: CC.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: CC.border),
        boxShadow: [
          BoxShadow(
            color: CC.primary.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: child,
    );
  }
}

class _CardTitle extends StatelessWidget {
  final String text;
  const _CardTitle(this.text);

  @override
  Widget build(BuildContext context) => Text(
    text,
    style: GoogleFonts.rajdhani(
      color: CC.textH,
      fontSize: 16,
      fontWeight: FontWeight.w700,
      letterSpacing: 0.3,
    ),
  );
}
