// ─────────────────────────────────────────────────────────────────────────────
// crm_dashboard_viewmodel.dart
// lib/features/crm/viewmodel/crm_dashboard_viewmodel.dart
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:orientmobileapplication/features/crm_dasboard/crm%20_dashboard_model.dart';

class CrmDashboardViewModel extends ChangeNotifier {
  // ── Tab ──────────────────────────────────────────────────────────────────
  int _selectedIndex = 0;
  int get selectedIndex => _selectedIndex;

  void selectTab(int i) {
    _selectedIndex = i;
    notifyListeners();
  }

  // ── Period / Salesperson filter ──────────────────────────────────────────
  String _period = 'Today';
  String get period => _period;
  final List<String> periods = ['Today', 'This Week', 'This Month', 'This Year'];

  void setPeriod(String p) {
    _period = p;
    notifyListeners();
  }

  String _salesperson = 'All Salespeople';
  String get salesperson => _salesperson;
  final List<String> salespeople = [
    'All Salespeople',
    'John Doe',
    'Sarah Smith',
    'Mike Johnson',
    'Joe Brown',
  ];

  void setSalesperson(String s) {
    _salesperson = s;
    notifyListeners();
  }

  // ── Loading ───────────────────────────────────────────────────────────────
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  Future<void> refresh() async {
    _isLoading = true;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 900));
    _isLoading = false;
    notifyListeners();
  }

  // ── Search ────────────────────────────────────────────────────────────────
  String _searchQuery = '';
  String get searchQuery => _searchQuery;

  void updateSearch(String q) {
    _searchQuery = q;
    notifyListeners();
  }

  // ── KPIs ─────────────────────────────────────────────────────────────────
  List<CrmKpiModel> get kpis => const [
        CrmKpiModel(
          label: 'Total Messages',
          value: '1247',
          icon: Icons.chat_bubble_outline_rounded,
          color: Color(0xFF00D4FF),
          bgColor: Color(0xFF001F2E),
          trend: '12%',
          trendUp: true,
        ),
        CrmKpiModel(
          label: 'Active Leads',
          value: '3',
          icon: Icons.person_search_outlined,
          color: Color(0xFF7C3AFF),
          bgColor: Color(0xFF1A0A2E),
          trend: '8%',
          trendUp: true,
        ),
        CrmKpiModel(
          label: 'Unanswered',
          value: '2',
          icon: Icons.mark_chat_unread_outlined,
          color: Color(0xFFD97706),
          bgColor: Color(0xFF2A1A00),
          trend: '5%',
          trendUp: false,
        ),
        CrmKpiModel(
          label: 'Won Leads',
          value: '3',
          icon: Icons.emoji_events_outlined,
          color: Color(0xFF00C896),
          bgColor: Color(0xFF002A1E),
          trend: '15%',
          trendUp: true,
        ),
        CrmKpiModel(
          label: 'Lost Leads',
          value: '2',
          icon: Icons.trending_down_rounded,
          color: Color(0xFFEF4444),
          bgColor: Color(0xFF2A0A0A),
          trend: '3%',
          trendUp: false,
        ),
        CrmKpiModel(
          label: 'No Response',
          value: '2',
          icon: Icons.notifications_off_outlined,
          color: Color(0xFF8B5CF6),
          bgColor: Color(0xFF1A0A2E),
          trend: '2%',
          trendUp: true,
        ),
      ];

  // ── Channels ──────────────────────────────────────────────────────────────
  List<CrmChannelModel> get channels => const [
        CrmChannelModel(
          label: 'WhatsApp Lite',
          icon: Icons.chat_rounded,
          color: Color(0xFF25D366),
          value: '487',
          trend: '15%',
          trendUp: true,
        ),
        CrmChannelModel(
          label: 'WhatsApp Cloud',
          icon: Icons.cloud_queue_rounded,
          color: Color(0xFF00D4FF),
          value: '324',
          trend: '22%',
          trendUp: true,
        ),
        CrmChannelModel(
          label: 'Instagram',
          icon: Icons.camera_alt_outlined,
          color: Color(0xFFE1306C),
          value: '156',
          trend: '8%',
          trendUp: true,
        ),
        CrmChannelModel(
          label: 'SMS',
          icon: Icons.sms_outlined,
          color: Color(0xFF7C3AFF),
          value: '98',
          trend: '3%',
          trendUp: false,
        ),
        CrmChannelModel(
          label: 'Live Chat',
          icon: Icons.support_agent_rounded,
          color: Color(0xFF00C896),
          value: '82',
          trend: '12%',
          trendUp: true,
        ),
        CrmChannelModel(
          label: 'Google Ads',
          icon: Icons.ads_click_rounded,
          color: Color(0xFFFBBC04),
          value: '54',
          trend: '18%',
          trendUp: true,
        ),
        CrmChannelModel(
          label: 'Website',
          icon: Icons.language_rounded,
          color: Color(0xFF00D4FF),
          value: '36',
          trend: '5%',
          trendUp: true,
        ),
        CrmChannelModel(
          label: 'Email',
          icon: Icons.email_outlined,
          color: Color(0xFFEF4444),
          value: '10',
          trend: '2%',
          trendUp: false,
        ),
      ];

  // ── Recent Leads ──────────────────────────────────────────────────────────
  List<CrmLeadModel> get leads => [
        const CrmLeadModel(
          sno: 1,
          leadNumber: 'LEAD#A1023',
          customerName: 'James Anderson',
          phone: '+1 (555) 123-4567',
          email: 'james.anderson@email.com',
          source: 'WhatsApp',
          sourceColor: Color(0xFF25D366),
          assignedTo: 'John Doe',
          status: 'ACTIVE',
          statusColor: Color(0xFF00C896),
          lastActivity: '2026-04-29 14:23',
        ),
        const CrmLeadModel(
          sno: 2,
          leadNumber: 'LEAD#A1024',
          customerName: 'Emily Chen',
          phone: '+1 (555) 234-5678',
          email: 'emily.chen@email.com',
          source: 'Instagram',
          sourceColor: Color(0xFFE1306C),
          assignedTo: 'Sarah Smith',
          status: 'WON',
          statusColor: Color(0xFF00C896),
          lastActivity: '2026-04-29 13:45',
        ),
        const CrmLeadModel(
          sno: 3,
          leadNumber: 'LEAD#A1025',
          customerName: 'Michael Roberts',
          phone: '+1 (555) 345-6789',
          email: 'michael.roberts@email.com',
          source: 'Google Ads',
          sourceColor: Color(0xFFFBBC04),
          assignedTo: 'Mike Johnson',
          status: 'ACTIVE',
          statusColor: Color(0xFF00C896),
          lastActivity: '2026-04-29 12:15',
        ),
        const CrmLeadModel(
          sno: 4,
          leadNumber: 'LEAD#A1026',
          customerName: 'Sarah Williams',
          phone: '+1 (555) 456-7890',
          email: 'sarah.williams@email.com',
          source: 'Website',
          sourceColor: Color(0xFF00D4FF),
          assignedTo: 'John Doe',
          status: 'UNANSWERED',
          statusColor: Color(0xFFD97706),
          lastActivity: '2026-04-28 18:30',
        ),
        const CrmLeadModel(
          sno: 5,
          leadNumber: 'LEAD#A1027',
          customerName: 'David Martinez',
          phone: '+1 (555) 567-8901',
          email: 'david.martinez@email.com',
          source: 'SMS',
          sourceColor: Color(0xFF7C3AFF),
          assignedTo: 'Sarah Smith',
          status: 'LOST',
          statusColor: Color(0xFFEF4444),
          lastActivity: '2026-04-27 09:45',
        ),
      ];

  List<CrmLeadModel> get filteredLeads {
    if (_searchQuery.isEmpty) return leads;
    final q = _searchQuery.toLowerCase();
    return leads
        .where((l) =>
            l.customerName.toLowerCase().contains(q) ||
            l.leadNumber.toLowerCase().contains(q) ||
            l.source.toLowerCase().contains(q))
        .toList();
  }

  // ── Conversion Trend ──────────────────────────────────────────────────────
  List<CrmTrendPoint> get conversionTrend => const [
        CrmTrendPoint('Jan', 20, 10, 40),
        CrmTrendPoint('Feb', 28, 8, 45),
        CrmTrendPoint('Mar', 25, 12, 38),
        CrmTrendPoint('Apr', 35, 9, 50),
        CrmTrendPoint('May', 30, 7, 42),
        CrmTrendPoint('Jun', 45, 11, 55),
        CrmTrendPoint('Jul', 40, 8, 48),
      ];

  // ── Salesperson Performance ───────────────────────────────────────────────
  List<SalespersonPerf> get salespersonPerf => const [
        SalespersonPerf('John Doe', 125, 85),
        SalespersonPerf('Sarah Smith', 98, 62),
        SalespersonPerf('Mike Johnson', 110, 74),
        SalespersonPerf('Joe Brown', 75, 48),
      ];

  // ── Response Time ─────────────────────────────────────────────────────────
  List<ResponseTimeBucket> get responseTimeBuckets => const [
        ResponseTimeBucket('0-5 min', 340),
        ResponseTimeBucket('5-15 min', 280),
        ResponseTimeBucket('15-30 min', 180),
        ResponseTimeBucket('30-60 min', 95),
        ResponseTimeBucket('> 1hr', 110),
      ];

  // ── Lead Source Distribution ──────────────────────────────────────────────
  List<LeadSourceSlice> get leadSources => const [
        LeadSourceSlice('WhatsApp', 51, Color(0xFF25D366)),
        LeadSourceSlice('Instagram', 17, Color(0xFFE1306C)),
        LeadSourceSlice('SMS', 10, Color(0xFF7C3AFF)),
        LeadSourceSlice('Google Ads', 8, Color(0xFFFBBC04)),
        LeadSourceSlice('Website', 6, Color(0xFF00D4FF)),
        LeadSourceSlice('Other', 8, Color(0xFF64748B)),
      ];

  // ── Key Metrics ───────────────────────────────────────────────────────────
  List<CrmKeyMetric> get keyMetrics => const [
        CrmKeyMetric(
          label: 'Win Rate',
          value: '63.8%',
          sub: '↑ 0.3% from last month',
          up: true,
          color: Color(0xFF00C896),
        ),
        CrmKeyMetric(
          label: 'Avg Response Time',
          value: '8.4m',
          sub: '↓ 2.1m from last month',
          up: false,
          color: Color(0xFF00D4FF),
        ),
        CrmKeyMetric(
          label: 'Customer Satisfaction',
          value: '4.7/5',
          sub: '↑ 0.3 from last month',
          up: true,
          color: Color(0xFF8B5CF6),
        ),
        CrmKeyMetric(
          label: 'ROI from Ads',
          value: '342%',
          sub: '↑ 28% from last month',
          up: true,
          color: Color(0xFFD97706),
        ),
      ];

  // ── Integrations ──────────────────────────────────────────────────────────
  List<IntegrationModel> get integrations => const [
        IntegrationModel(
          name: 'WhatsApp Business API',
          icon: Icons.chat_rounded,
          color: Color(0xFF25D366),
          connected: true,
        ),
        IntegrationModel(
          name: 'Instagram',
          icon: Icons.camera_alt_outlined,
          color: Color(0xFFE1306C),
          connected: false,
        ),
        IntegrationModel(
          name: 'Facebook Messenger',
          icon: Icons.facebook_rounded,
          color: Color(0xFF1877F2),
          connected: true,
        ),
        IntegrationModel(
          name: 'Google Ads',
          icon: Icons.ads_click_rounded,
          color: Color(0xFFFBBC04),
          connected: true,
        ),
        IntegrationModel(
          name: 'Website Chat',
          icon: Icons.language_rounded,
          color: Color(0xFF00D4FF),
          connected: false,
        ),
        IntegrationModel(
          name: 'SMS Provider',
          icon: Icons.sms_outlined,
          color: Color(0xFF7C3AFF),
          connected: true,
        ),
      ];

  // ── Tasks ─────────────────────────────────────────────────────────────────
  final List<CrmTaskModel> _tasks = [
    CrmTaskModel(
      id: '1',
      title: 'Follow up with James Anderson',
      assignedTo: 'John Doe',
      dueDate: '2026-04-30',
      priority: 'HIGH',
      priorityColor: const Color(0xFFEF4444),
    ),
    CrmTaskModel(
      id: '2',
      title: 'Send proposal to Emily Chen',
      assignedTo: 'Sarah Smith',
      dueDate: '2026-05-01',
      priority: 'MEDIUM',
      priorityColor: const Color(0xFFD97706),
    ),
    CrmTaskModel(
      id: '3',
      title: 'Update CRM data for Q2',
      assignedTo: 'Mike Johnson',
      dueDate: '2026-05-03',
      priority: 'LOW',
      priorityColor: const Color(0xFF00C896),
    ),
    CrmTaskModel(
      id: '4',
      title: 'Review lost lead analysis',
      assignedTo: 'Joe Brown',
      dueDate: '2026-05-02',
      priority: 'HIGH',
      priorityColor: const Color(0xFFEF4444),
    ),
  ];

  List<CrmTaskModel> get tasks => _tasks;

  void toggleTask(int i) {
    _tasks[i].isDone = !_tasks[i].isDone;
    notifyListeners();
  }

  // ── Sales Team ────────────────────────────────────────────────────────────
  List<SalesTeamMember> get salesTeam => const [
        SalesTeamMember(
          name: 'John Doe',
          role: 'Senior Sales Rep',
          leadsHandled: 125,
          wonDeals: 85,
          revenue: 'AED 95,800',
          winRate: 0.68,
        ),
        SalesTeamMember(
          name: 'Sarah Smith',
          role: 'Sales Representative',
          leadsHandled: 98,
          wonDeals: 62,
          revenue: 'AED 72,400',
          winRate: 0.63,
        ),
        SalesTeamMember(
          name: 'Mike Johnson',
          role: 'Sales Representative',
          leadsHandled: 110,
          wonDeals: 74,
          revenue: 'AED 68,200',
          winRate: 0.67,
        ),
        SalesTeamMember(
          name: 'Joe Brown',
          role: 'Junior Sales Rep',
          leadsHandled: 75,
          wonDeals: 48,
          revenue: 'AED 44,300',
          winRate: 0.64,
        ),
      ];

  // ── Conversations ─────────────────────────────────────────────────────────
  List<ConversationModel> get conversations => const [
        ConversationModel(
          id: '1',
          customerName: 'James Anderson',
          lastMessage: 'I am interested in your services, can we schedule a call?',
          time: '14:23',
          channel: 'WhatsApp',
          channelColor: Color(0xFF25D366),
          unread: 2,
          status: 'ACTIVE',
        ),
        ConversationModel(
          id: '2',
          customerName: 'Emily Chen',
          lastMessage: 'Thank you for the quick response!',
          time: '13:45',
          channel: 'Instagram',
          channelColor: Color(0xFFE1306C),
          unread: 0,
          status: 'WON',
        ),
        ConversationModel(
          id: '3',
          customerName: 'Michael Roberts',
          lastMessage: 'Please send me the quotation as soon as possible.',
          time: '12:15',
          channel: 'Google Ads',
          channelColor: Color(0xFFFBBC04),
          unread: 1,
          status: 'ACTIVE',
        ),
        ConversationModel(
          id: '4',
          customerName: 'Sarah Williams',
          lastMessage: 'No reply yet on the proposal.',
          time: 'Yesterday',
          channel: 'Website',
          channelColor: Color(0xFF00D4FF),
          unread: 0,
          status: 'UNANSWERED',
        ),
        ConversationModel(
          id: '5',
          customerName: 'David Martinez',
          lastMessage: 'Going with a competitor unfortunately.',
          time: '2 days ago',
          channel: 'SMS',
          channelColor: Color(0xFF7C3AFF),
          unread: 0,
          status: 'LOST',
        ),
      ];

  // ── Settings ──────────────────────────────────────────────────────────────
  bool notificationsEnabled = true;
  bool darkMode = true;
  bool autoAssign = true;

  void toggleNotifications() {
    notificationsEnabled = !notificationsEnabled;
    notifyListeners();
  }

  void toggleDarkMode() {
    darkMode = !darkMode;
    notifyListeners();
  }

  void toggleAutoAssign() {
    autoAssign = !autoAssign;
    notifyListeners();
  }
}