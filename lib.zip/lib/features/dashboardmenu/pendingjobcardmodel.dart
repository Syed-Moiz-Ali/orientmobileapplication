import 'package:flutter/material.dart';

enum JobCardStatus { overdue, pending, inProgress }

class PendingJobCardModel {
  final String jobCardId;
  final String customerName;
  final String vehicleInfo;
  final String assignedTo;
  final String createdDate;
  final String dueDate;
  final int daysOverdue; // negative = days remaining
  final JobCardStatus status;
  final double estimatedAmount;

  PendingJobCardModel({
    required this.jobCardId,
    required this.customerName,
    required this.vehicleInfo,
    required this.assignedTo,
    required this.createdDate,
    required this.dueDate,
    required this.daysOverdue,
    required this.status,
    required this.estimatedAmount,
  });
}