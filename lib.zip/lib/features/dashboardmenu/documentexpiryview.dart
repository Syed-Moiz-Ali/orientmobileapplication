import 'package:flutter/material.dart';
import 'package:orientmobileapplication/features/dashboardmenu/documentexpirymodel.dart';
import 'package:orientmobileapplication/features/dashboardmenu/documentexpiryviewmodel.dart';
import 'package:provider/provider.dart';


class DocumentExpiryView extends StatefulWidget {
  const DocumentExpiryView({super.key});

  @override
  State<DocumentExpiryView> createState() => _DocumentExpiryViewState();
}

class _DocumentExpiryViewState extends State<DocumentExpiryView> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DocumentExpiryViewModel>().loadDocuments();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<DocumentExpiryViewModel>(
      builder: (context, vm, _) => Scaffold(
        backgroundColor: Colors.white,
        appBar: _buildAppBar(vm),
        body: vm.isLoading
            ? const Center(
                child: CircularProgressIndicator(color: Color(0xFF2563EB)))
            : Column(
                children: [
                  // Summary cards
                  Padding(
                    padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
                    child: Row(
                      children: [
                        _SummaryCard(
                          label: 'Critical',
                          count: vm.criticalCount,
                          color: const Color(0xFFDC2626),
                          bg: const Color(0xFFFEF2F2),
                        ),
                        const SizedBox(width: 10),
                        _SummaryCard(
                          label: 'Urgent',
                          count: vm.urgentCount,
                          color: const Color(0xFFD97706),
                          bg: const Color(0xFFFFFBEB),
                        ),
                        const SizedBox(width: 10),
                        _SummaryCard(
                          label: 'Warning',
                          count: vm.warningCount,
                          color: const Color(0xFFCA8A04),
                          bg: const Color(0xFFFEFCE8),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: ListView.separated(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      itemCount: vm.filteredDocuments.length,
                      separatorBuilder: (_, __) =>
                          const Divider(height: 1, color: Color(0xFFE5E7EB)),
                      itemBuilder: (_, i) => _DocumentItem(
                        doc: vm.filteredDocuments[i],
                        onRenew: () =>
                            vm.onRenewDocument(vm.filteredDocuments[i]),
                      ),
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(DocumentExpiryViewModel vm) {
    return AppBar(
      backgroundColor: Colors.white,
      elevation: 0,
      leading: IconButton(
        icon: const Icon(Icons.menu, color: Color(0xFF374151)),
        onPressed: () {},
      ),
      title: const Text('Document Expiry',
          style: TextStyle(
              color: Color(0xFF111827),
              fontSize: 17,
              fontWeight: FontWeight.w600)),
      centerTitle: true,
      actions: [
        Stack(
          children: [
            IconButton(
              icon: const Icon(Icons.notifications_outlined,
                  color: Color(0xFF374151)),
              onPressed: () {},
            ),
            Positioned(
              right: 6,
              top: 6,
              child: Container(
                width: 18,
                height: 18,
                decoration: const BoxDecoration(
                    color: Color(0xFFDC2626), shape: BoxShape.circle),
                child: const Center(
                  child: Text('8',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold)),
                ),
              ),
            ),
          ],
        ),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(56),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
          child: Container(
            height: 42,
            decoration: BoxDecoration(
              color: const Color(0xFFF3F4F6),
              borderRadius: BorderRadius.circular(8),
            ),
            child: TextField(
              onChanged: vm.onSearch,
              style: const TextStyle(fontSize: 14),
              decoration: const InputDecoration(
                hintText: 'Search employees...',
                hintStyle: TextStyle(color: Color(0xFF9CA3AF), fontSize: 14),
                prefixIcon:
                    Icon(Icons.search, color: Color(0xFF9CA3AF), size: 20),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final String label;
  final int count;
  final Color color;
  final Color bg;

  const _SummaryCard(
      {required this.label,
      required this.count,
      required this.color,
      required this.bg});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withValues(alpha: 0.2)),
        ),
        child: Column(
          children: [
            Icon(Icons.warning_amber_rounded, color: color, size: 22),
            const SizedBox(height: 6),
            Text(label,
                style: TextStyle(
                    fontSize: 12, color: color, fontWeight: FontWeight.w500)),
            const SizedBox(height: 4),
            Text('$count',
                style: TextStyle(
                    fontSize: 22, fontWeight: FontWeight.w800, color: color)),
          ],
        ),
      ),
    );
  }
}

class _DocumentItem extends StatelessWidget {
  final DocumentExpiryModel doc;
  final VoidCallback onRenew;

  const _DocumentItem({required this.doc, required this.onRenew});

  @override
  Widget build(BuildContext context) {
    Color urgencyColor;
    String urgencyLabel;
    Color urgencyBg;

    switch (doc.urgency) {
      case ExpiryUrgency.critical:
        urgencyColor = const Color(0xFFDC2626);
        urgencyBg = const Color(0xFFFEF2F2);
        urgencyLabel = 'Critical';
        break;
      case ExpiryUrgency.urgent:
        urgencyColor = const Color(0xFFD97706);
        urgencyBg = const Color(0xFFFFFBEB);
        urgencyLabel = 'Urgent';
        break;
      case ExpiryUrgency.warning:
        urgencyColor = const Color(0xFFCA8A04);
        urgencyBg = const Color(0xFFFEFCE8);
        urgencyLabel = 'Warning';
        break;
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(doc.empId,
                        style: const TextStyle(
                            fontSize: 12, color: Color(0xFF6B7280))),
                    const SizedBox(height: 2),
                    Text(doc.employeeName,
                        style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF111827))),
                    const SizedBox(height: 2),
                    Text(doc.designation,
                        style: const TextStyle(
                            fontSize: 13, color: Color(0xFF6B7280))),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                    color: urgencyBg,
                    borderRadius: BorderRadius.circular(20)),
                child: Text(urgencyLabel,
                    style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: urgencyColor)),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _DetailRow(label: 'Document:', value: doc.documentType),
          const SizedBox(height: 4),
          _DetailRow(label: 'Expires:', value: doc.expiryDate),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Days left:',
                  style: TextStyle(fontSize: 13, color: Color(0xFF6B7280))),
              Text('${doc.daysLeft} days',
                  style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: urgencyColor)),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: onRenew,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF111827),
                foregroundColor: Colors.white,
                elevation: 0,
                padding: const EdgeInsets.symmetric(vertical: 13),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8)),
              ),
              child: const Text('Renew Document',
                  style:
                      TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
            ),
          ),
        ],
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  const _DetailRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: const TextStyle(fontSize: 13, color: Color(0xFF6B7280))),
        Text(value,
            style: const TextStyle(fontSize: 13, color: Color(0xFF111827))),
      ],
    );
  }
}