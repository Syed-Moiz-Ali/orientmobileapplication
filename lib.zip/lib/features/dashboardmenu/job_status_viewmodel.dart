import 'package:flutter/foundation.dart';
import 'job_status_model.dart';

class JobStatusViewModel extends ChangeNotifier {
  bool _isLoading = false;
  String _searchQuery = '';
  JobStage? _filterStage; // null = All
  List<JobStatusModel> _all = [];

  bool get isLoading => _isLoading;
  JobStage? get filterStage => _filterStage;

  List<JobStatusModel> get filtered {
    var list = _all.where((j) {
      final q = _searchQuery.toLowerCase();
      final matchQuery = q.isEmpty ||
          j.customerName.toLowerCase().contains(q) ||
          j.jobCardId.toLowerCase().contains(q) ||
          j.vehicleInfo.toLowerCase().contains(q);
      final matchStage =
          _filterStage == null || j.stage == _filterStage;
      return matchQuery && matchStage;
    }).toList();
    return list;
  }

  void onSearch(String q) {
    _searchQuery = q;
    notifyListeners();
  }

  void setFilter(JobStage? stage) {
    _filterStage = stage;
    notifyListeners();
  }

  Future<void> load() async {
    _isLoading = true;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 500));
    _all = [
      const JobStatusModel(
        jobCardId: 'JC-1041',
        customerName: 'Ahmed Al Rashid',
        vehicleInfo: 'Toyota Camry 2020 · DXB-A-12345',
        assignedTo: 'Mohammed Hassan',
        createdDate: '28 Mar 2024',
        dueDate: '02 Apr 2024',
        stage: JobStage.wip,
        estimatedAmount: 1250.00,
      ),
      const JobStatusModel(
        jobCardId: 'JC-1042',
        customerName: 'Sara Al Mansoori',
        vehicleInfo: 'Nissan Patrol 2022 · AUH-B-67890',
        assignedTo: 'Ali Ahmed',
        createdDate: '01 Apr 2024',
        dueDate: '05 Apr 2024',
        stage: JobStage.waitingApproval,
        estimatedAmount: 3400.50,
      ),
      const JobStatusModel(
        jobCardId: 'JC-1043',
        customerName: 'Khalid bin Zayed',
        vehicleInfo: 'BMW X5 2021 · SHJ-C-11223',
        assignedTo: 'Hassan Ibrahim',
        createdDate: '02 Apr 2024',
        dueDate: '06 Apr 2024',
        stage: JobStage.completed,
        estimatedAmount: 5800.00,
      ),
      const JobStatusModel(
        jobCardId: 'JC-1044',
        customerName: 'Fatima Al Zaabi',
        vehicleInfo: 'Mercedes GLC 2019 · DXB-D-44556',
        assignedTo: 'Omar Khalid',
        createdDate: '25 Mar 2024',
        dueDate: '30 Mar 2024',
        stage: JobStage.waitingEstimation,
        estimatedAmount: 2100.00,
      ),
      const JobStatusModel(
        jobCardId: 'JC-1045',
        customerName: 'Yousef Al Hamad',
        vehicleInfo: 'Lexus LX 2023 · AUH-E-99001',
        assignedTo: 'Yousef Ali',
        createdDate: '03 Apr 2024',
        dueDate: '08 Apr 2024',
        stage: JobStage.invoice,
        estimatedAmount: 4750.00,
      ),
    ];
    _isLoading = false;
    notifyListeners();
  }
}