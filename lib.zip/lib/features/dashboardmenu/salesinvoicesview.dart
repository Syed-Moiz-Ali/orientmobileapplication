// import 'package:flutter/material.dart';
// import 'package:orientmobileapplication/features/dashboardmenu/salesinvoicesviewmodel.dart';
// import 'package:provider/provider.dart';


// class SalesInvoicesView extends StatefulWidget {
//   const SalesInvoicesView({super.key});

//   @override
//   State<SalesInvoicesView> createState() => _SalesInvoicesViewState();
// }

// class _SalesInvoicesViewState extends State<SalesInvoicesView> {
//   @override
//   void initState() {
//     super.initState();
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       context.read<SalesInvoicesViewModel>().loadInvoices();
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Consumer<SalesInvoicesViewModel>(
//       builder: (context, vm, _) => Scaffold(
//         backgroundColor: Colors.white,
//         appBar: _buildAppBar(vm),
//         body: vm.isLoading
//             ? const Center(child: CircularProgressIndicator(color: Color(0xFF2563EB)))
//             : Column(
//                 children: [
//                   // Total Sales bar
//                   Container(
//                     width: double.infinity,
//                     padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
//                     decoration: const BoxDecoration(
//                       border: Border(bottom: BorderSide(color: Color(0xFFE5E7EB))),
//                     ),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                       children: [
//                         const Text('Total Sales',
//                             style: TextStyle(fontSize: 14, color: Color(0xFF374151))),
//                         Text(
//                           'AED ${_formatAmount(vm.totalSales)}',
//                           style: const TextStyle(
//                               fontSize: 15,
//                               fontWeight: FontWeight.w700,
//                               color: Color(0xFF16A34A)),
//                         ),
//                       ],
//                     ),
//                   ),
//                   Expanded(
//                     child: ListView.separated(
//                       itemCount: vm.filteredInvoices.length,
//                       separatorBuilder: (_, __) =>
//                           const Divider(height: 1, color: Color(0xFFE5E7EB)),
//                       itemBuilder: (_, i) => _InvoiceItem(
//                         invoice: vm.filteredInvoices[i],
//                         onView: () => vm.onViewInvoice(vm.filteredInvoices[i]),
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//       ),
//     );
//   }

//   PreferredSizeWidget _buildAppBar(SalesInvoicesViewModel vm) {
//     return AppBar(
//       backgroundColor: Colors.white,
//       elevation: 0,
//       leading: IconButton(
//         icon: const Icon(Icons.menu, color: Color(0xFF374151)),
//         onPressed: () {},
//       ),
//       title: const Text('Sales Invoices',
//           style: TextStyle(
//               color: Color(0xFF111827),
//               fontSize: 17,
//               fontWeight: FontWeight.w600)),
//       centerTitle: true,
//       actions: [
//         IconButton(
//           icon: const Icon(Icons.notifications_outlined, color: Color(0xFF374151)),
//           onPressed: () {},
//         ),
//       ],
//       bottom: PreferredSize(
//         preferredSize: const Size.fromHeight(56),
//         child: Padding(
//           padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
//           child: Row(
//             children: [
//               Expanded(
//                 child: Container(
//                   height: 42,
//                   decoration: BoxDecoration(
//                     color: const Color(0xFFF3F4F6),
//                     borderRadius: BorderRadius.circular(8),
//                   ),
//                   child: TextField(
//                     onChanged: vm.onSearch,
//                     style: const TextStyle(fontSize: 14),
//                     decoration: const InputDecoration(
//                       hintText: 'Search invoices...',
//                       hintStyle:
//                           TextStyle(color: Color(0xFF9CA3AF), fontSize: 14),
//                       prefixIcon:
//                           Icon(Icons.search, color: Color(0xFF9CA3AF), size: 20),
//                       border: InputBorder.none,
//                       contentPadding: EdgeInsets.symmetric(vertical: 12),
//                     ),
//                   ),
//                 ),
//               ),
//               const SizedBox(width: 8),
//               _iconBtn(Icons.tune, () {}),
//               const SizedBox(width: 8),
//               _iconBtn(Icons.download_outlined, vm.onDownload),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _iconBtn(IconData icon, VoidCallback onTap) {
//     return GestureDetector(
//       onTap: onTap,
//       child: Container(
//         height: 42,
//         width: 42,
//         decoration: BoxDecoration(
//           color: const Color(0xFFF3F4F6),
//           borderRadius: BorderRadius.circular(8),
//         ),
//         child: Icon(icon, color: const Color(0xFF374151), size: 20),
//       ),
//     );
//   }

//   String _formatAmount(double amount) {
//     return amount.toStringAsFixed(0).replaceAllMapped(
//         RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},');
//   }
// }

// class _InvoiceItem extends StatelessWidget {
//   final SalesInvoiceModel invoice;
//   final VoidCallback onView;

//   const _InvoiceItem({required this.invoice, required this.onView});

//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Row(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Expanded(
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Text(invoice.id,
//                         style: const TextStyle(
//                             fontSize: 12, color: Color(0xFF6B7280))),
//                     const SizedBox(height: 2),
//                     Text(invoice.customerName,
//                         style: const TextStyle(
//                             fontSize: 15,
//                             fontWeight: FontWeight.w700,
//                             color: Color(0xFF111827))),
//                     const SizedBox(height: 2),
//                     Text('${invoice.date} • ${invoice.jobCardRef}',
//                         style: const TextStyle(
//                             fontSize: 12, color: Color(0xFF6B7280))),
//                   ],
//                 ),
//               ),
//               _InvoiceStatusBadge(status: invoice.status),
//             ],
//           ),
//           const SizedBox(height: 10),
//           _DetailRow(label: 'Type:', value: invoice.type),
//           const SizedBox(height: 4),
//           _DetailRow(label: 'Payment:', value: invoice.payment),
//           const SizedBox(height: 12),
//           Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               Text('AED ${_formatAmount(invoice.amount)}',
//                   style: const TextStyle(
//                       fontSize: 15,
//                       fontWeight: FontWeight.w700,
//                       color: Color(0xFF111827))),
//               OutlinedButton(
//                 onPressed: onView,
//                 style: OutlinedButton.styleFrom(
//                   foregroundColor: const Color(0xFF111827),
//                   side: const BorderSide(color: Color(0xFFD1D5DB)),
//                   padding:
//                       const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
//                   minimumSize: Size.zero,
//                   tapTargetSize: MaterialTapTargetSize.shrinkWrap,
//                   shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(6)),
//                 ),
//                 child: const Text('View Invoice',
//                     style:
//                         TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }

//   String _formatAmount(double amount) {
//     return amount.toStringAsFixed(0).replaceAllMapped(
//         RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},');
//   }
// }

// class _DetailRow extends StatelessWidget {
//   final String label;
//   final String value;
//   const _DetailRow({required this.label, required this.value});

//   @override
//   Widget build(BuildContext context) {
//     return Row(
//       children: [
//         Text(label, style: const TextStyle(fontSize: 13, color: Color(0xFF6B7280))),
//         const Spacer(),
//         Text(value, style: const TextStyle(fontSize: 13, color: Color(0xFF111827))),
//       ],
//     );
//   }
// }

// class _InvoiceStatusBadge extends StatelessWidget {
//   final InvoiceStatus status;
//   const _InvoiceStatusBadge({required this.status});

//   @override
//   Widget build(BuildContext context) {
//     Color bg, fg;
//     String label;
//     switch (status) {
//       case InvoiceStatus.paid:
//         bg = const Color(0xFFECFDF5);
//         fg = const Color(0xFF059669);
//         label = 'Paid';
//         break;
//       case InvoiceStatus.unpaid:
//         bg = const Color(0xFFFFFBEB);
//         fg = const Color(0xFFD97706);
//         label = 'Unpaid';
//         break;
//       case InvoiceStatus.overdue:
//         bg = const Color(0xFFFEF2F2);
//         fg = const Color(0xFFDC2626);
//         label = 'Overdue';
//         break;
//     }
//     return Container(
//       padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
//       decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
//       child: Text(label,
//           style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: fg)),
//     );
//   }
// }