enum ExpiryUrgency { critical, urgent, warning }

class DocumentExpiryModel {
  final String empId;
  final String employeeName;
  final String designation;
  final String documentType;
  final String expiryDate;
  final int daysLeft;
  final ExpiryUrgency urgency;

  DocumentExpiryModel({
    required this.empId,
    required this.employeeName,
    required this.designation,
    required this.documentType,
    required this.expiryDate,
    required this.daysLeft,
    required this.urgency,
  });
}