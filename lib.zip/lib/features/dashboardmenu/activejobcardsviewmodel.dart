
import 'package:flutter/material.dart';
import 'package:orientmobileapplication/features/dashboardmenu/activejobcardmodel.dart';

class ActiveJobCardsViewModel extends ChangeNotifier {
  bool _isLoading = false;
  String _searchQuery = '';
  List<ActiveJobCardModel> _allJobCards = [];

  bool get isLoading => _isLoading;
  String get searchQuery => _searchQuery;

  List<ActiveJobCardModel> get filteredJobCards {
    if (_searchQuery.isEmpty) return _allJobCards;
    final q = _searchQuery.toLowerCase();
    return _allJobCards.where((jc) =>
        jc.id.toLowerCase().contains(q) ||
        jc.customerName.toLowerCase().contains(q) ||
        jc.vehicleInfo.toLowerCase().contains(q)).toList();
  }

  Future<void> loadJobCards() async {
    _isLoading = true;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 500));
    _allJobCards = [
      ActiveJobCardModel(
        id: 'JC-2024-001',
        customerName: 'Ahmed Al Mansouri',
        vehicleInfo: 'Toyota Camry - AA-12345',
        services: 'Oil Change, Brake Inspection',
        technician: 'Mohammed Hassan',
        estCompletion: '2024-04-01',
        amount: 850,
        status: ActiveJobStatus.inProgress,
      ),
      ActiveJobCardModel(
        id: 'JC-2024-002',
        customerName: 'Fatima Ali',
        vehicleInfo: 'Honda Accord - BB-67890',
        services: 'Transmission Repair',
        technician: 'Ali Ahmed',
        estCompletion: '2024-04-02',
        amount: 3200,
        status: ActiveJobStatus.waitingParts,
      ),
      ActiveJobCardModel(
        id: 'JC-2024-003',
        customerName: 'Khalid Rashid',
        vehicleInfo: 'Nissan Patrol - CC-11223',
        services: 'AC Service, Filter Replacement',
        technician: 'Hassan Ibrahim',
        estCompletion: '2024-04-01',
        amount: 1450,
        status: ActiveJobStatus.inProgress,
      ),
      ActiveJobCardModel(
        id: 'JC-2024-004',
        customerName: 'Mariam Salem',
        vehicleInfo: 'BMW X5 - DD-44556',
        services: 'Engine Diagnostics, Spark Plug Change',
        technician: 'Omar Khalid',
        estCompletion: '2024-03-31',
        amount: 2100,
        status: ActiveJobStatus.qualityCheck,
      ),
      ActiveJobCardModel(
        id: 'JC-2024-005',
        customerName: 'Saeed Mohammed',
        vehicleInfo: 'Mercedes C-Class - EE-77889',
        services: 'Brake Pad Replacement, Wheel Alignment',
        technician: 'Yousef Ali',
        estCompletion: '2024-04-02',
        amount: 1680,
        status: ActiveJobStatus.inProgress,
      ),
    ];
    _isLoading = false;
    notifyListeners();
  }

  void onSearch(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  void onViewDetails(ActiveJobCardModel jobCard) {}
}