import 'package:flutter/foundation.dart';
import 'package:orientmobileapplication/features/dashboardmenu/documentexpirymodel.dart';

class DocumentExpiryViewModel extends ChangeNotifier {
  bool _isLoading = false;
  String _searchQuery = '';
  List<DocumentExpiryModel> _allDocuments = [];

  bool get isLoading => _isLoading;
  int get criticalCount =>
      _allDocuments.where((d) => d.urgency == ExpiryUrgency.critical).length;
  int get urgentCount =>
      _allDocuments.where((d) => d.urgency == ExpiryUrgency.urgent).length;
  int get warningCount =>
      _allDocuments.where((d) => d.urgency == ExpiryUrgency.warning).length;

  List<DocumentExpiryModel> get filteredDocuments {
    if (_searchQuery.isEmpty) return _allDocuments;
    final q = _searchQuery.toLowerCase();
    return _allDocuments
        .where((d) =>
            d.employeeName.toLowerCase().contains(q) ||
            d.empId.toLowerCase().contains(q))
        .toList();
  }

  Future<void> loadDocuments() async {
    _isLoading = true;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 500));
    _allDocuments = [
      DocumentExpiryModel(
        empId: 'EMP-001',
        employeeName: 'Mohammed Hassan',
        designation: 'Senior Technician',
        documentType: 'Labor Card',
        expiryDate: '2024-04-15',
        daysLeft: 15,
        urgency: ExpiryUrgency.urgent,
      ),
      DocumentExpiryModel(
        empId: 'EMP-002',
        employeeName: 'Ali Ahmed',
        designation: 'Technician',
        documentType: 'Visa',
        expiryDate: '2024-04-22',
        daysLeft: 22,
        urgency: ExpiryUrgency.warning,
      ),
      DocumentExpiryModel(
        empId: 'EMP-003',
        employeeName: 'Hassan Ibrahim',
        designation: 'Technician',
        documentType: 'Emirates ID',
        expiryDate: '2024-04-18',
        daysLeft: 18,
        urgency: ExpiryUrgency.urgent,
        //daysleft
      ),
      DocumentExpiryModel(
        empId: 'EMP-004',
        employeeName: 'Omar Khalid',
        designation: 'Lead Technician',
        documentType: 'Labor Card',
        expiryDate: '2024-04-05',
        daysLeft: 5,
        urgency: ExpiryUrgency.critical,
      ),
      DocumentExpiryModel(
        empId: 'EMP-005',
        employeeName: 'Yousef Ali',
        designation: 'Technician',
        documentType: 'Visa',
        expiryDate: '2024-04-08',
        daysLeft: 8,
        urgency: ExpiryUrgency.critical,
      ),
    ];
    _isLoading = false;
    notifyListeners();
  }

  void onSearch(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  void onRenewDocument(DocumentExpiryModel doc) {}
}