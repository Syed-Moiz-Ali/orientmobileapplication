import 'package:flutter/foundation.dart';
import 'package:orientmobileapplication/features/dashboardmenu/Accountsreceivablemodel.dart';

class AccountsReceivableViewModel extends ChangeNotifier {
  bool _isLoading = false;
  String _searchQuery = '';
  List<ARRecordModel> _allRecords = [];
  ARSummaryModel _summary = ARSummaryModel(
    totalOutstanding: 0,
    days0to30: 0,
    days31to60: 0,
    days61to90: 0,
    days90plus: 0,
  );

  bool get isLoading => _isLoading;
  ARSummaryModel get summary => _summary;

  List<ARRecordModel> get filteredRecords {
    if (_searchQuery.isEmpty) return _allRecords;
    final q = _searchQuery.toLowerCase();
    return _allRecords
        .where((r) =>
            r.arId.toLowerCase().contains(q) ||
            r.customer.toLowerCase().contains(q))
        .toList();
  }

  Future<void> loadData() async {
    _isLoading = true;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 500));

    _summary = ARSummaryModel(
      totalOutstanding: 566000,
      days0to30: 230000,
      days31to60: 241000,
      days61to90: 95000,
      days90plus: 0,
    );

    _allRecords = [
      ARRecordModel(
        arId: 'AR-2024-001',
        customer: 'Al Fahim Motors',
        invoiceDate: '2024-02-15',
        dueDate: '2024-03-15',
        amount: 125000,
        outstanding: 125000,
        aging: AgingBucket.days0to30,
        contactPerson: 'Ahmed Ali',
        phone: '+971 50 123 4567',
      ),
      ARRecordModel(
        arId: 'AR-2024-002',
        customer: 'Emirates Trading Co.',
        invoiceDate: '2024-01-28',
        dueDate: '2024-02-28',
        amount: 65000,
        outstanding: 85000,
        aging: AgingBucket.days31to60,
        contactPerson: 'Sara Mohammed',
        phone: '+971 50 234 5678',
      ),
      ARRecordModel(
        arId: 'AR-2024-003',
        customer: 'Dubai Fleet Services',
        invoiceDate: '2024-02-20',
        dueDate: '2024-03-20',
        amount: 210000,
        outstanding: 105000,
        aging: AgingBucket.days0to30,
        contactPerson: 'Khalid Hassan',
        phone: '+971 50 345 6789',
      ),
      ARRecordModel(
        arId: 'AR-2024-004',
        customer: 'Abu Dhabi Transport',
        invoiceDate: '2024-01-10',
        dueDate: '2024-02-10',
        amount: 156000,
        outstanding: 156000,
        aging: AgingBucket.days31to60,
        contactPerson: 'Fatima Ali',
        phone: '+971 50 456 7890',
      ),
      ARRecordModel(
        arId: 'AR-2024-005',
        customer: 'Sharjah Auto Group',
        invoiceDate: '2023-12-15',
        dueDate: '2024-01-15',
        amount: 95000,
        outstanding: 95000,
        aging: AgingBucket.days61to90,
        contactPerson: 'Mohammed Rashid',
        phone: '+971 50 567 8901',
      ),
    ];
    _isLoading = false;
    notifyListeners();
  }

  void onSearch(String query) {
    _searchQuery = query;
    notifyListeners();
  }
}