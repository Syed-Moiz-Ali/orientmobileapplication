import 'package:flutter/material.dart';

class ApprovalCategoryModel {
  final String title;
  final String subtitle;
  final int count;
  final Color iconBg;
  final IconData icon;
 



  ApprovalCategoryModel({
    required this.title,
    required this.subtitle,
    required this.count,
    required this.iconBg,
    required this.icon,
  


  });
}