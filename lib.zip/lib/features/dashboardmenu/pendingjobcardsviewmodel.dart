import 'package:flutter/foundation.dart';
import 'package:orientmobileapplication/features/dashboardmenu/pendingjobcardmodel.dart';

class PendingJobCardsViewModel extends ChangeNotifier {
  bool _isLoading = false;
  String _searchQuery = '';
  List<PendingJobCardModel> _allJobCards = [];

  bool get isLoading => _isLoading;

  int get overdueCount =>
      _allJobCards.where((j) => j.status == JobCardStatus.overdue).length;
  int get pendingCount =>
      _allJobCards.where((j) => j.status == JobCardStatus.pending).length;
  int get inProgressCount =>
      _allJobCards.where((j) => j.status == JobCardStatus.inProgress).length;

  List<PendingJobCardModel> get filteredJobCards {
    if (_searchQuery.isEmpty) return _allJobCards;
    final q = _searchQuery.toLowerCase();
    return _allJobCards
        .where((j) =>
            j.customerName.toLowerCase().contains(q) ||
            j.jobCardId.toLowerCase().contains(q) ||
            j.vehicleInfo.toLowerCase().contains(q))
        .toList();
  }

  Future<void> loadJobCards() async {
    _isLoading = true;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 500));
    _allJobCards = [
      PendingJobCardModel(
        jobCardId: 'JC-1041',
        customerName: 'Ahmed Al Rashid',
        vehicleInfo: 'Toyota Camry 2020 - DXB-A-12345',
        assignedTo: 'Mohammed Hassan',
        createdDate: '2024-03-28',
        dueDate: '2024-04-02',
        daysOverdue: 3,
        status: JobCardStatus.overdue,
        estimatedAmount: 1250.00,
      ),
      PendingJobCardModel(
        jobCardId: 'JC-1042',
        customerName: 'Sara Al Mansoori',
        vehicleInfo: 'Nissan Patrol 2022 - AUH-B-67890',
        assignedTo: 'Ali Ahmed',
        createdDate: '2024-04-01',
        dueDate: '2024-04-05',
        daysOverdue: 0,
        status: JobCardStatus.pending,
        estimatedAmount: 3400.50,
      ),
      PendingJobCardModel(
        jobCardId: 'JC-1043',
        customerName: 'Khalid bin Zayed',
        vehicleInfo: 'BMW X5 2021 - SHJ-C-11223',
        assignedTo: 'Hassan Ibrahim',
        createdDate: '2024-04-02',
        dueDate: '2024-04-06',
        daysOverdue: -1,
        status: JobCardStatus.inProgress,
        estimatedAmount: 5800.00,
      ),
      PendingJobCardModel(
        jobCardId: 'JC-1044',
        customerName: 'Fatima Al Zaabi',
        vehicleInfo: 'Mercedes GLC 2019 - DXB-D-44556',
        assignedTo: 'Omar Khalid',
        createdDate: '2024-03-25',
        dueDate: '2024-03-30',
        daysOverdue: 7,
        status: JobCardStatus.overdue,
        estimatedAmount: 2100.00,
      ),
      PendingJobCardModel(
        jobCardId: 'JC-1045',
        customerName: 'Yousef Al Hamad',
        vehicleInfo: 'Lexus LX 2023 - AUH-E-99001',
        assignedTo: 'Yousef Ali',
        createdDate: '2024-04-03',
        dueDate: '2024-04-08',
        daysOverdue: -3,
        status: JobCardStatus.pending,
        estimatedAmount: 4750.00,
      ),
    ];
    _isLoading = false;
    notifyListeners();
  }

  void onSearch(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  void onViewJobCard(PendingJobCardModel jobCard) {
    // TODO: navigate to job card detail
  }

  void onApproveJobCard(PendingJobCardModel jobCard) {
    // TODO: handle approval
  }
}