import 'package:flutter/material.dart';
import 'package:orientmobileapplication/features/dashboardmenu/pendingjobcardmodel.dart';
import 'package:orientmobileapplication/features/dashboardmenu/pendingjobcardsviewmodel.dart';
import 'package:provider/provider.dart';

class PendingJobCardsView extends StatefulWidget {
  const PendingJobCardsView({super.key});

  @override
  State<PendingJobCardsView> createState() => _PendingJobCardsViewState();
}

class _PendingJobCardsViewState extends State<PendingJobCardsView> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<PendingJobCardsViewModel>().loadJobCards();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<PendingJobCardsViewModel>(
      builder: (context, vm, _) => Scaffold(
        backgroundColor: Colors.white,
        appBar: _buildAppBar(vm),
        body: vm.isLoading
            ? const Center(
                child: CircularProgressIndicator(color: Color(0xFF2563EB)))
            : Column(
                children: [
                  // Summary cards
                  Padding(
                    padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
                    child: Row(
                      children: [
                        _SummaryCard(
                          label: 'Overdue',
                          count: vm.overdueCount,
                          color: const Color(0xFFDC2626),
                          bg: const Color(0xFFFEF2F2),
                          icon: Icons.error_outline,
                        ),
                        const SizedBox(width: 10),
                        _SummaryCard(
                          label: 'Pending',
                          count: vm.pendingCount,
                          color: const Color(0xFFD97706),
                          bg: const Color(0xFFFFFBEB),
                          icon: Icons.hourglass_empty_rounded,
                        ),
                        const SizedBox(width: 10),
                        _SummaryCard(
                          label: 'In Progress',
                          count: vm.inProgressCount,
                          color: const Color(0xFF2563EB),
                          bg: const Color(0xFFEFF6FF),
                          icon: Icons.build_outlined,
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: ListView.separated(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      itemCount: vm.filteredJobCards.length,
                      separatorBuilder: (_, __) =>
                          const Divider(height: 1, color: Color(0xFFE5E7EB)),
                      itemBuilder: (_, i) => _JobCardItem(
                        jobCard: vm.filteredJobCards[i],
                        onView: () =>
                            vm.onViewJobCard(vm.filteredJobCards[i]),
                        onApprove: () =>
                            vm.onApproveJobCard(vm.filteredJobCards[i]),
                      ),
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(PendingJobCardsViewModel vm) {
    final totalOverdue = vm.overdueCount;
    return AppBar(
      backgroundColor: Colors.white,
      elevation: 0,
      leading: IconButton(
        icon: const Icon(Icons.menu, color: Color(0xFF374151)),
        onPressed: () {},
      ),
      title: const Text(
        'Pending Job Cards',
        style: TextStyle(
            color: Color(0xFF111827),
            fontSize: 17,
            fontWeight: FontWeight.w600),
      ),
      centerTitle: true,
      actions: [
        Stack(
          children: [
            IconButton(
              icon: const Icon(Icons.notifications_outlined,
                  color: Color(0xFF374151)),
              onPressed: () {},
            ),
            if (totalOverdue > 0)
              Positioned(
                right: 6,
                top: 6,
                child: Container(
                  width: 18,
                  height: 18,
                  decoration: const BoxDecoration(
                      color: Color(0xFFDC2626), shape: BoxShape.circle),
                  child: Center(
                    child: Text(
                      '$totalOverdue',
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(56),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
          child: Container(
            height: 42,
            decoration: BoxDecoration(
              color: const Color(0xFFF3F4F6),
              borderRadius: BorderRadius.circular(8),
            ),
            child: TextField(
              onChanged: vm.onSearch,
              style: const TextStyle(fontSize: 14),
              decoration: const InputDecoration(
                hintText: 'Search job cards...',
                hintStyle:
                    TextStyle(color: Color(0xFF9CA3AF), fontSize: 14),
                prefixIcon:
                    Icon(Icons.search, color: Color(0xFF9CA3AF), size: 20),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ── Summary Card ──────────────────────────────────────────────
class _SummaryCard extends StatelessWidget {
  final String label;
  final int count;
  final Color color;
  final Color bg;
  final IconData icon;

  const _SummaryCard({
    required this.label,
    required this.count,
    required this.color,
    required this.bg,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withValues(alpha: 0.2)),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(height: 6),
            Text(label,
                style: TextStyle(
                    fontSize: 12,
                    color: color,
                    fontWeight: FontWeight.w500)),
            const SizedBox(height: 4),
            Text(
              '$count',
              style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: color),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Job Card Item ─────────────────────────────────────────────
class _JobCardItem extends StatelessWidget {
  final PendingJobCardModel jobCard;
  final VoidCallback onView;
  final VoidCallback onApprove;

  const _JobCardItem({
    required this.jobCard,
    required this.onView,
    required this.onApprove,
  });

  @override
  Widget build(BuildContext context) {
    Color statusColor;
    String statusLabel;
    Color statusBg;
    String daysText;

    switch (jobCard.status) {
      case JobCardStatus.overdue:
        statusColor = const Color(0xFFDC2626);
        statusBg = const Color(0xFFFEF2F2);
        statusLabel = 'Overdue';
        daysText = '${jobCard.daysOverdue}d overdue';
        break;
      case JobCardStatus.pending:
        statusColor = const Color(0xFFD97706);
        statusBg = const Color(0xFFFFFBEB);
        statusLabel = 'Pending';
        daysText = jobCard.daysOverdue == 0
            ? 'Due today'
            : 'Due in ${jobCard.daysOverdue.abs()}d';
        break;
      case JobCardStatus.inProgress:
        statusColor = const Color(0xFF2563EB);
        statusBg = const Color(0xFFEFF6FF);
        statusLabel = 'In Progress';
        daysText = 'Due in ${jobCard.daysOverdue.abs()}d';
        break;
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      jobCard.jobCardId,
                      style: const TextStyle(
                          fontSize: 12, color: Color(0xFF6B7280)),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      jobCard.customerName,
                      style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF111827)),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      jobCard.vehicleInfo,
                      style: const TextStyle(
                          fontSize: 12, color: Color(0xFF6B7280)),
                    ),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                    color: statusBg,
                    borderRadius: BorderRadius.circular(20)),
                child: Text(
                  statusLabel,
                  style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: statusColor),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _DetailRow(label: 'Assigned To:', value: jobCard.assignedTo),
          const SizedBox(height: 4),
          _DetailRow(label: 'Created:', value: jobCard.createdDate),
          const SizedBox(height: 4),
          _DetailRow(label: 'Due Date:', value: jobCard.dueDate),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Status:',
                  style:
                      TextStyle(fontSize: 13, color: Color(0xFF6B7280))),
              Text(
                daysText,
                style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: statusColor),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Est. Amount:',
                  style:
                      TextStyle(fontSize: 13, color: Color(0xFF6B7280))),
              Text(
                'AED ${jobCard.estimatedAmount.toStringAsFixed(2)}',
                style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF111827)),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // Two action buttons
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: onView,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFF374151),
                    side: const BorderSide(color: Color(0xFFD1D5DB)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                  ),
                  child: const Text('View Details',
                      style: TextStyle(
                          fontSize: 13, fontWeight: FontWeight.w600)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton(
                  onPressed: onApprove,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF111827),
                    foregroundColor: Colors.white,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                  ),
                  child: const Text('Approve',
                      style: TextStyle(
                          fontSize: 13, fontWeight: FontWeight.w600)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  const _DetailRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style:
                const TextStyle(fontSize: 13, color: Color(0xFF6B7280))),
        Text(value,
            style: const TextStyle(
                fontSize: 13, color: Color(0xFF111827))),
      ],
    );
  }
}