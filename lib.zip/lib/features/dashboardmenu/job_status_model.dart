import 'dart:ui';

enum JobStage {
  waitingInspection,
  waitingPreRequest,
  waitingEstimation,
  waitingApproval,
  waitingParts,
  wip,
  completed,
  invoice,
  gatePassOut,
  cancelled,
}

extension JobStageExtension on JobStage {
  String get label {
    switch (this) {
      case JobStage.waitingInspection:   return 'Waiting for Inspection';
      case JobStage.waitingPreRequest:   return 'Waiting for Pre-Request';
      case JobStage.waitingEstimation:   return 'Waiting for Estimation';
      case JobStage.waitingApproval:     return 'Waiting for Approval';
      case JobStage.waitingParts:        return 'Waiting for Parts';
      case JobStage.wip:                 return 'WIP';
      case JobStage.completed:           return 'Completed';
      case JobStage.invoice:             return 'Invoice';
      case JobStage.gatePassOut:         return 'Gate Pass Out';
      case JobStage.cancelled:           return 'Cancelled';
    }
  }

  /// 0.0 – 1.0 progress along the pipeline
  double get progress {
    switch (this) {
      case JobStage.waitingInspection: return 0.10;
      case JobStage.waitingPreRequest: return 0.20;
      case JobStage.waitingEstimation: return 0.30;
      case JobStage.waitingApproval:   return 0.40;
      case JobStage.waitingParts:      return 0.50;
      case JobStage.wip:               return 0.60;
      case JobStage.completed:         return 0.80;
      case JobStage.invoice:           return 0.88;
      case JobStage.gatePassOut:       return 0.95;
      case JobStage.cancelled:         return 1.0;
    }
  }

  Color get color {
    switch (this) {
      case JobStage.waitingInspection: return const Color(0xFF3B82F6);
      case JobStage.waitingPreRequest: return const Color(0xFF22C55E);
      case JobStage.waitingEstimation: return const Color(0xFFF59E0B);
      case JobStage.waitingApproval:   return const Color(0xFF8B5CF6);
      case JobStage.waitingParts:      return const Color(0xFFF97316);
      case JobStage.wip:               return const Color(0xFF0EA5E9);
      case JobStage.completed:         return const Color(0xFF16A34A);
      case JobStage.invoice:           return const Color(0xFF10B981);
      case JobStage.gatePassOut:       return const Color(0xFF64748B);
      case JobStage.cancelled:         return const Color(0xFFEF4444);
    }
  }

  Color get bgColor {
    switch (this) {
      case JobStage.waitingInspection: return const Color(0xFFEFF6FF);
      case JobStage.waitingPreRequest: return const Color(0xFFF0FDF4);
      case JobStage.waitingEstimation: return const Color(0xFFFFFBEB);
      case JobStage.waitingApproval:   return const Color(0xFFFAF5FF);
      case JobStage.waitingParts:      return const Color(0xFFFFF7ED);
      case JobStage.wip:               return const Color(0xFFF0F9FF);
      case JobStage.completed:         return const Color(0xFFF0FDF4);
      case JobStage.invoice:           return const Color(0xFFECFDF5);
      case JobStage.gatePassOut:       return const Color(0xFFF8FAFC);
      case JobStage.cancelled:         return const Color(0xFFFEF2F2);
    }
  }
}

class JobStatusModel {
  final String jobCardId;
  final String customerName;
  final String vehicleInfo;
  final String assignedTo;
  final String createdDate;
  final String dueDate;
  final JobStage stage;
  final double estimatedAmount;

  const JobStatusModel({
    required this.jobCardId,
    required this.customerName,
    required this.vehicleInfo,
    required this.assignedTo,
    required this.createdDate,
    required this.dueDate,
    required this.stage,
    required this.estimatedAmount,
  });
}