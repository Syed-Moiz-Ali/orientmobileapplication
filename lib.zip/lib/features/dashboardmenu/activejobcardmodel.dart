enum ActiveJobStatus { inProgress, waitingParts, qualityCheck, completed }

class ActiveJobCardModel {
  final String id;
  final String customerName;
  final String vehicleInfo;
  final String services;
  final String technician;
  final String estCompletion;
  final double amount;
  final ActiveJobStatus status;

  ActiveJobCardModel({
    required this.id,
    required this.customerName,
    required this.vehicleInfo,
    required this.services,
    required this.technician,
    required this.estCompletion,
    required this.amount,
    required this.status,
  });
}