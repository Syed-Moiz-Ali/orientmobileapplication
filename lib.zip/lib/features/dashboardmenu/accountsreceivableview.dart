import 'package:flutter/material.dart';
import 'package:orientmobileapplication/features/dashboardmenu/Accountsreceivablemodel.dart';
import 'package:orientmobileapplication/features/dashboardmenu/accountsreceivableviewmodel.dart';
import 'package:provider/provider.dart';


class AccountsReceivableView extends StatefulWidget {
  const AccountsReceivableView({super.key});

  @override
  State<AccountsReceivableView> createState() => _AccountsReceivableViewState();
}

class _AccountsReceivableViewState extends State<AccountsReceivableView> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AccountsReceivableViewModel>().loadData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AccountsReceivableViewModel>(
      builder: (context, vm, _) => Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Color(0xFF374151)),
            onPressed: () => Navigator.of(context).pop(),
          ),
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Accounts Receivable',
                style: TextStyle(
                  color: Color(0xFF111827),
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(
                'Total Outstanding: AED ${_formatAmount(vm.summary.totalOutstanding)}',
                style: const TextStyle(fontSize: 12, color: Color(0xFF6B7280)),
              ),
            ],
          ),
        ),
        body: vm.isLoading
            ? const Center(
                child: CircularProgressIndicator(color: Color(0xFF2563EB)))
            : Column(
                children: [
                  // Search bar
                  Padding(
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
                    child: Container(
                      height: 42,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF3F4F6),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: TextField(
                        onChanged: vm.onSearch,
                        style: const TextStyle(fontSize: 14),
                        decoration: const InputDecoration(
                          hintText: 'Search by customer or AR ID...',
                          hintStyle: TextStyle(
                              color: Color(0xFF9CA3AF), fontSize: 13),
                          prefixIcon: Icon(Icons.search,
                              color: Color(0xFF9CA3AF), size: 20),
                          border: InputBorder.none,
                          contentPadding:
                              EdgeInsets.symmetric(vertical: 12),
                        ),
                      ),
                    ),
                  ),

                  // Aging bucket cards
                  Padding(
                    padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
                    child: Row(
                      children: [
                        _AgingCard(
                          label: '0-30 Days',
                          amount: vm.summary.days0to30,
                          color: const Color(0xFF16A34A),
                        ),
                        const SizedBox(width: 8),
                        _AgingCard(
                          label: '31-60 Days',
                          amount: vm.summary.days31to60,
                          color: const Color(0xFFD97706),
                        ),
                        const SizedBox(width: 8),
                        _AgingCard(
                          label: '61-90 Days',
                          amount: vm.summary.days61to90,
                          color: const Color(0xFFDC2626),
                        ),
                        const SizedBox(width: 8),
                        _AgingCard(
                          label: '90+ Days',
                          amount: vm.summary.days90plus,
                          color: const Color(0xFF374151),
                        ),
                      ],
                    ),
                  ),

                  // Table header
                  Container(
                    color: const Color(0xFFF9FAFB),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 10),
                    child: const Row(
                      children: [
                        _TableHeader(text: 'AR ID', flex: 2),
                        _TableHeader(text: 'Customer', flex: 3),
                        _TableHeader(text: 'Inv. Date', flex: 2),
                        _TableHeader(text: 'Due Date', flex: 2),
                        _TableHeader(text: 'Aging', flex: 2),
                      ],
                    ),
                  ),
                  const Divider(height: 1, color: Color(0xFFE5E7EB)),

                  // Table rows
                  Expanded(
                    child: ListView.separated(
                      itemCount: vm.filteredRecords.length,
                      separatorBuilder: (_, __) =>
                          const Divider(height: 1, color: Color(0xFFE5E7EB)),
                      itemBuilder: (_, i) =>
                          _ARTableRow(record: vm.filteredRecords[i]),
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  String _formatAmount(double amount) {
    return amount.toStringAsFixed(0).replaceAllMapped(
        RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},');
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _AgingCard extends StatelessWidget {
  final String label;
  final double amount;
  final Color color;

  const _AgingCard({
    required this.label,
    required this.amount,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFE5E7EB)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label,
                style: const TextStyle(
                    fontSize: 11, color: Color(0xFF6B7280))),
            const SizedBox(height: 4),
            Text(
              'AED ${_fmt(amount)}',
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: color),
            ),
          ],
        ),
      ),
    );
  }

  String _fmt(double v) => v == 0
      ? '0'
      : v.toStringAsFixed(0).replaceAllMapped(
          RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},');
}

class _TableHeader extends StatelessWidget {
  final String text;
  final int flex;
  const _TableHeader({required this.text, required this.flex});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: flex,
      child: Text(text,
          style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: Color(0xFF6B7280))),
    );
  }
}

class _ARTableRow extends StatelessWidget {
  final ARRecordModel record;
  const _ARTableRow({required this.record});

  @override
  Widget build(BuildContext context) {
    // ← fix: initialized with a default so it's never unassigned
    Color agingColor;
    String agingLabel;

    switch (record.aging) {
      case AgingBucket.days0to30:
        agingColor = const Color(0xFF16A34A);
        agingLabel = '0-30 days';
        break;
      case AgingBucket.days31to60:
        agingColor = const Color(0xFFD97706);
        agingLabel = '31-60 days';
        break;
      case AgingBucket.days61to90:
        agingColor = const Color(0xFFDC2626);
        agingLabel = '61-90 days';
        break;
      case AgingBucket.days90plus:
        agingColor = const Color(0xFF374151);
        agingLabel = '90+ days';
        break;
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Text(record.arId,
                style: const TextStyle(
                    fontSize: 12, color: Color(0xFF111827))),
          ),
          Expanded(
            flex: 3,
            child: Text(record.customer,
                style: const TextStyle(
                    fontSize: 12, color: Color(0xFF111827))),
          ),
          Expanded(
            flex: 2,
            child: Text(record.invoiceDate,
                style: const TextStyle(
                    fontSize: 11, color: Color(0xFF6B7280))),
          ),
          Expanded(
            flex: 2,
            child: Text(record.dueDate,
                style: const TextStyle(
                    fontSize: 11, color: Color(0xFF6B7280))),
          ),
          Expanded(
            flex: 2,
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
              decoration: BoxDecoration(
                color: agingColor.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                agingLabel,
                style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    color: agingColor),
              ),
            ),
          ),
        ],
      ),
    );
  }
}