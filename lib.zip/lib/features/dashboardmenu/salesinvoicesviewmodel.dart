// import 'package:flutter/foundation.dart';

// class SalesInvoicesViewModel extends ChangeNotifier {
//   bool _isLoading = false;
//   String _searchQuery = '';
//   List<SalesInvoiceModel> _allInvoices = [];

//   bool get isLoading => _isLoading;
//   double get totalSales =>
//       _allInvoices.fold(0, (sum, inv) => sum + inv.amount);

//   List<SalesInvoiceModel> get filteredInvoices {
//     if (_searchQuery.isEmpty) return _allInvoices;
//     final q = _searchQuery.toLowerCase();
//     return _allInvoices
//         .where((inv) =>
//             inv.id.toLowerCase().contains(q) ||
//             inv.customerName.toLowerCase().contains(q))
//         .toList();
//   }

//   Future<void> loadInvoices() async {
//     _isLoading = true;
//     notifyListeners();
//     await Future.delayed(const Duration(milliseconds: 500));
//     _allInvoices = [
//       SalesInvoiceModel(
//         id: 'INV-2024-1245',
//         customerName: 'Ahmed Al Mansouri',
//         date: '2024-03-31',
//         jobCardRef: 'JC-2024-001',
//         type: 'Service',
//         payment: 'Bank',
//         amount: 4250,
//         status: InvoiceStatus.paid,
//       ),
//       SalesInvoiceModel(
//         id: 'INV-2024-1246',
//         customerName: 'Sara Abdullah',
//         date: '2024-03-31',
//         jobCardRef: 'JC-2024-012',
//         type: 'Parts',
//         payment: 'Cash',
//         amount: 1850,
//         status: InvoiceStatus.paid,
//       ),
//       SalesInvoiceModel(
//         id: 'INV-2024-1247',
//         customerName: 'Mohammed Youssef',
//         date: '2024-03-30',
//         jobCardRef: 'JC-2024-009',
//         type: 'Service',
//         payment: 'Card',
//         amount: 3200,
//         status: InvoiceStatus.paid,
//       ),
//       SalesInvoiceModel(
//         id: 'INV-2024-1248',
//         customerName: 'Layla Hassan',
//         date: '2024-03-30',
//         jobCardRef: 'JC-2024-008',
//         type: 'Service',
//         payment: 'Bank',
//         amount: 5500,
//         status: InvoiceStatus.unpaid,
//       ),
//       SalesInvoiceModel(
//         id: 'INV-2024-1249',
//         customerName: 'Khalid Al Rashid',
//         date: '2024-03-29',
//         jobCardRef: 'JC-2024-007',
//         type: 'Parts',
//         payment: 'Cash',
//         amount: 9250,
//         status: InvoiceStatus.paid,
//       ),
//     ];
//     _isLoading = false;
//     notifyListeners();
//   }

//   void onSearch(String query) {
//     _searchQuery = query;
//     notifyListeners();
//   }

//   void onViewInvoice(SalesInvoiceModel invoice) {}
//   void onDownload() {}
// }