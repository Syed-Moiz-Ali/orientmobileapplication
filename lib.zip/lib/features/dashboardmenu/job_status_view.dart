import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'job_status_model.dart';
import 'job_status_viewmodel.dart';

class JobStatusView extends StatefulWidget {
  const JobStatusView({super.key});

  @override
  State<JobStatusView> createState() => _JobStatusViewState();
}

class _JobStatusViewState extends State<JobStatusView> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<JobStatusViewModel>().load();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<JobStatusViewModel>(
      builder: (context, vm, _) => Scaffold(
        backgroundColor: Colors.white,
        appBar: _buildAppBar(vm),
        body: vm.isLoading
            ? const Center(
                child: CircularProgressIndicator(color: Color(0xFF2563EB)))
            : Column(
                children: [
                  _FilterStrip(vm: vm),
                  Expanded(
                    child: vm.filtered.isEmpty
                        ? const Center(
                            child: Text('No job cards found.',
                                style: TextStyle(color: Color(0xFF6B7280))))
                        : ListView.separated(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            itemCount: vm.filtered.length,
                            separatorBuilder: (_, __) => const Divider(
                                height: 1, color: Color(0xFFE5E7EB)),
                            itemBuilder: (_, i) =>
                                _JobStatusItem(job: vm.filtered[i]),
                          ),
                  ),
                ],
              ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(JobStatusViewModel vm) {
    return AppBar(
      backgroundColor: Colors.white,
      elevation: 0,
      leading: IconButton(
        icon: const Icon(Icons.menu, color: Color(0xFF374151)),
        onPressed: () {},
      ),
      title: const Text(
        'Job Status Tracking',
        style: TextStyle(
            color: Color(0xFF111827),
            fontSize: 17,
            fontWeight: FontWeight.w600),
      ),
      centerTitle: true,
      actions: [
        IconButton(
          icon: const Icon(Icons.notifications_outlined,
              color: Color(0xFF374151)),
          onPressed: () {},
        ),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(52),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
          child: Container(
            height: 42,
            decoration: BoxDecoration(
              color: const Color(0xFFF3F4F6),
              borderRadius: BorderRadius.circular(8),
            ),
            child: TextField(
              onChanged: vm.onSearch,
              style: const TextStyle(fontSize: 14),
              decoration: const InputDecoration(
                hintText: 'Search job cards...',
                hintStyle: TextStyle(color: Color(0xFF9CA3AF), fontSize: 14),
                prefixIcon:
                    Icon(Icons.search, color: Color(0xFF9CA3AF), size: 20),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ── Filter Strip ──────────────────────────────────────────────
class _FilterStrip extends StatelessWidget {
  final JobStatusViewModel vm;
  const _FilterStrip({required this.vm});

  static const _chips = <String, JobStage?>{
    'All': null,
    'Inspection': JobStage.waitingInspection,
    'Pre-Request': JobStage.waitingPreRequest,
    'Estimation': JobStage.waitingEstimation,
    'Approval': JobStage.waitingApproval,
    'Parts': JobStage.waitingParts,
    'WIP': JobStage.wip,
    'Completed': JobStage.completed,
    'Invoice': JobStage.invoice,
    'Gate Pass': JobStage.gatePassOut,
    'Cancelled': JobStage.cancelled,
  };

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 44,
      decoration: const BoxDecoration(
          border: Border(bottom: BorderSide(color: Color(0xFFE5E7EB)))),
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        children: _chips.entries.map((e) {
          final isActive = vm.filterStage == e.value;
          return GestureDetector(
            onTap: () => vm.setFilter(e.value),
            child: Container(
              margin: const EdgeInsets.only(right: 6),
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                color: isActive
                    ? const Color(0xFF111827)
                    : Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: isActive
                      ? const Color(0xFF111827)
                      : const Color(0xFFD1D5DB),
                ),
              ),
              child: Center(
                child: Text(
                  e.key,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                    color: isActive
                        ? Colors.white
                        : const Color(0xFF374151),
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

// ── Job Status Item ───────────────────────────────────────────
class _JobStatusItem extends StatelessWidget {
  final JobStatusModel job;
  const _JobStatusItem({required this.job});

  @override
  Widget build(BuildContext context) {
    final stage = job.stage;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(job.jobCardId,
                        style: const TextStyle(
                            fontSize: 11, color: Color(0xFF6B7280))),
                    const SizedBox(height: 2),
                    Text(job.customerName,
                        style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF111827))),
                    const SizedBox(height: 2),
                    Text(job.vehicleInfo,
                        style: const TextStyle(
                            fontSize: 12, color: Color(0xFF6B7280))),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                    color: stage.bgColor,
                    borderRadius: BorderRadius.circular(20)),
                child: Text(
                  stage.label,
                  style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: stage.color),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),

          // Progress bar
          ClipRRect(
            borderRadius: BorderRadius.circular(2),
            child: LinearProgressIndicator(
              value: stage.progress,
              minHeight: 5,
              backgroundColor: const Color(0xFFF3F4F6),
              valueColor: AlwaysStoppedAnimation<Color>(stage.color),
            ),
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Inspection',
                  style: const TextStyle(
                      fontSize: 10, color: Color(0xFF9CA3AF))),
              Text('Gate pass',
                  style: const TextStyle(
                      fontSize: 10, color: Color(0xFF9CA3AF))),
            ],
          ),
          const SizedBox(height: 6),

          // Meta row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(job.assignedTo,
                  style: const TextStyle(
                      fontSize: 12, color: Color(0xFF6B7280))),
              Text('AED ${job.estimatedAmount.toStringAsFixed(2)}',
                  style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF111827))),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Due: ${job.dueDate}',
                  style: const TextStyle(
                      fontSize: 11, color: Color(0xFF9CA3AF))),
            ],
          ),
        ],
      ),
    );
  }
}