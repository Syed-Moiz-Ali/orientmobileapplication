import 'package:flutter/material.dart';
import 'package:orientmobileapplication/features/dashboardmenu/pendingapprovalcategorymodel.dart';

class PendingApprovalsViewModel extends ChangeNotifier {
  bool _isLoading = false;
  List<ApprovalCategoryModel> _categories = [];

  bool get isLoading => _isLoading;
  List<ApprovalCategoryModel> get categories => _categories;
  int get totalPending => _categories.fold(0, (sum, c) => sum + c.count);

  Future<void> loadApprovals() async {
    _isLoading = true;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 500));
    _categories = [
      ApprovalCategoryModel(
        title: 'Purchase Order',
        subtitle: 'Tap to view details',
        count: 8,
        iconBg: const Color(0xFF2563EB),
        icon: Icons.shopping_cart_outlined,
      ),
      ApprovalCategoryModel(
        title: 'OPEN JOB CARD',
        subtitle: 'Tap to view details',
        count: 8,
        iconBg: const Color(0xFF2563EB),
        icon: Icons.shopping_cart_outlined,
      ),
      ApprovalCategoryModel(
        title: 'WORK IN PROGRESS ',
        subtitle: 'Tap to view details',
        count: 8,
        iconBg: const Color(0xFF2563EB),
        icon: Icons.shopping_cart_outlined,
      ),
      ApprovalCategoryModel(
        title: 'JOB COMPLETED ',
        subtitle: 'Tap to view details',
        count: 8,
        iconBg: const Color(0xFF2563EB),
        icon: Icons.shopping_cart_outlined,
      ),
       ApprovalCategoryModel(
        title: 'JOB COMPLETED ',
        subtitle: 'Tap to view details',
        count: 8,
        iconBg: const Color(0xFF2563EB),
        icon: Icons.shopping_cart_outlined,
      ),
       ApprovalCategoryModel(
        title: 'JOB COMPLETED ',
        subtitle: 'Tap to view details',
        count: 8,
        iconBg: const Color(0xFF2563EB),
        icon: Icons.shopping_cart_outlined,
      ),
       ApprovalCategoryModel(
        title: 'JOB CANCELLED ',
        subtitle: 'Tap to view details',
        count: 8,
        iconBg: const Color(0xFF2563EB),
        icon: Icons.shopping_cart_outlined,
      ),
      ApprovalCategoryModel(
        title: 'INVOICE RAISED',
        subtitle: 'Tap to view details',
        count: 8,
        iconBg: const Color(0xFF2563EB),
        icon: Icons.shopping_cart_outlined,
      ),
      ApprovalCategoryModel(
        title: 'Sales Return',
        subtitle: 'Tap to view details',
        count: 3,
        iconBg: const Color(0xFFEF4444),
        icon: Icons.undo_rounded,
      ),
      ApprovalCategoryModel(
        title: 'Purchase Return',
        subtitle: 'Tap to view details',
        count: 2,
        iconBg: const Color(0xFFF97316),
        icon: Icons.replay_rounded,
      ),
      ApprovalCategoryModel(
        title: 'Petty Cash',
        subtitle: 'Tap to view details',
        count: 5,
        iconBg: const Color(0xFF22C55E),
        icon: Icons.account_balance_wallet_outlined,
      ),
      ApprovalCategoryModel(
        title: 'Journal Voucher',
        subtitle: 'Tap to view details',
        count: 4,
        iconBg: const Color(0xFF8B5CF6),
        icon: Icons.description_outlined,
      ),
      ApprovalCategoryModel(
        title: 'Job Card to Invoice',
        subtitle: 'Tap to view details',
        count: 12,
        iconBg: const Color(0xFF6366F1),
        icon: Icons.receipt_long_outlined,
      ),
    ];
    _isLoading = false;
    notifyListeners();
  }

  void onCategoryTap(ApprovalCategoryModel category) {}
}