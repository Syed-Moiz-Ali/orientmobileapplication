// ─────────────────────────────────────────────────────────────────────────────
// supervisor_dashboard_view.dart  — Refined Slate & Teal Professional Mobile
// lib/features/supervisor/view/supervisor_dashboard_view.dart
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:orientmobileapplication/features/supervisor/supervisor_dasboard_view_model.dart';
import 'package:orientmobileapplication/features/supervisor/supervisor_models.dart';
import 'package:provider/provider.dart';

// ─────────────────────────────────────────────────────────────────────────────
// DESIGN TOKENS — Slate + Teal + Warm Whites
// ─────────────────────────────────────────────────────────────────────────────

abstract class SC {
  // ── Brand core ──────────────────────────────────────────────────────────────
  static const primary = Color(0xFF0F4C75);
  static const accent = Color(0xFF1B9AAA);
  static const accentLight = Color(0xFFE0F4F6);
  static const accentMid = Color(0xFFB2E0E5);

  // ── Surface ─────────────────────────────────────────────────────────────────
  static const scaffold = Color(0xFFF5F7FA);
  static const surface = Color(0xFFFFFFFF);
  static const surfaceAlt = Color(0xFFF0F3F7);
  static const border = Color(0xFFE2E8EF);

  // ── Text ────────────────────────────────────────────────────────────────────
  static const textH = Color(0xFF0A1628);
  static const textB = Color(0xFF253347);
  static const textM = Color(0xFF5C6E85);

  // ── Semantic status ─────────────────────────────────────────────────────────
  static const green = Color(0xFF1A8754);
  static const greenBg = Color(0xFFEAF7EF);
  static const amber = Color(0xFFD97706);
  static const amberBg = Color(0xFFFFF8EC);
  static const red = Color(0xFFB91C1C);
  static const redBg = Color(0xFFFEECEC);
  static const purple = Color(0xFF6D28D9);
  static const purpleBg = Color(0xFFF0EAFC);

  // ── Gradient helpers ────────────────────────────────────────────────────────
  static const gradientStart = Color(0xFF0F4C75);
  static const gradientEnd = Color(0xFF1B9AAA);
}

// ─────────────────────────────────────────────────────────────────────────────
// ENTRY POINT
// ─────────────────────────────────────────────────────────────────────────────

class SupervisorDashboardView extends StatelessWidget {
  const SupervisorDashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => SupervisorDashboardViewModel(),
      child: const _SupervisorBody(),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SCAFFOLD
// ─────────────────────────────────────────────────────────────────────────────

class _SupervisorBody extends StatelessWidget {
  const _SupervisorBody();

  static const _pages = <Widget>[
    _DashboardPage(),
    _AssignWorkPage(),
    _WorkListPage(),
  ];

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<SupervisorDashboardViewModel>();

    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: SC.primary,
        statusBarIconBrightness: Brightness.light,
      ),
    );

    return Scaffold(
      backgroundColor: SC.scaffold,
      appBar: _AppBar(vm: vm),
      body: IndexedStack(index: vm.selectedIndex, children: _pages),
      floatingActionButton: vm.selectedIndex == 1
          ? FloatingActionButton.extended(
              onPressed: vm.saveAndAssign,
              backgroundColor: SC.accent,
              elevation: 4,
              icon: vm.isAssignWorkLoading
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 2.5,
                      ),
                    )
                  : const Icon(Icons.save_rounded, color: Colors.white),
              label: const Text(
                'Save & Assign',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.3,
                ),
              ),
            )
          : null,
      bottomNavigationBar: _BottomNav(
        selectedIndex: vm.selectedIndex,
        onTap: vm.selectTab,
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// APP BAR
// ─────────────────────────────────────────────────────────────────────────────

class _AppBar extends StatelessWidget implements PreferredSizeWidget {
  final SupervisorDashboardViewModel vm;
  const _AppBar({required this.vm});

  static const _titles = ['Dashboard', 'Assign Work', 'Work List'];
  static const _subtitles = [
    'Overview & Analytics',
    'Assign Tasks to Technicians',
    'All Job Assignments',
  ];

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight + 1);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      flexibleSpace: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [SC.gradientStart, SC.gradientEnd],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
        ),
      ),
      backgroundColor: Colors.transparent,
      elevation: 0,
      systemOverlayStyle: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
      ),
      titleSpacing: 0,
      leading: Padding(
        padding: const EdgeInsets.all(10),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.15),
            borderRadius: BorderRadius.circular(10),
          ),
          child: const Icon(
            Icons.build_circle_rounded,
            color: Colors.white,
            size: 24,
          ),
        ),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            _titles[vm.selectedIndex],
            style: GoogleFonts.rajdhani(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.5,
            ),
          ),
          Text(
            _subtitles[vm.selectedIndex],
            style: GoogleFonts.rajdhani(
              color: Colors.white70,
              fontSize: 12,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.4,
            ),
          ),
        ],
      ),
      actions: [
        // Notification bell
        Stack(
          clipBehavior: Clip.none,
          children: [
            IconButton(
              icon: const Icon(
                Icons.notifications_outlined,
                color: Colors.white,
                size: 27,
              ),
              onPressed: () {},
            ),
            Positioned(
              right: 10,
              top: 10,
              child: Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: const Color(0xFFFBBF24),
                  shape: BoxShape.circle,
                  border: Border.all(color: SC.gradientStart, width: 1.5),
                ),
              ),
            ),
          ],
        ),
        // Avatar
        Padding(
          padding: const EdgeInsets.only(right: 14),
          child: GestureDetector(
            onTap: () => _showProfile(context),
            child: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.20),
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.white.withOpacity(0.5),
                  width: 1.5,
                ),
              ),
              child: const Center(
                child: Text(
                  'S',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(height: 1, color: Colors.white.withOpacity(0.12)),
      ),
    );
  }

  void _showProfile(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: SC.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: SC.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 24),
            Container(
              width: 68,
              height: 68,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [SC.gradientStart, SC.gradientEnd],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
              ),
              child: const Center(
                child: Text(
                  'S',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 14),
            const Text(
              'Supervisor',
              style: TextStyle(
                color: SC.textH,
                fontSize: 19,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.3,
              ),
            ),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: SC.accentLight,
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Text(
                'Admin • Auto Garage ERP',
                style: TextStyle(
                  color: SC.accent,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 28),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: OutlinedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.of(context).pop();
                },
                style: OutlinedButton.styleFrom(
                  foregroundColor: SC.red,
                  side: const BorderSide(color: SC.red, width: 1.5),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                icon: const Icon(Icons.logout_rounded, size: 18),
                label: const Text(
                  'Logout',
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// BOTTOM NAV
// ─────────────────────────────────────────────────────────────────────────────

class _BottomNav extends StatelessWidget {
  final int selectedIndex;
  final void Function(int) onTap;
  const _BottomNav({required this.selectedIndex, required this.onTap});

  @override
  Widget build(BuildContext context) {
    const items = [
      (Icons.dashboard_rounded, Icons.dashboard_outlined, 'Dashboard'),
      (Icons.assignment_rounded, Icons.assignment_outlined, 'Assign'),
      (Icons.list_alt_rounded, Icons.list_alt_outlined, 'Work List'),
    ];

    return Container(
      decoration: BoxDecoration(
        color: SC.surface,
        border: const Border(top: BorderSide(color: SC.border)),
        boxShadow: [
          BoxShadow(
            color: SC.primary.withOpacity(0.07),
            blurRadius: 16,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 74,
          child: Row(
            children: List.generate(items.length, (i) {
              final sel = selectedIndex == i;
              return Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => onTap(i),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 220),
                        curve: Curves.easeOutCubic,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: sel ? SC.accentLight : Colors.transparent,
                          borderRadius: BorderRadius.circular(24),
                        ),
                        child: Icon(
                          sel ? items[i].$1 : items[i].$2,
                          color: sel ? SC.accent : SC.textM,
                          size: 26,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        items[i].$3,
                        style: TextStyle(
                          fontSize: 11,
                          color: sel ? SC.accent : SC.textM,
                          fontWeight: sel ? FontWeight.w800 : FontWeight.w500,
                          letterSpacing: sel ? 0.2 : 0,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE 1 — DASHBOARD
// ─────────────────────────────────────────────────────────────────────────────

class _DashboardPage extends StatelessWidget {
  const _DashboardPage();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<SupervisorDashboardViewModel>();

    if (vm.isDashboardLoading) {
      return const Center(
        child: CircularProgressIndicator(color: SC.accent, strokeWidth: 2.5),
      );
    }

    return RefreshIndicator(
      onRefresh: vm.refreshDashboard,
      color: SC.accent,
      strokeWidth: 2.5,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _HeaderBanner(),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 22, 16, 28),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _SectionLabel('Overview'),
                  const SizedBox(height: 12),
                  _KpiScroll(kpis: vm.kpis),
                  const SizedBox(height: 26),

                  _SectionLabel('Job Analysis'),
                  const SizedBox(height: 12),
                  _AdvisorBarCard(data: vm.advisorJobData),
                  const SizedBox(height: 12),
                  _JobTypeCard(types: vm.jobTypes),
                  const SizedBox(height: 26),

                  _SectionLabel('Revenue Overview'),
                  const SizedBox(height: 12),
                  // FIX: replaced GridView with a Column of Rows so each card
                  // can be as tall as its content needs — no more overflow.
                  _RevenueGrid(metrics: vm.revenueMetrics),
                  const SizedBox(height: 12),
                  const _RevenueTrendCard(),
                  const SizedBox(height: 26),

                  _SectionLabel('Pending Status'),
                  const SizedBox(height: 12),
                  _PendingGrid(statuses: vm.pendingStatuses),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _SectionLabel(String text) => Row(
    children: [
      Container(
        width: 4,
        height: 20,
        decoration: BoxDecoration(
          color: SC.accent,
          borderRadius: BorderRadius.circular(2),
        ),
      ),
      const SizedBox(width: 10),
      Text(
        text,
        style: GoogleFonts.rajdhani(
          color: SC.textH,
          fontSize: 19,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.5,
        ),
      ),
    ],
  );
}

// ── Header banner ─────────────────────────────────────────────────────────────

class _HeaderBanner extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 22, 20, 26),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [SC.gradientStart, SC.gradientEnd],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(32)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      margin: const EdgeInsets.only(right: 6, top: 1),
                      decoration: const BoxDecoration(
                        color: Color(0xFF4ADEDF),
                        shape: BoxShape.circle,
                      ),
                    ),
                    const Text(
                      'Live',
                      style: TextStyle(
                        color: Color(0xFF4ADEDF),
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                const Text(
                  'Good Morning,',
                  style: TextStyle(color: Colors.white70, fontSize: 14),
                ),
                Text(
                  'Supervisor',
                  style: GoogleFonts.orbitron(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    height: 1.2,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    _pill(
                      Icons.pending_actions_rounded,
                      '24 Pending',
                      const Color(0xFFFBBF24),
                    ),
                    const SizedBox(width: 8),
                    _pill(
                      Icons.check_circle_outline_rounded,
                      '8 Delivery',
                      const Color(0xFF4ADEDF),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            width: 68,
            height: 68,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.14),
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.white.withOpacity(0.25),
                width: 1.5,
              ),
            ),
            child: const Icon(
              Icons.garage_rounded,
              color: Colors.white,
              size: 34,
            ),
          ),
        ],
      ),
    );
  }

  Widget _pill(IconData icon, String label, Color accent) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: accent.withOpacity(0.4), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: accent, size: 14),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

// ── KPI scroll ────────────────────────────────────────────────────────────────

class _KpiScroll extends StatelessWidget {
  final List<SupervisorKpiModel> kpis;
  const _KpiScroll({required this.kpis});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 160,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: kpis.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (_, i) => _KpiCard(kpi: kpis[i]),
      ),
    );
  }
}

class _KpiCard extends StatelessWidget {
  final SupervisorKpiModel kpi;
  const _KpiCard({required this.kpi});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 168,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: SC.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: SC.border),
        boxShadow: [
          BoxShadow(
            color: SC.primary.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: kpi.color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(kpi.icon, color: kpi.color, size: 22),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                decoration: BoxDecoration(
                  color: SC.greenBg,
                  borderRadius: BorderRadius.circular(7),
                ),
                child: Text(
                  kpi.sub,
                  style: const TextStyle(
                    color: SC.green,
                    fontSize: 9,
                    fontWeight: FontWeight.w700,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const Spacer(),
          Text(
            kpi.value,
            style: GoogleFonts.orbitron(
              color: SC.textH,
              fontSize: 24,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.3,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            kpi.label,
            style: GoogleFonts.rajdhani(
              color: SC.textM,
              fontSize: 13,
              fontWeight: FontWeight.w800,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

// ── Advisor bar chart card ────────────────────────────────────────────────────

class _AdvisorBarCard extends StatelessWidget {
  final List<AdvisorJobData> data;
  const _AdvisorBarCard({required this.data});

  @override
  Widget build(BuildContext context) {
    final maxVal = data.map((d) => d.count).reduce((a, b) => a > b ? a : b);

    return _SurfaceCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _CardTitle('Job Cards — Advisor Wise'),
          const SizedBox(height: 20),
          SizedBox(
            height: 180,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: data.map((b) {
                final frac = maxVal > 0 ? b.count / maxVal : 0.0;
                return Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          '${b.count.toInt()}',
                          style: const TextStyle(
                            color: SC.accent,
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Container(
                          height: 130 * frac,
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [SC.gradientEnd, SC.gradientStart],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          b.name.split(' ').first,
                          style: const TextStyle(
                            color: SC.textB,
                            fontSize: 10.5,
                            fontWeight: FontWeight.w600,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Job type donut card ───────────────────────────────────────────────────────

class _JobTypeCard extends StatelessWidget {
  final List<JobTypeData> types;
  const _JobTypeCard({required this.types});

  @override
  Widget build(BuildContext context) {
    final total = types.fold(0, (s, t) => s + t.count);
    return _SurfaceCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _CardTitle('Job Card by Type'),
          const SizedBox(height: 18),
          Row(
            children: [
              SizedBox(
                width: 110,
                height: 110,
                child: CustomPaint(painter: _PiePainter(types)),
              ),
              const SizedBox(width: 22),
              Expanded(
                child: Column(
                  children: types.map((t) {
                    final pct = total > 0
                        ? (t.count / total * 100).toStringAsFixed(0)
                        : '0';
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Row(
                        children: [
                          Container(
                            width: 12,
                            height: 12,
                            decoration: BoxDecoration(
                              color: t.color,
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              t.label,
                              style: const TextStyle(
                                color: SC.textB,
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          Text(
                            '$pct%',
                            style: const TextStyle(
                              color: SC.textH,
                              fontSize: 14,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PiePainter extends CustomPainter {
  final List<JobTypeData> types;
  const _PiePainter(this.types);

  @override
  void paint(Canvas canvas, Size size) {
    final total = types.fold(0, (s, t) => s + t.count);
    if (total == 0) return;
    final rect = Rect.fromLTWH(2, 2, size.width - 4, size.height - 4);
    double start = -1.5708;
    for (final t in types) {
      final sweep = 2 * 3.14159 * t.count / total;
      canvas.drawArc(rect, start, sweep, true, Paint()..color = t.color);
      start += sweep;
    }
    canvas.drawCircle(
      size.center(Offset.zero),
      size.width * 0.30,
      Paint()..color = Colors.white,
    );
  }

  @override
  bool shouldRepaint(_) => false;
}

// ── Revenue grid — FIX: replaced fixed-aspect GridView with intrinsic rows ───
//
// ROOT CAUSE of overflow: GridView with childAspectRatio: 1.45 allocated a
// fixed height per cell. With Orbitron font rendering at a larger height than
// system default, the label text overflowed by 3 px on every card.
//
// FIX: Use a plain Column + Row layout so each card sizes to its content.
// We build pairs of metrics as side-by-side rows, identical visual style.

class _RevenueGrid extends StatelessWidget {
  final List<RevenueMetric> metrics;
  const _RevenueGrid({required this.metrics});

  @override
  Widget build(BuildContext context) {
    // Split into pairs for 2-column layout
    final rows = <Widget>[];
    for (var i = 0; i < metrics.length; i += 2) {
      final left = metrics[i];
      final right = i + 1 < metrics.length ? metrics[i + 1] : null;
      rows.add(
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(child: _RevenueMetricCard(metric: left)),
            const SizedBox(width: 12),
            right != null
                ? Expanded(child: _RevenueMetricCard(metric: right))
                : const Expanded(child: SizedBox()),
          ],
        ),
      );
      if (i + 2 < metrics.length) rows.add(const SizedBox(height: 12));
    }
    return Column(children: rows);
  }
}

class _RevenueMetricCard extends StatelessWidget {
  final RevenueMetric metric;
  const _RevenueMetricCard({required this.metric});

  @override
  Widget build(BuildContext context) {
    return Container(
      // FIX: removed fixed height constraint — let content define height
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
      decoration: BoxDecoration(
        color: SC.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: SC.border),
        boxShadow: [
          BoxShadow(
            color: SC.primary.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        // FIX: mainAxisSize.min so the Column only takes the space it needs
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: SC.accentLight,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(metric.icon, color: SC.accent, size: 18),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                decoration: BoxDecoration(
                  color: SC.greenBg,
                  borderRadius: BorderRadius.circular(7),
                ),
                child: Text(
                  metric.change,
                  style: const TextStyle(
                    color: SC.green,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          // FIX: increased top spacing slightly so text has breathing room
          const SizedBox(height: 12),
          Text(
            metric.amount,
            style: GoogleFonts.orbitron(
              color: SC.textH,
              fontSize: 16,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.3,
              height: 1.2, // FIX: explicit line-height so Orbitron doesn't clip
            ),
          ),
          const SizedBox(height: 5),
          Text(
            metric.label,
            style: GoogleFonts.rajdhani(
              color: SC.textM,
              fontSize: 12.5,
              fontWeight: FontWeight.w600,
              height: 1.3,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

// ── Revenue trend card ────────────────────────────────────────────────────────

class _RevenueTrendCard extends StatelessWidget {
  const _RevenueTrendCard();

  @override
  Widget build(BuildContext context) {
    return _SurfaceCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const _CardTitle('Revenue Trend'),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: SC.accentLight,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text(
                  'This Year',
                  style: TextStyle(
                    color: SC.accent,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          SizedBox(
            height: 120,
            child: CustomPaint(size: Size.infinite, painter: _LinePainter()),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul']
                .map(
                  (m) => Text(
                    m,
                    style: const TextStyle(
                      color: SC.textM,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                )
                .toList(),
          ),
        ],
      ),
    );
  }
}

class _LinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    const pts = [0.65, 0.55, 0.60, 0.40, 0.48, 0.30, 0.35];

    final fillPaint = Paint()
      ..shader = LinearGradient(
        colors: [
          const Color(0xFF1B9AAA).withOpacity(0.22),
          const Color(0xFF1B9AAA).withOpacity(0.0),
        ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
      ..style = PaintingStyle.fill;

    final linePaint = Paint()
      ..color = SC.accent
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final path = Path();
    final fill = Path();

    for (var i = 0; i < pts.length; i++) {
      final x = size.width * i / (pts.length - 1);
      final y = size.height * pts[i];
      if (i == 0) {
        path.moveTo(x, y);
        fill.moveTo(x, y);
      } else {
        path.lineTo(x, y);
        fill.lineTo(x, y);
      }
    }
    fill
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();

    canvas.drawPath(fill, fillPaint);
    canvas.drawPath(path, linePaint);

    final dotPaint = Paint()
      ..color = SC.accent
      ..style = PaintingStyle.fill;
    final ringPaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    for (var i = 0; i < pts.length; i++) {
      final x = size.width * i / (pts.length - 1);
      final y = size.height * pts[i];
      canvas.drawCircle(Offset(x, y), 5, dotPaint);
      canvas.drawCircle(Offset(x, y), 2.5, ringPaint);
    }
  }

  @override
  bool shouldRepaint(_) => false;
}

// ── Pending 2-col grid — same fix applied ─────────────────────────────────────

class _PendingGrid extends StatelessWidget {
  final List<PendingStatusModel> statuses;
  const _PendingGrid({required this.statuses});

  @override
  Widget build(BuildContext context) {
    final rows = <Widget>[];
    for (var i = 0; i < statuses.length; i += 2) {
      final left = statuses[i];
      final right = i + 1 < statuses.length ? statuses[i + 1] : null;
      rows.add(
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(child: _PendingCard(status: left)),
            const SizedBox(width: 12),
            right != null
                ? Expanded(child: _PendingCard(status: right))
                : const Expanded(child: SizedBox()),
          ],
        ),
      );
      if (i + 2 < statuses.length) rows.add(const SizedBox(height: 12));
    }
    return Column(children: rows);
  }
}

class _PendingCard extends StatelessWidget {
  final PendingStatusModel status;
  const _PendingCard({required this.status});

  @override
  Widget build(BuildContext context) {
    final bgTint = Color.lerp(SC.surface, status.color, 0.06)!;

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 13, 11, 14),
      decoration: BoxDecoration(
        color: bgTint,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: status.color.withOpacity(0.18), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: status.color.withOpacity(0.08),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min, // FIX: only take needed height
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: status.color.withOpacity(0.14),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(status.icon, color: status.color, size: 19),
          ),
          const SizedBox(height: 10),
          Text(
            status.count,
            style: GoogleFonts.orbitron(
              color: status.color,
              fontSize: 26,
              fontWeight: FontWeight.w900,
              letterSpacing: -0.5,
              height:
                  1.2, // FIX: explicit line-height prevents Orbitron clipping
            ),
          ),
          const SizedBox(height: 5),
          Text(
            status.label,
            style: GoogleFonts.rajdhani(
              color: SC.textB,
              fontSize: 12.5,
              fontWeight: FontWeight.w600,
              height: 1.3,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE 2 — ASSIGN WORK
// ─────────────────────────────────────────────────────────────────────────────

class _AssignWorkPage extends StatelessWidget {
  const _AssignWorkPage();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<SupervisorDashboardViewModel>();

    return Column(
      children: [
        Container(
          color: SC.surface,
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
          child: _SearchField(
            hint: 'Search or enter job card number...',
            onChanged: vm.updateJobCardSearch,
          ),
        ),
        const Divider(height: 1, color: SC.border),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 100),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Text(
                      'Work Assignments',
                      style: TextStyle(
                        color: SC.textH,
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.3,
                      ),
                    ),
                    const Spacer(),
                    _TealChipButton(
                      icon: Icons.add_rounded,
                      label: 'Add Task',
                      onTap: vm.addAssignmentRow,
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                ...vm.assignmentRows.asMap().entries.map(
                  (e) => Padding(
                    key: ValueKey(e.value.id),
                    padding: const EdgeInsets.only(bottom: 14),
                    child: _AssignmentCard(
                      row: e.value,
                      index: e.key + 1,
                      departments: vm.departments,
                      technicians: vm.technicians,
                      onDelete: () => vm.removeAssignmentRow(e.value.id),
                      onChanged: (updated) =>
                          vm.updateAssignmentRow(e.value.id, updated),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _AssignmentCard extends StatefulWidget {
  final WorkAssignmentRow row;
  final int index;
  final List<String> departments;
  final List<String> technicians;
  final VoidCallback onDelete;
  final void Function(WorkAssignmentRow) onChanged;

  const _AssignmentCard({
    required this.row,
    required this.index,
    required this.departments,
    required this.technicians,
    required this.onDelete,
    required this.onChanged,
  });

  @override
  State<_AssignmentCard> createState() => _AssignmentCardState();
}

class _AssignmentCardState extends State<_AssignmentCard> {
  late final TextEditingController _descCtrl;
  late final TextEditingController _dateCtrl;
  late final TextEditingController _stdTimeCtrl;
  late final TextEditingController _remarksCtrl;

  @override
  void initState() {
    super.initState();
    _descCtrl = TextEditingController(text: widget.row.description);
    _dateCtrl = TextEditingController(text: widget.row.dateOfWork);
    _stdTimeCtrl = TextEditingController(text: widget.row.stdTime);
    _remarksCtrl = TextEditingController(text: widget.row.remarks);
  }

  @override
  void didUpdateWidget(covariant _AssignmentCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    _syncIfNeeded(_descCtrl, widget.row.description, oldWidget.row.description);
    _syncIfNeeded(_dateCtrl, widget.row.dateOfWork, oldWidget.row.dateOfWork);
    _syncIfNeeded(_stdTimeCtrl, widget.row.stdTime, oldWidget.row.stdTime);
    _syncIfNeeded(_remarksCtrl, widget.row.remarks, oldWidget.row.remarks);
  }

  void _syncIfNeeded(TextEditingController ctrl, String newVal, String oldVal) {
    if (newVal != oldVal && ctrl.text != newVal) {
      ctrl.value = ctrl.value.copyWith(
        text: newVal,
        selection: TextSelection.collapsed(offset: newVal.length),
      );
    }
  }

  @override
  void dispose() {
    _descCtrl.dispose();
    _dateCtrl.dispose();
    _stdTimeCtrl.dispose();
    _remarksCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: SC.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: SC.border),
        boxShadow: [
          BoxShadow(
            color: SC.primary.withOpacity(0.06),
            blurRadius: 12,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
            decoration: const BoxDecoration(
              color: SC.accentLight,
              borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
            ),
            child: Row(
              children: [
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [SC.gradientStart, SC.gradientEnd],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: Center(
                    child: Text(
                      '${widget.index}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                const Text(
                  'Task Details',
                  style: TextStyle(
                    color: SC.accent,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: widget.onDelete,
                  child: Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                      color: SC.redBg,
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: const Icon(
                      Icons.delete_outline_rounded,
                      color: SC.red,
                      size: 16,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                _FormRow(
                  label: 'Description of Work',
                  child: _PersistentInput(
                    controller: _descCtrl,
                    hint: 'Enter work description...',
                    onChanged: (v) =>
                        widget.onChanged(widget.row.copyWith(description: v)),
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: _FormRow(
                        label: 'Department',
                        child: _LightDropdown(
                          value: widget.row.department.isEmpty
                              ? null
                              : widget.row.department,
                          hint: 'Select',
                          items: widget.departments,
                          onChanged: (v) => widget.onChanged(
                            widget.row.copyWith(department: v ?? ''),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _FormRow(
                        label: 'Technician',
                        child: _LightDropdown(
                          value: widget.row.technicianName.isEmpty
                              ? null
                              : widget.row.technicianName,
                          hint: 'Select',
                          items: widget.technicians,
                          onChanged: (v) => widget.onChanged(
                            widget.row.copyWith(technicianName: v ?? ''),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: _FormRow(
                        label: 'Date of Work',
                        child: _PersistentInput(
                          controller: _dateCtrl,
                          hint: 'dd/mm/yyyy',
                          onChanged: (v) => widget.onChanged(
                            widget.row.copyWith(dateOfWork: v),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _FormRow(
                        label: 'Std Time',
                        child: _PersistentInput(
                          controller: _stdTimeCtrl,
                          hint: '2h 30m',
                          onChanged: (v) =>
                              widget.onChanged(widget.row.copyWith(stdTime: v)),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                _FormRow(
                  label: 'Status Completion: ${widget.row.statusPercent}%',
                  child: SliderTheme(
                    data: SliderTheme.of(context).copyWith(
                      trackHeight: 5,
                      thumbShape: const RoundSliderThumbShape(
                        enabledThumbRadius: 9,
                      ),
                      activeTrackColor: SC.accent,
                      inactiveTrackColor: SC.accentMid,
                      thumbColor: SC.accent,
                      overlayColor: SC.accent.withOpacity(0.12),
                    ),
                    child: Slider(
                      value: widget.row.statusPercent.toDouble(),
                      min: 0,
                      max: 100,
                      divisions: 20,
                      onChanged: (v) => widget.onChanged(
                        widget.row.copyWith(statusPercent: v.toInt()),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                _FormRow(
                  label: 'Remarks (optional)',
                  child: _PersistentInput(
                    controller: _remarksCtrl,
                    hint: 'Add any notes...',
                    maxLines: 2,
                    onChanged: (v) =>
                        widget.onChanged(widget.row.copyWith(remarks: v)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGE 3 — WORK LIST
// ─────────────────────────────────────────────────────────────────────────────

class _WorkListPage extends StatelessWidget {
  const _WorkListPage();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<SupervisorDashboardViewModel>();

    return Column(
      children: [
        Container(
          color: SC.surface,
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
          child: Row(
            children: [
              _StatPill(
                label: 'Total',
                value: '${vm.totalAssigned}',
                color: SC.accent,
                bg: SC.accentLight,
              ),
              const SizedBox(width: 8),
              _StatPill(
                label: 'In Progress',
                value: '${vm.inProgressCount}',
                color: SC.amber,
                bg: SC.amberBg,
              ),
              const SizedBox(width: 8),
              _StatPill(
                label: 'Done',
                value: '${vm.completedCount}',
                color: SC.green,
                bg: SC.greenBg,
              ),
              const Spacer(),
              GestureDetector(
                onTap: vm.onNewAssignment,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [SC.gradientStart, SC.gradientEnd],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    borderRadius: BorderRadius.circular(22),
                    boxShadow: [
                      BoxShadow(
                        color: SC.primary.withOpacity(0.25),
                        blurRadius: 8,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.add_rounded, color: Colors.white, size: 14),
                      SizedBox(width: 5),
                      Text(
                        'New',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        const Divider(height: 1, color: SC.border),
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
            itemCount: vm.jobs.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (_, i) => _JobCard(job: vm.jobs[i]),
          ),
        ),
      ],
    );
  }
}

class _StatPill extends StatelessWidget {
  final String label, value;
  final Color color, bg;
  const _StatPill({
    required this.label,
    required this.value,
    required this.color,
    required this.bg,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 15,
              fontWeight: FontWeight.w900,
              letterSpacing: -0.4,
            ),
          ),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              color: color.withOpacity(0.70),
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _JobCard extends StatelessWidget {
  final AssignedJobModel job;
  const _JobCard({required this.job});

  Color get _statusColor {
    switch (job.status) {
      case 'Completed':
        return SC.green;
      case 'In Progress':
        return SC.amber;
      default:
        return SC.red;
    }
  }

  Color get _statusBg {
    switch (job.status) {
      case 'Completed':
        return SC.greenBg;
      case 'In Progress':
        return SC.amberBg;
      default:
        return SC.redBg;
    }
  }

  @override
  Widget build(BuildContext context) {
    final progress = job.total > 0 ? job.done / job.total : 0.0;
    final progressPct = (progress * 100).toInt();
    final taskLabel = '${job.done}/${job.total} tasks';

    return Container(
      decoration: BoxDecoration(
        color: SC.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: SC.border),
        boxShadow: [
          BoxShadow(
            color: SC.primary.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
            decoration: const BoxDecoration(
              color: SC.surfaceAlt,
              borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.receipt_long_rounded,
                  size: 17,
                  color: SC.accent,
                ),
                const SizedBox(width: 7),
                Text(
                  job.jobCard,
                  style: const TextStyle(
                    color: SC.primary,
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.5,
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: _statusBg,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    job.status,
                    style: TextStyle(
                      color: _statusColor,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      radius: 24,
                      backgroundColor: SC.accentLight,
                      child: Text(
                        job.customer[0],
                        style: const TextStyle(
                          color: SC.accent,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            job.customer,
                            style: const TextStyle(
                              color: SC.textH,
                              fontWeight: FontWeight.w700,
                              fontSize: 15,
                            ),
                          ),
                          Text(
                            job.vehicle,
                            style: const TextStyle(
                              color: SC.textM,
                              fontSize: 12.5,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        const Text(
                          'Assigned',
                          style: TextStyle(color: SC.textM, fontSize: 10),
                        ),
                        Text(
                          job.dateAssigned,
                          style: const TextStyle(
                            color: SC.textB,
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                const Divider(height: 1, color: SC.border),
                const SizedBox(height: 12),
                Row(
                  children: [
                    const Text(
                      'Progress',
                      style: TextStyle(color: SC.textM, fontSize: 11),
                    ),
                    const Spacer(),
                    Text(
                      taskLabel,
                      style: const TextStyle(color: SC.textM, fontSize: 11),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      '$progressPct%',
                      style: TextStyle(
                        color: _statusColor,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: progress,
                    backgroundColor: SC.accentMid,
                    valueColor: AlwaysStoppedAnimation(_statusColor),
                    minHeight: 7,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SHARED SMALL WIDGETS
// ─────────────────────────────────────────────────────────────────────────────

class _SurfaceCard extends StatelessWidget {
  final Widget child;
  const _SurfaceCard({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: SC.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: SC.border),
        boxShadow: [
          BoxShadow(
            color: SC.primary.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: child,
    );
  }
}

class _CardTitle extends StatelessWidget {
  final String text;
  const _CardTitle(this.text);

  @override
  Widget build(BuildContext context) => Text(
    text,
    style: GoogleFonts.rajdhani(
      color: SC.textH,
      fontSize: 16,
      fontWeight: FontWeight.w700,
      letterSpacing: 0.3,
    ),
  );
}

class _FormRow extends StatelessWidget {
  final String label;
  final Widget child;
  const _FormRow({required this.label, required this.child});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.rajdhani(
            color: SC.textB,
            fontSize: 13,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.3,
          ),
        ),
        const SizedBox(height: 7),
        child,
      ],
    );
  }
}

class _PersistentInput extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final int maxLines;
  final TextInputType? keyboardType;
  final void Function(String) onChanged;

  const _PersistentInput({
    required this.controller,
    required this.hint,
    required this.onChanged,
    this.maxLines = 1,
    this.keyboardType,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      onChanged: onChanged,
      maxLines: maxLines,
      keyboardType: keyboardType,
      style: const TextStyle(color: SC.textH, fontSize: 13),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: SC.textM, fontSize: 13),
        filled: true,
        fillColor: SC.scaffold,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 13,
          vertical: 13,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11),
          borderSide: const BorderSide(color: SC.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11),
          borderSide: const BorderSide(color: SC.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11),
          borderSide: const BorderSide(color: SC.accent, width: 1.5),
        ),
      ),
    );
  }
}

class _LightDropdown extends StatelessWidget {
  final String? value;
  final String hint;
  final List<String> items;
  final void Function(String?) onChanged;

  const _LightDropdown({
    required this.value,
    required this.hint,
    required this.items,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 46,
      padding: const EdgeInsets.symmetric(horizontal: 13),
      decoration: BoxDecoration(
        color: SC.scaffold,
        borderRadius: BorderRadius.circular(11),
        border: Border.all(color: SC.border),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          hint: Text(
            hint,
            style: const TextStyle(color: SC.textM, fontSize: 13),
          ),
          dropdownColor: SC.surface,
          style: const TextStyle(color: SC.textH, fontSize: 13),
          icon: const Icon(
            Icons.keyboard_arrow_down_rounded,
            color: SC.textM,
            size: 18,
          ),
          isExpanded: true,
          onChanged: onChanged,
          items: items
              .map((i) => DropdownMenuItem(value: i, child: Text(i)))
              .toList(),
        ),
      ),
    );
  }
}

class _SearchField extends StatelessWidget {
  final String hint;
  final void Function(String) onChanged;
  const _SearchField({required this.hint, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return TextField(
      onChanged: onChanged,
      style: const TextStyle(color: SC.textH, fontSize: 14),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: SC.textM, fontSize: 13),
        prefixIcon: const Icon(Icons.search_rounded, color: SC.textM, size: 20),
        filled: true,
        fillColor: SC.scaffold,
        contentPadding: const EdgeInsets.symmetric(vertical: 13),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(13),
          borderSide: const BorderSide(color: SC.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(13),
          borderSide: const BorderSide(color: SC.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(13),
          borderSide: const BorderSide(color: SC.accent, width: 1.5),
        ),
      ),
    );
  }
}

class _TealChipButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _TealChipButton({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [SC.gradientStart, SC.gradientEnd],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(22),
          boxShadow: [
            BoxShadow(
              color: SC.accent.withOpacity(0.28),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: Colors.white, size: 14),
            const SizedBox(width: 6),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
