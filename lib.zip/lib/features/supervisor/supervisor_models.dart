// ─────────────────────────────────────────────────────────────────────────────
// supervisor_models.dart
// lib/features/supervisor/model/supervisor_models.dart
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';

// ── KPI card data ─────────────────────────────────────────────────────────────

class SupervisorKpiModel {
  final IconData icon;
  final Color color;
  final String value;
  final String label;
  final String sub;

  const SupervisorKpiModel({
    required this.icon,
    required this.color,
    required this.value,
    required this.label,
    required this.sub,
  });
}

// ── Advisor bar chart data ────────────────────────────────────────────────────

class AdvisorJobData {
  final String name;
  final double count;

  const AdvisorJobData({required this.name, required this.count});
}

// ── Job type (pie legend) ─────────────────────────────────────────────────────

class JobTypeData {
  final String label;
  final int count;
  final Color color;

  const JobTypeData({
    required this.label,
    required this.count,
    required this.color,
  });
}

// ── Revenue metric ────────────────────────────────────────────────────────────

class RevenueMetric {
  final IconData icon;
  final String amount;
  final String label;
  final String change;

  const RevenueMetric({
    required this.icon,
    required this.amount,
    required this.label,
    required this.change,
  });
}

// ── Pending status tile ───────────────────────────────────────────────────────

class PendingStatusModel {
  final IconData icon;
  final Color color;
  final String count;
  final String label;

  const PendingStatusModel({
    required this.icon,
    required this.color,
    required this.count,
    required this.label,
  });
}

// ── Work assignment row ───────────────────────────────────────────────────────

class WorkAssignmentRow {
  final int id;
  String description;
  String department;
  String technicianName;
  String dateOfWork;
  int statusPercent;
  String stdTime;
  String remarks;

  WorkAssignmentRow({
    required this.id,
    this.description = '',
    this.department = '',
    this.technicianName = '',
    this.dateOfWork = '',
    this.statusPercent = 0,
    this.stdTime = '',
    this.remarks = '',
  });

  WorkAssignmentRow copyWith({
    String? description,
    String? department,
    String? technicianName,
    String? dateOfWork,
    int? statusPercent,
    String? stdTime,
    String? remarks,
  }) {
    return WorkAssignmentRow(
      id: id,
      description: description ?? this.description,
      department: department ?? this.department,
      technicianName: technicianName ?? this.technicianName,
      dateOfWork: dateOfWork ?? this.dateOfWork,
      statusPercent: statusPercent ?? this.statusPercent,
      stdTime: stdTime ?? this.stdTime,
      remarks: remarks ?? this.remarks,
    );
  }
}

// ── Assigned job card ─────────────────────────────────────────────────────────

class AssignedJobModel {
  final String jobCard;
  final String customer;
  final String vehicle;
  final String dateAssigned;
  final int done;
  final int total;
  final String status; // 'In Progress' | 'Completed' | 'Pending'

  const AssignedJobModel({
    required this.jobCard,
    required this.customer,
    required this.vehicle,
    required this.dateAssigned,
    required this.done,
    required this.total,
    required this.status,
  });
}