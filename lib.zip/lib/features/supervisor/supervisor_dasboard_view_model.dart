// ─────────────────────────────────────────────────────────────────────────────
// supervisor_dashboard_viewmodel.dart
// lib/features/supervisor/viewmodel/supervisor_dashboard_viewmodel.dart
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:orientmobileapplication/features/supervisor/supervisor_models.dart';

class SupervisorDashboardViewModel extends ChangeNotifier {
  // ── Navigation ──────────────────────────────────────────────────────────────
  int _selectedIndex = 0;
  int get selectedIndex => _selectedIndex;

  void selectTab(int index) {
    if (_selectedIndex == index) return;
    _selectedIndex = index;
    notifyListeners();
  }

  // ── Loading states ───────────────────────────────────────────────────────────
  bool _isDashboardLoading = false;
  bool _isAssignWorkLoading = false;
  bool _isWorkListLoading = false;

  bool get isDashboardLoading => _isDashboardLoading;
  bool get isAssignWorkLoading => _isAssignWorkLoading;
  bool get isWorkListLoading => _isWorkListLoading;

  // ── Search query (top bar) ───────────────────────────────────────────────────
  String _searchQuery = '';
  String get searchQuery => _searchQuery;

  void updateSearch(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  // ────────────────────────────────────────────────────────────────────────────
  // DASHBOARD — KPI data
  // ────────────────────────────────────────────────────────────────────────────

  List<SupervisorKpiModel> get kpis => const [
    SupervisorKpiModel(
      icon: Icons.description_outlined, // Blue document icon
      color: Color(0xFF1F6FEB),
      value: '24',
      label: 'Total Job Cards Pending',
      sub: '+4 from yesterday',
    ),

    SupervisorKpiModel(
      icon: Icons.calendar_month_outlined, // Green calendar icon
      color: Color(0xFF238636),
      value: '8',
      label: 'Today Delivery Job Cards',
      sub: 'On schedule',
    ),

    SupervisorKpiModel(
      icon: Icons.groups_2_outlined, // Purple people icon
      color: Color(0xFF8957E5),
      value: '18',
      label: 'Total Advisors Present',
      sub: '2 out of 20',
    ),

    SupervisorKpiModel(
      icon: Icons.engineering_outlined, // Orange technician icon
      color: Color(0xFFFF7B00),
      value: '3',
      label: 'Total Idle Technicians',
      sub: 'Assign them now',
    ),

    SupervisorKpiModel(
      icon: Icons.assignment_outlined, // Red clipboard icon
      color: Color(0xFFDA3633),
      value: '12',
      label: 'Waiting to Assign Stock',
      sub: 'Requires attention',
    ),
  ];

  // ── Advisor bar chart ────────────────────────────────────────────────────────

  List<AdvisorJobData> get advisorJobData => const [
    AdvisorJobData(name: 'John Smith', count: 20),
    AdvisorJobData(name: 'Sarah Lee', count: 13),
    AdvisorJobData(name: 'Mike Anwar', count: 18),
    AdvisorJobData(name: 'Emma Wilson', count: 10),
  ];

  // ── Job type (pie) ────────────────────────────────────────────────────────────

  List<JobTypeData> get jobTypes => const [
    JobTypeData(label: 'Regular Service', count: 38, color: Color(0xFF1F6FEB)),
    JobTypeData(label: 'Insurance', count: 28, color: Color(0xFF238636)),
    JobTypeData(label: 'Contract', count: 15, color: Color(0xFFE3B341)),
  ];

  // ── Revenue metrics ───────────────────────────────────────────────────────────

  List<RevenueMetric> get revenueMetrics => const [
    RevenueMetric(
      icon: Icons.trending_up_rounded,
      amount: '\$45,280',
      label: 'Total Revenue',
      change: '+12.4%',
    ),
    RevenueMetric(
      icon: Icons.store_rounded,
      amount: '\$18,920',
      label: 'Service Revenue',
      change: '+8.2%',
    ),
    RevenueMetric(
      icon: Icons.build_rounded,
      amount: '\$8,450',
      label: 'Parts Revenue',
      change: '+3.1%',
    ),
    RevenueMetric(
      icon: Icons.people_rounded,
      amount: '\$12,680',
      label: 'Labour Revenue',
      change: '+24.3%',
    ),
    RevenueMetric(
      icon: Icons.attach_money_rounded,
      amount: '\$5,230',
      label: 'Other Revenue',
      change: '+18.7%',
    ),
  ];

  // ── Pending status ────────────────────────────────────────────────────────────

  List<PendingStatusModel> get pendingStatuses => const [
    PendingStatusModel(
      icon: Icons.access_time_rounded,
      color: Color(0xFFE3B341),
      count: '10',
      label: 'Waiting for Parts',
    ),
    PendingStatusModel(
      icon: Icons.check_circle_outline_rounded,
      color: Color(0xFF238636),
      count: '2',
      label: 'Job Completed Not Invoiced',
    ),
    PendingStatusModel(
      icon: Icons.search_rounded,
      color: Color(0xFFDA3633),
      count: '4',
      label: 'Waiting for Inspection',
    ),
    PendingStatusModel(
      icon: Icons.thumb_up_outlined,
      color: Color(0xFF8957E5),
      count: '6',
      label: 'Waiting for Approval',
    ),
  ];

  // ────────────────────────────────────────────────────────────────────────────
  // ASSIGN WORK
  // ────────────────────────────────────────────────────────────────────────────

  String _jobCardSearch = '';
  String get jobCardSearch => _jobCardSearch;

  void updateJobCardSearch(String value) {
    _jobCardSearch = value;
    notifyListeners();
  }

  int _nextRowId = 2;
  final List<WorkAssignmentRow> _assignmentRows = [WorkAssignmentRow(id: 1)];
  List<WorkAssignmentRow> get assignmentRows =>
      List.unmodifiable(_assignmentRows);

  void addAssignmentRow() {
    _assignmentRows.add(WorkAssignmentRow(id: _nextRowId++));
    notifyListeners();
  }

  void removeAssignmentRow(int id) {
    if (_assignmentRows.length <= 1) return;
    _assignmentRows.removeWhere((r) => r.id == id);
    notifyListeners();
  }

  void updateAssignmentRow(int id, WorkAssignmentRow updated) {
    final index = _assignmentRows.indexWhere((r) => r.id == id);
    if (index == -1) return;
    _assignmentRows[index] = updated;
    notifyListeners();
  }

  final List<String> departments = const [
    'Engine',
    'Body & Paint',
    'Electrical',
    'Tyres & Alignment',
    'AC & Cooling',
    'Transmission',
    'General Service',
  ];

  final List<String> technicians = const [
    'Ali Hassan',
    'Ravi Kumar',
    'Mohammed Salim',
    'David Osei',
    'James Patel',
  ];

  Future<void> saveAndAssign() async {
    _isAssignWorkLoading = true;
    notifyListeners();

    // Replace with your real API call
    await Future.delayed(const Duration(milliseconds: 1200));

    _isAssignWorkLoading = false;
    notifyListeners();
  }

  // ────────────────────────────────────────────────────────────────────────────
  // WORK LIST
  // ────────────────────────────────────────────────────────────────────────────

  final List<AssignedJobModel> _allJobs = const [
    AssignedJobModel(
      jobCard: 'JC-2025-001',
      customer: 'John Anderson',
      vehicle: 'Toyota Camry 2023',
      dateAssigned: '4/20/2026',
      done: 2,
      total: 4,
      status: 'In Progress',
    ),
    AssignedJobModel(
      jobCard: 'JC-2025-002',
      customer: 'Sarah Williams',
      vehicle: 'Honda City 7025',
      dateAssigned: '4/21/2026',
      done: 3,
      total: 3,
      status: 'Completed',
    ),
    AssignedJobModel(
      jobCard: 'JC-2025-003',
      customer: 'Michael Brown',
      vehicle: 'BMW 35 2025',
      dateAssigned: '4/22/2026',
      done: 0,
      total: 5,
      status: 'Pending',
    ),
  ];

  List<AssignedJobModel> get jobs => _allJobs;

  int get totalAssigned => _allJobs.length;
  int get inProgressCount =>
      _allJobs.where((j) => j.status == 'In Progress').length;
  int get completedCount =>
      _allJobs.where((j) => j.status == 'Completed').length;

  void onNewAssignment() {
    // Navigate or open dialog — wired from the view
    selectTab(1);
  }

  // ────────────────────────────────────────────────────────────────────────────
  // Init & dispose
  // ────────────────────────────────────────────────────────────────────────────

  SupervisorDashboardViewModel() {
    _loadDashboard();
  }

  Future<void> _loadDashboard() async {
    _isDashboardLoading = true;
    notifyListeners();

    // Replace with real API fetch
    await Future.delayed(const Duration(milliseconds: 600));

    _isDashboardLoading = false;
    notifyListeners();
  }

  Future<void> refreshDashboard() => _loadDashboard();
}
