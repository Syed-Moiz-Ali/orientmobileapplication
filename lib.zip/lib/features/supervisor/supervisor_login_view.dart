// import 'package:flutter/material.dart';
// import 'package:orientmobileapplication/features/supervisor/supervisor_dashboard_view.dart';

// class SupervisorLoginView extends StatefulWidget {
//   const SupervisorLoginView({super.key});

//   @override
//   State<SupervisorLoginView> createState() => _SupervisorLoginViewState();
// }

// class _SupervisorLoginViewState extends State<SupervisorLoginView> {
//   final _usernameController = TextEditingController();
//   final _passwordController = TextEditingController();
//   bool _obscurePassword = true;
//   bool _isLoading = false;
//   String? _error;

//   static const _bg = Color(0xFF0A0E1A);
//   static const _card = Color(0xFF111827);
//   static const _accent = Color(0xFF2563EB);
//   static const _border = Color(0xFF1E2D4A);
//   static const _textPrimary = Color(0xFFF1F5F9);
//   static const _textMuted = Color(0xFF64748B);
//   static const _fieldBg = Color(0xFF0D1424);

//   @override
//   void dispose() {
//     _usernameController.dispose();
//     _passwordController.dispose();
//     super.dispose();
//   }

//   Future<void> _login() async {
//     setState(() {
//       _isLoading = true;
//       _error = null;
//     });
//     await Future.delayed(const Duration(milliseconds: 800));

//     // Demo check — replace with real auth
//     if (_usernameController.text == 'supervisor' &&
//         _passwordController.text == 'super123') {
//       if (!mounted) return;
//       Navigator.of(context).pushReplacement(
//         MaterialPageRoute(
//           builder: (_) => const SupervisorDashboardView(),
//         ),
//       );
//     } else {
//       setState(() {
//         _isLoading = false;
//         _error = 'Invalid username or password.';
//       });
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: _bg,
//       body: Stack(
//         children: [
//           // ── Grid background ──────────────────────────────────────────────
//           Positioned.fill(
//             child: CustomPaint(painter: _GridPainter()),
//           ),

//           // ── Content ─────────────────────────────────────────────────────
//           SafeArea(
//             child: Center(
//               child: SingleChildScrollView(
//                 padding: const EdgeInsets.symmetric(horizontal: 28),
//                 child: Column(
//                   mainAxisSize: MainAxisSize.min,
//                   children: [
//                     const SizedBox(height: 20),

//                     // Icon
//                     Container(
//                       width: 64,
//                       height: 64,
//                       decoration: BoxDecoration(
//                         color: _accent,
//                         borderRadius: BorderRadius.circular(18),
//                       ),
//                       child: const Icon(Icons.build_circle_rounded,
//                           color: Colors.white, size: 30),
//                     ),
//                     const SizedBox(height: 20),

//                     // App name
//                     const Text(
//                       'AUTO GARAGE',
//                       style: TextStyle(
//                         color: _textPrimary,
//                         fontSize: 26,
//                         fontWeight: FontWeight.w900,
//                         letterSpacing: 4,
//                       ),
//                     ),
//                     const SizedBox(height: 6),
//                     const Text(
//                       'SUPERVISOR PORTAL',
//                       style: TextStyle(
//                         color: _textMuted,
//                         fontSize: 11,
//                         letterSpacing: 3,
//                         fontWeight: FontWeight.w500,
//                       ),
//                     ),
//                     const SizedBox(height: 36),

//                     // ── Card ────────────────────────────────────────────────
//                     Container(
//                       width: double.infinity,
//                       constraints: const BoxConstraints(maxWidth: 400),
//                       padding: const EdgeInsets.all(24),
//                       decoration: BoxDecoration(
//                         color: _card,
//                         borderRadius: BorderRadius.circular(16),
//                         border: Border.all(color: _border),
//                         boxShadow: [
//                           BoxShadow(
//                             color: Colors.black.withOpacity(0.4),
//                             blurRadius: 40,
//                             offset: const Offset(0, 12),
//                           ),
//                         ],
//                       ),
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           // USERNAME
//                           _Label('USERNAME'),
//                           const SizedBox(height: 8),
//                           _DarkField(
//                             controller: _usernameController,
//                             hint: 'Enter your username',
//                             prefixIcon: Icons.person_outline_rounded,
//                             onChanged: (_) =>
//                                 setState(() => _error = null),
//                           ),
//                           const SizedBox(height: 16),

//                           // PASSWORD
//                           _Label('PASSWORD'),
//                           const SizedBox(height: 8),
//                           _DarkField(
//                             controller: _passwordController,
//                             hint: 'Enter your password',
//                             prefixIcon: Icons.lock_outline_rounded,
//                             obscureText: _obscurePassword,
//                             suffixIcon: GestureDetector(
//                               onTap: () => setState(
//                                   () => _obscurePassword = !_obscurePassword),
//                               child: Icon(
//                                 _obscurePassword
//                                     ? Icons.visibility_off_outlined
//                                     : Icons.visibility_outlined,
//                                 color: _textMuted,
//                                 size: 18,
//                               ),
//                             ),
//                             onChanged: (_) =>
//                                 setState(() => _error = null),
//                           ),

//                           // Error
//                           if (_error != null) ...[
//                             const SizedBox(height: 10),
//                             Text(_error!,
//                                 style: const TextStyle(
//                                     color: Color(0xFFEF4444),
//                                     fontSize: 12)),
//                           ],

//                           const SizedBox(height: 12),

//                           // Forgot password
//                           Align(
//                             alignment: Alignment.centerRight,
//                             child: GestureDetector(
//                               onTap: () {},
//                               child: const Text(
//                                 'Forgot Password?',
//                                 style: TextStyle(
//                                   color: _accent,
//                                   fontSize: 12,
//                                   fontWeight: FontWeight.w500,
//                                 ),
//                               ),
//                             ),
//                           ),
//                           const SizedBox(height: 20),

//                           // Login button
//                           SizedBox(
//                             width: double.infinity,
//                             height: 48,
//                             child: ElevatedButton(
//                               onPressed: _isLoading ? null : _login,
//                               style: ElevatedButton.styleFrom(
//                                 backgroundColor: _accent,
//                                 foregroundColor: Colors.white,
//                                 elevation: 0,
//                                 shape: RoundedRectangleBorder(
//                                   borderRadius: BorderRadius.circular(10),
//                                 ),
//                               ),
//                               child: _isLoading
//                                   ? const SizedBox(
//                                       width: 20,
//                                       height: 20,
//                                       child: CircularProgressIndicator(
//                                           color: Colors.white,
//                                           strokeWidth: 2.5),
//                                     )
//                                   : const Text(
//                                       'LOGIN',
//                                       style: TextStyle(
//                                         fontSize: 14,
//                                         fontWeight: FontWeight.w800,
//                                         letterSpacing: 2,
//                                       ),
//                                     ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),

//                     const SizedBox(height: 32),

//                     // Footer
//                     Text(
//                       '© 2026 Auto Garage Management System.',
//                       style: TextStyle(
//                         color: _textMuted.withOpacity(0.6),
//                         fontSize: 11,
//                       ),
//                     ),
//                     const SizedBox(height: 20),
//                   ],
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // HELPERS
// // ─────────────────────────────────────────────────────────────────────────────

// class _Label extends StatelessWidget {
//   final String text;
//   const _Label(this.text);

//   @override
//   Widget build(BuildContext context) {
//     return Text(
//       text,
//       style: const TextStyle(
//         color: Color(0xFF94A3B8),
//         fontSize: 10,
//         fontWeight: FontWeight.w700,
//         letterSpacing: 1.5,
//       ),
//     );
//   }
// }

// class _DarkField extends StatelessWidget {
//   final TextEditingController controller;
//   final String hint;
//   final IconData prefixIcon;
//   final bool obscureText;
//   final Widget? suffixIcon;
//   final void Function(String)? onChanged;

//   const _DarkField({
//     required this.controller,
//     required this.hint,
//     required this.prefixIcon,
//     this.obscureText = false,
//     this.suffixIcon,
//     this.onChanged,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return TextField(
//       controller: controller,
//       obscureText: obscureText,
//       onChanged: onChanged,
//       style: const TextStyle(color: Color(0xFFF1F5F9), fontSize: 14),
//       decoration: InputDecoration(
//         hintText: hint,
//         hintStyle:
//             const TextStyle(color: Color(0xFF334155), fontSize: 13),
//         prefixIcon:
//             Icon(prefixIcon, color: const Color(0xFF475569), size: 18),
//         suffixIcon: suffixIcon,
//         filled: true,
//         fillColor: const Color(0xFF0D1424),
//         contentPadding:
//             const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
//         border: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(10),
//           borderSide:
//               const BorderSide(color: Color(0xFF1E2D4A)),
//         ),
//         enabledBorder: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(10),
//           borderSide:
//               const BorderSide(color: Color(0xFF1E2D4A)),
//         ),
//         focusedBorder: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(10),
//           borderSide:
//               const BorderSide(color: Color(0xFF2563EB), width: 1.5),
//         ),
//       ),
//     );
//   }
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // GRID BACKGROUND PAINTER
// // ─────────────────────────────────────────────────────────────────────────────

// class _GridPainter extends CustomPainter {
//   @override
//   void paint(Canvas canvas, Size size) {
//     final paint = Paint()
//       ..color = const Color(0xFF1E2D4A).withOpacity(0.35)
//       ..strokeWidth = 0.5;

//     const step = 40.0;

//     for (double x = 0; x <= size.width; x += step) {
//       canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
//     }
//     for (double y = 0; y <= size.height; y += step) {
//       canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
//     }

//     // Subtle blue glow in centre
//     final glowPaint = Paint()
//       ..shader = RadialGradient(
//         colors: [
//           const Color(0xFF2563EB).withOpacity(0.08),
//           Colors.transparent,
//         ],
//       ).createShader(
//           Rect.fromCircle(center: size.center(Offset.zero), radius: 280));
//     canvas.drawRect(
//         Rect.fromLTWH(0, 0, size.width, size.height), glowPaint);
//   }

//   @override
//   bool shouldRepaint(_) => false;
// }