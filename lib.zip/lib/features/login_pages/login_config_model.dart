import 'package:flutter/material.dart';
import 'package:orientmobileapplication/features/role_selection/user_role_model.dart';

class LoginConfigModel {
  final UserRole role;
  final String title;
  final String subtitle;
  final IconData icon;
  final Color iconBackgroundColor;
  final Color buttonColor;
  final bool showRequestPassword;
  final bool showCreateAccount;
  final String? demoUsername;
  final String? demoPassword;
  final String usernamePlaceholder;

  const LoginConfigModel({
    required this.role,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.iconBackgroundColor,
    required this.buttonColor,
    this.showRequestPassword = false,
    this.showCreateAccount = false,
    this.demoUsername,
    this.demoPassword,
    this.usernamePlaceholder = 'Enter your username',
  });

  static const Map<UserRole, LoginConfigModel> configs = {
    UserRole.owner: LoginConfigModel(
      role: UserRole.owner,
      title: 'Owner Portal',
      subtitle: 'All Branches',
      icon: Icons.manage_accounts_rounded,
      iconBackgroundColor: Color(0xFF1976D2),
      buttonColor: Color(0xFF1976D2),
      showRequestPassword: true,
      showCreateAccount: true,
      usernamePlaceholder: 'Enter your login ID',
    ),
    UserRole.customer: LoginConfigModel(
      role: UserRole.customer,
      title: 'Customer Portal',
      subtitle: 'Access your vehicles and service history',
      icon: Icons.directions_car_rounded,
      iconBackgroundColor: Color(0xFF1976D2),
      buttonColor: Color(0xFF1976D2),
      showRequestPassword: true,
      showCreateAccount: true,
      usernamePlaceholder: 'Enter your login ID',
    ),
    UserRole.technician: LoginConfigModel(
      role: UserRole.technician,
      title: 'Technician Login',
      subtitle: 'Auto Garage ERP System',
      icon: Icons.build_rounded,
      iconBackgroundColor: Color(0xFF1976D2),
      buttonColor: Color(0xFF1976D2),
      // demoUsername: 'tech001',
      // demoPassword: 'tech123',
    ),
    UserRole.advisor: LoginConfigModel(
      role: UserRole.advisor,
      title: 'Advisor Login',
      subtitle: 'Service Advisor Portal',
      icon: Icons.assignment_rounded,
      iconBackgroundColor: Color(0xFF37474F),
      buttonColor: Color(0xFF37474F),
      // demoUsername: 'ADV001',
      // demoPassword: 'advisor123',
    ),

    UserRole.supervisor: LoginConfigModel(
      role: UserRole.supervisor,
      title: 'Supervisor Portal',
      subtitle: 'Manage technicians and job assignments',
      icon: Icons.manage_accounts_rounded,
      iconBackgroundColor: Color(0xFF1565C0),
      buttonColor: Color(0xFF1976D2),
      usernamePlaceholder: 'Enter your username',
      showRequestPassword: false,
      showCreateAccount: false,
    ),
     UserRole.crmdasboard: LoginConfigModel(
      role: UserRole.crmdasboard,
      title: 'CRM Dashboard',
      subtitle: 'Dashboard',
      icon: Icons.manage_accounts_rounded,
      iconBackgroundColor: Color(0xFF1565C0),
      buttonColor: Color(0xFF1976D2),
      usernamePlaceholder: 'Enter your username',
      showRequestPassword: false,
      showCreateAccount: false,
    ),
  };
}
