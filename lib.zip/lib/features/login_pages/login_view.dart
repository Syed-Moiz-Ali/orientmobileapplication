import 'package:flutter/material.dart';
import 'package:orientmobileapplication/advisor_dashboard/advisor_home_view.dart';
import 'package:orientmobileapplication/features/crm_dasboard/crm_dasboard_view.dart';
import 'package:orientmobileapplication/features/customer/view/customer_dashboard_view.dart';
import 'package:orientmobileapplication/features/dashboard/view/dashboard_view.dart';
import 'package:orientmobileapplication/features/login_pages/login_config_model.dart';
import 'package:orientmobileapplication/features/login_pages/login_viewmodel.dart';
import 'package:orientmobileapplication/features/role_selection/user_role_model.dart';
import 'package:orientmobileapplication/advisor_dashboard/advisor_dashboard_viewmodel.dart';
import 'package:orientmobileapplication/features/supervisor/supervisor_dashboard_view.dart';
import 'package:orientmobileapplication/features/technician/view/technician_dashboard_view.dart';
import 'package:orientmobileapplication/forgotpasswordscreen/forgot_password_screen.dart';
import 'package:provider/provider.dart';

class LoginView extends StatelessWidget {
  final UserRole role;

  const LoginView({super.key, required this.role});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => LoginViewModel(),
      child: _LoginViewBody(role: role),
    );
  }
}

class _LoginViewBody extends StatelessWidget {
  final UserRole role;

  const _LoginViewBody({required this.role});

  @override
  Widget build(BuildContext context) {
    final config = LoginConfigModel.configs[role]!;

    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF1E88E5), Color(0xFF1565C0), Color(0xFF1A237E)],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: _LoginCard(config: config, role: role),
            ),
          ),
        ),
      ),
    );
  }
}

class _LoginCard extends StatelessWidget {
  final LoginConfigModel config;
  final UserRole role;

  const _LoginCard({required this.config, required this.role});

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<LoginViewModel>();

    return Container(
      width: double.infinity,
      constraints: const BoxConstraints(maxWidth: 400),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.15),
            blurRadius: 30,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Icon + Title
          Center(
            child: Column(
              children: [
                Container(
                  width: 72,
                  height: 72,
                  decoration: BoxDecoration(
                    color: config.iconBackgroundColor,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(config.icon, color: Colors.white, size: 34),
                ),
                const SizedBox(height: 16),
                Text(
                  config.title,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF1A1A2E),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  config.subtitle,
                  style: const TextStyle(
                    fontSize: 13,
                    color: Color(0xFF777777),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 28),

          // Username field
          _FieldLabel(
            label: config.role == UserRole.customer
                ? 'Login ID / Mobile Number'
                : 'Username',
          ),
          const SizedBox(height: 8),
          _InputField(
            controller: context.read<LoginViewModel>().usernameController,
            hint: config.usernamePlaceholder,
            prefixIcon: Icons.person_outline_rounded,
            onChanged: (_) => vm.clearError(),
          ),
          const SizedBox(height: 16),

          // Password field
          const _FieldLabel(label: 'Password'),
          const SizedBox(height: 8),
          const _PasswordField(),

          // Error message
          if (vm.errorMessage != null) ...[
            const SizedBox(height: 10),
            Text(
              vm.errorMessage!,
              style: const TextStyle(color: Colors.red, fontSize: 12.5),
            ),
          ],

          const SizedBox(height: 12),

          // ── Forgot Password / Request Password Row ──
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ForgotPasswordScreen(
                        themeColor: config.buttonColor,
                        iconBgColor: config.iconBackgroundColor,
                        portalTitle: config.title,
                        portalSubtitle: config.subtitle,
                        portalIcon: config.icon,
                      ),
                    ),
                  );
                },
                child: const Text(
                  'Forgot Password?',
                  style: TextStyle(
                    fontSize: 13,
                    color: Color(0xFF1976D2),
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              if (config.showRequestPassword)
                GestureDetector(
                  onTap: () {},
                  child: const Text(
                    'Request Password',
                    style: TextStyle(
                      fontSize: 13,
                      color: Color(0xFF1976D2),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
            ],
          ),

          const SizedBox(height: 20),

          // Login button
          _LoginButton(config: config, role: role),

          // Create Account (customer only)
          if (config.showCreateAccount) ...[
            const SizedBox(height: 12),
            const _CreateAccountButton(),
          ],

          // Demo credentials
          if (config.demoUsername != null) ...[
            const SizedBox(height: 16),
            _DemoCredentials(
              username: config.demoUsername!,
              password: config.demoPassword!,
            ),
          ],
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _FieldLabel extends StatelessWidget {
  final String label;
  const _FieldLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Text(
      label,
      style: const TextStyle(
        fontSize: 13.5,
        fontWeight: FontWeight.w600,
        color: Color(0xFF1A1A2E),
      ),
    );
  }
}

class _InputField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final IconData prefixIcon;
  final void Function(String)? onChanged;

  const _InputField({
    required this.controller,
    required this.hint,
    required this.prefixIcon,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      onChanged: onChanged,
      style: const TextStyle(fontSize: 14, color: Color(0xFF1A1A2E)),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Color(0xFFAAAAAA), fontSize: 14),
        prefixIcon: Icon(prefixIcon, color: const Color(0xFFAAAAAA), size: 20),
        filled: true,
        fillColor: const Color(0xFFF5F5F5),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFF1976D2), width: 1.5),
        ),
      ),
    );
  }
}

class _PasswordField extends StatelessWidget {
  const _PasswordField();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<LoginViewModel>();

    return TextField(
      controller: vm.passwordController,
      obscureText: !vm.isPasswordVisible,
      onChanged: (_) => vm.clearError(),
      style: const TextStyle(fontSize: 14, color: Color(0xFF1A1A2E)),
      decoration: InputDecoration(
        hintText: 'Enter your password',
        hintStyle: const TextStyle(color: Color(0xFFAAAAAA), fontSize: 14),
        prefixIcon: const Icon(
          Icons.lock_outline_rounded,
          color: Color(0xFFAAAAAA),
          size: 20,
        ),
        suffixIcon: GestureDetector(
          onTap: vm.togglePasswordVisibility,
          child: Icon(
            vm.isPasswordVisible
                ? Icons.visibility_outlined
                : Icons.visibility_off_outlined,
            color: const Color(0xFFAAAAAA),
            size: 20,
          ),
        ),
        filled: true,
        fillColor: const Color(0xFFF5F5F5),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFF1976D2), width: 1.5),
        ),
      ),
    );
  }
}

class _LoginButton extends StatelessWidget {
  final LoginConfigModel config;
  final UserRole role;

  const _LoginButton({required this.config, required this.role});

  void _navigateAfterLogin(BuildContext context) {
    switch (role) {
      case UserRole.advisor:
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(
            builder: (_) => ChangeNotifierProvider(
              create: (_) => AdvisorDashboardViewModel(),
              child: const AdvisorHomeView(),
            ),
          ),
        );
        break;
      case UserRole.technician:
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const TechnicianDashboardView()),
        );
        break;
      case UserRole.customer:
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const CustomerDashboardView()),
        );
        break;
      case UserRole.supervisor:
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const SupervisorDashboardView()),
        );
        break;
      case UserRole.owner:
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const DashboardView()),
        );
        break;
      case UserRole.crmdasboard:
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const CrmDashboardView()),
        );
        break;
      default:
        Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<LoginViewModel>();

    return SizedBox(
      width: double.infinity,
      height: 50,
      child: ElevatedButton( 
        onPressed: vm.isLoading
            ? null
            : () => vm.login(onSuccess: () => _navigateAfterLogin(context)),
        style: ElevatedButton.styleFrom(
          backgroundColor: config.buttonColor,
          foregroundColor: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        child: vm.isLoading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  color: Colors.white,
                  strokeWidth: 2.5,
                ),
              )
            : const Text(
                'Login',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
              ),
      ),
    );
  }
}

class _CreateAccountButton extends StatelessWidget {
  const _CreateAccountButton();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: OutlinedButton(
        onPressed: () {},
        style: OutlinedButton.styleFrom(
          foregroundColor: const Color(0xFF1976D2),
          side: const BorderSide(color: Color(0xFF1976D2), width: 1.5),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Create New Account',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
            ),
            SizedBox(width: 6),
            Icon(Icons.chevron_right_rounded, size: 20),
          ],
        ),
      ),
    );
  }
}

class _DemoCredentials extends StatelessWidget {
  final String username;
  final String password;

  const _DemoCredentials({required this.username, required this.password});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF5F5F5),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Demo Credentials:',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: Color(0xFF444444),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Username: $username',
            style: const TextStyle(fontSize: 12, color: Color(0xFF666666)),
          ),
          Text(
            'Password: $password',
            style: const TextStyle(fontSize: 12, color: Color(0xFF666666)),
          ),
        ],
      ),
    );
  }
}
