import 'package:flutter/material.dart';
import 'package:orientmobileapplication/advisor_dashboard/advisor_dashboard_viewmodel.dart';
import 'package:orientmobileapplication/advisor_dashboard/inspectionpages/inspection_vew_model.dart';
import 'package:orientmobileapplication/core/theme/app_fonts.dart';
import 'package:orientmobileapplication/features/crm_dasboard/crm_dasboard_view_model.dart';
import 'package:orientmobileapplication/features/customer/viewmodel/customer_dashboard_viewmodel.dart';
import 'package:orientmobileapplication/features/dashboard/viewmodel/dashboard_viewmodel.dart';
import 'package:orientmobileapplication/features/dashboardmenu/accountsreceivableviewmodel.dart';
import 'package:orientmobileapplication/features/dashboardmenu/activejobcardsviewmodel.dart';
import 'package:orientmobileapplication/features/dashboardmenu/documentexpiryviewmodel.dart';
import 'package:orientmobileapplication/features/dashboardmenu/job_status_viewmodel.dart';
import 'package:orientmobileapplication/features/dashboardmenu/pendingapprovalsviewmodel.dart';
import 'package:orientmobileapplication/features/dashboardmenu/pendingjobcardsviewmodel.dart';
import 'package:orientmobileapplication/features/role_selection/role_selection_viewmodel.dart';
import 'package:orientmobileapplication/routes/approutes.dart';
import 'package:provider/provider.dart';

// ─── App-wide color constants ────────────────────────────────────────────────
const Color kBlue = Color(0xFF1A73E8);
const Color kBlueBg = Color(0xFFE8F0FE);
const Color kBlueText = Color(0xFF1A73E8);
const Color kSurface = Color(0xFFF5F5F5);
const Color kText = Color(0xFF212121);
const Color kText3 = Color(0xFF757575);
const Color kText4 = Color(0xFF9E9E9E);

// ─── Top-level theme builder ──────────────────────────────────────────────────
ThemeData buildAppTheme() {
  return ThemeData(
    colorScheme: ColorScheme.fromSeed(seedColor: kBlue),
    scaffoldBackgroundColor: kSurface,
    textTheme: AppTypography.textTheme,
    useMaterial3: true,
  );
}

// ─── Entry point ──────────────────────────────────────────────────────────────
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => RoleSelectionViewModel()),
        ChangeNotifierProvider(create: (_) => DashboardViewModel()),
        ChangeNotifierProvider(create: (_) => AdvisorDashboardViewModel()),
        ChangeNotifierProvider(create: (_) => CustomerDashboardViewModel()),
        ChangeNotifierProvider(create: (_) => ActiveJobCardsViewModel()),
        ChangeNotifierProvider(create: (_) => PendingApprovalsViewModel()),
        ChangeNotifierProvider(create: (_) => AccountsReceivableViewModel()),
        ChangeNotifierProvider(create: (_) => DocumentExpiryViewModel()),
        ChangeNotifierProvider(create: (_) => InspectionViewModel()),
        ChangeNotifierProvider(create: (_) => PendingJobCardsViewModel()),
        ChangeNotifierProvider(create: (_) => AdvisorDashboardViewModel()),
        ChangeNotifierProvider(create: (_) => JobStatusViewModel()),
        ChangeNotifierProvider(create: (_) =>CrmDashboardViewModel ()),

      ],
      child: MaterialApp.router(
        debugShowCheckedModeBanner: false,
        routerConfig: routes,
        title: 'Orient Mobile',
        theme: buildAppTheme(),
      ),
    );
  }
}
